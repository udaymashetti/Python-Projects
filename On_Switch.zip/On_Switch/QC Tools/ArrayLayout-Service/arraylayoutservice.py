# import libs
import traceback

import datetime
import json
import time

from flask import Flask, render_template, request, send_file, session,redirect
from flask.json import jsonify
# import custom libs
from Qc import Qc

s3 = ''
bucket = None

app = Flask(__name__, static_url_path='/arraylayout/static')
app.secret_key = '123456'
qct = Qc()


@app.route('/arraylayout/main', methods=['GET', 'POST'])
def qc_tool():
    # imageData = ''
    start_time = time.time()
    st = datetime.datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S')
    qct.log(
        "------------------------------------------------------------------------------------------------------------------------------------------")
    qct.log("Qcarraylayout Initiated at {}".format(st))
    qct.log(
        "------------------------------------------------------------------------------------------------------------------------------------------")

    userName = None
    token2 = None
    if 'username' in session:
        userName = session['username']

    if 'token2' in session:
        token2 = session['token2']

    value = request.url_root;
    session['rootvalue'] = value

    if userName is not None:
        # token2 = request.args.get('token2')
        # token2 = session['token2']
        if token2 is not None:
            email = qct.validateSession(token2)
            if email is not '' and email is not 'error':
                redirectToValue = qct.getUserBasedDetails(email, value)
                if redirectToValue is 'approvalPending':
                    return redirect(value + "qctool/approvalPending")
                else:
                    if 'arraylayout' in redirectToValue:
                        return render_template('QARooftype.html')
                    else:
                        return redirect(value + 'qctool/home')
            else:
                session.pop('username', None)
                session.pop('token2', None)
                return redirect(value + "qctool/login")
        else:
            return redirect(value + "qctool/login")
    else:
        return redirect(value + "qctool/login")



@app.route('/arraylayout/initiate_session', methods=['POST'])
def initiate_session():
    try:
        content = json.loads(request.data)
        email = content['email']
        session['username'] = email
        qct.log("INFO    : Session initiated with email{}".format(email))
        return 'success'
    except Exception as ex:
        desired_trace = traceback.format_exc()
        qct.log("ERROR    : Session initiation encountered an error:{}".format(desired_trace))
    return "failed"

@app.route('/arraylayout/save_as_complete', methods=['POST'])
def save_as_complete():
    """3b receive modified image and upload to S3"""
    uid = None
    userCheck = qct.userSecurityCheck(session)
    qct.log("DEBUG User SecurityCheck Flag while saving image  is : {} ".format(userCheck))
    if userCheck is True:
        try:
            qct.log("Qcarraylayout save request content:'{}' ".format(request))
            content = request.get_json()
            fileName = content['selectimage']
            uid = fileName.split('/')[0]
            category = content['category']
            rank = content['rank']
            uid = uid.replace("-layoutviz.png", "")
            qct.log("INFO    : User request to save for UID {} initiated".format(uid))
            qct.db_service2_process_log(uid, stepName='layoutranking', baseStatus='complete')
            qct.db_service4_publish(uuid=uid, rank=rank, category=category)
            qct.onswitchdb_update(uid, status='PUBLISHED')
            qct.onswitchdb_insert_tracking(uid, '', 'PUBLISHED')
            qct.log("INFO    : User request to save for UID {} successful".format(uid))
            # Time stamps
            end_time = time.time()
            et = datetime.datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S')
            qct.log(
                "------------------------------------------------------------------------------------------------------------------------------------------")
            qct.log("Qcarraylayout with UID:'{}' successfully Completed at {}".format(uid, et))
            qct.log(
                "------------------------------------------------------------------------------------------------------------------------------------------")
            return 'images modified successfully'
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log("ERROR    : User request to save  for UID {} failed with error {}".format(uid, desired_trace))
            return 'failed'
    else:
        return "home"

@app.route('/arraylayout/getImageDetails', methods=['GET'])
def getImageDetails():
    imageData = ''
    username = ''
    inPipeLineimages = 0
    if 'username' in session:
        username = session['username']
        qct.log("INFO    : Active session user {}".format(username))

        uid_name,inPipeLineimages = qct.onswitchdb_get_uid(username)

        # uid_name = '00fe389c-b1f0-474d-bc41-c8483edbf399'

    if uid_name == None:
        qct.log("INFO    : Found no UID with status as IN-PROGRESS from database")
        qct.log("INFO    : Calling elect service for new UID")
        uid_name = qct.service1_get_uid()


    if uid_name is not None and uid_name != '':
        try:
            qct.db_service2_process_log(uid_name, stepName='layoutranking', baseStatus='inprogress')
            records = qct.onswitchdb_update(uid_name, 'IN-PROGRESS')
            if records is None or records == 0:
                qct.onswitchdb_insert(uid=uid_name, status='IN-PROGRESS', username=username)
            qct.onswitchdb_update_tracking(uid_name)
            qct.onswitchdb_insert_tracking(uid_name, username, 'IN-PROGRESS')

            imageData = qct.get_bg_img(uid_name)

            if imageData is None:
                qct.db_service2_process_log(uid_name, stepName='layoutranking', baseStatus='error')
                records = qct.onswitchdb_update(uid_name, 'ERROR')
                qct.onswitchdb_insert_tracking(uid_name, username, "Error Either BG is Not available")
                return getImageDetails()

            qct.log("SUCCESS : Images for UID {} rendered successfully".format(uid_name))
            return jsonify([uid_name,imageData,inPipeLineimages])
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log("ERROR : Inprocessing the UID {} with error {} ".format(uid_name, desired_trace))
            qct.db_service2_process_log(uid_name, stepName='layoutranking', baseStatus='error')
            records = qct.onswitchdb_update(uid_name, 'ERROR')
            qct.onswitchdb_insert_tracking(uid_name, username, str(ex))
            return getImageDetails()
    else:
        qct.log("INFO    : Images for UID {} couldnot be rendered".format(uid_name))
        return jsonify([uid_name,imageData,inPipeLineimages])

@app.route('/arraylayout/home', methods=['GET'])
def home1():
    if 'rootvalue' in session:
        root = session['rootvalue']
        return redirect(root+"qctool/home")

@app.route('/arraylayout/login', methods=['GET'])
def login():
    if 'rootvalue' in session:
        rValue = session['rootvalue']
        return redirect(rValue + "qctool/login")

if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True)
