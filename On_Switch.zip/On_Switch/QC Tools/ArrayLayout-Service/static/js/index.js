var roofPlanesArray = {};
var roofPlaneTypesArray = {};
var modifiedRoofPlaneTypesArray = {};
var current_image;
var bg_image;
var pendingInpipeline;



window.onload = function(e){

   $("#loadingIcon").css("display", "none");

   $("#parentContainer").css("visibility", "visible");
}


$(document).ready(function () {



	$.ajax({
		type: 'GET',
		async: false,
		url: '/arraylayout/getImageDetails',
		contentType: 'application/json; charset=utf-8'
	}).done(function (imageDetails) {
		current_image = imageDetails[0];
		bg_image = imageDetails[1];
		pendingInpipeline = imageDetails[2];

	}).fail(function () {
		alert("Something Went Wrong in callback(/arraylayout/getImageDetails)!!");
	});

	if(pendingInpipeline){
		     $("#pipeLinecount").val(pendingInpipeline);
		    }
		  else{
		     $("#pipeLinecount").val(0);
		    }

	$("input[name='c1']").prop("disabled", true);
	$("input[name='c1']").parent().css("cursor", "not-allowed");
	$("input[name='layoutId']").parent().css("cursor", "pointer");


	$(".wPaint-menu-icon-name-applyZoom").click(function () {
		$(".fa-search-plus").css("display", "none");
		$(".fa-search-minus").css("display", "block");

	});

	$(".wPaint-menu-icon-name-zoom").click(function () {
		if ($(this).attr('class').includes('active')) {
			$(".fa-search-minus").css("display", "none");
			$(".fa-search-plus").css("display", "block");
		}
	});


	currentFileName = current_image;
	if (currentFileName == '404' || currentFileName == 'None' || !currentFileName) {
		$("#pContainer").css("display", "block");
        $("#parentContainer").css("display", "none");
        $("#loadingIcon").css("display", "none");
		return;
	}

	var bgImage = bg_image;


	assignImageToCanvas(bgImage);
	$("#currentImageSpanId").html(currentFileName);


	$('#opacityBar').change(function () {
		var val = $(this).val();

		if (toolObject.childCanvas == "false") {
			context.clearRect(0, 0, canvas.width, canvas.height);
			context.globalAlpha = val;
			//context.drawImage(opacityCanvas, 0, 0);
			context.drawImage(fgOriginalcanvas, 0, 0, canvas.width, canvas.height);
		} else {

			var canvasZoomTemp = document.createElement('canvas'),
				ctxcanvasZoomTemp = canvasZoomTemp.getContext('2d');

			canvasZoomTemp.width = canvas.width;
			canvasZoomTemp.height = canvas.height;
			ctxcanvasZoomTemp.globalAlpha = 1;
			ctxcanvasZoomTemp.drawImage(fgZoomBoxcanvas, 0, 0);

			fgZoomBoxcontext.clearRect(0, 0, canvas.width, canvas.height);
			fgZoomBoxcontext.globalAlpha = val;
			//context.drawImage(opacityCanvas, 0, 0);
			fgZoomBoxcontext.drawImage(canvasZoomTemp, 0, 0, canvas.width, canvas.height);
		}

		console.log(val);
	});

	$('#lineWidthBar').change(function () {
		var val = $(this).val();
		val = Math.round(val)
		console.log(val);
		toolObject.setLineWidth(val);
	});

	$("#AcceptableId").change(function () {
		$(".wPaint-menu-icon-name-save").css("pointer-events", "all");
		$("input[name='c1']").prop("checked", false);
		$("input[name='c1']").prop("disabled", true);
		$("input[name='c1']").parent().css("cursor", "not-allowed");
	});
	$("#CondAccId").change(function () {
		$(".wPaint-menu-icon-name-save").css("pointer-events", "all");
		$("input[name='c1']").prop("disabled", false);
		$("input[name='c1']").parent().css("cursor", "pointer");

	});
	$("#RejectedId").change(function () {
		$(".wPaint-menu-icon-name-save").css("pointer-events", "all");
		$("input[name='c1']").prop("disabled", false);
		$("input[name='c1']").parent().css("cursor", "pointer");
	});


	$(".wPaint-menu-icon-name-save").append('<i style = "font-size : 20px;" class="fa fa-save"</i>');

	$(".wPaint-menu-icon-name-zoom").append('<i style = "font-size : 20px;" class="fas fa-search-plus" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-zoom").append('<i style = "font-size : 20px;display:none;" class="fas fa-search-minus" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-applyZoom").append('<i style = "font-size : 20px;" class="fa fa-arrows-alt" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-signout").append('<i style = "font-size : 20px;" class="fa fa-sign-out" aria-hidden="true"></i>');


});