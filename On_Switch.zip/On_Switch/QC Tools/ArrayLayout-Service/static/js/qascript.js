var canvas=document.getElementById("gameCanvas");
    ctx = canvas.getContext("2d");

canvas.width = 600;
canvas.height = 520;

//ctx.fillStyle = "red";
//ctx.fillRect(160, 240, 20,20);
//ctx.fillText("Im on top of the world!", 30,30);
ctx.globalAlpha = 0.5;
var image1 = new Image();
image1.src = 'images/sample1/TrueOrtho-001-033-028_pixel_mask_copy.png';
ctx.drawImage(image1, 00, 00);
ctx.globalCompositeOperation = "lighter";
