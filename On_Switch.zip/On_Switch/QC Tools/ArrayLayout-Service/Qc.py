# import libs
import traceback

import time
import boto3
import os
import base64
import json
import pymysql
import requests
import random
from pymysql import DatabaseError
# import custom scripts
from Logger import Logger
import CommonUtils as utils
import requests as req
from flask import session

s3 = ''
bucket = None

class Qc:
    """Class contains helper methods"""

    pendinginqueue = 0

    def __init__(self):
        self.conn = ''
        self.properties = utils.getPropertyFile()
        self.logger = Logger()

    def log(self, message):
        Logger.log(self.__class__.__name__, message)
        # print(message)

    def db_session(self):
        """Connect to db and return cursor object"""
        if self.conn == '' or (not self.conn.open):
            self.log("INFO    : Creating new DB connection")
            self.conn = pymysql.connect(host=self.properties.get('MYSQL', 'HOST'),
                                        user=self.properties.get('MYSQL', 'USER'),
                                        password=self.properties.get('MYSQL', 'PASSWORD'),
                                        db=self.properties.get('MYSQL', 'DB'),
                                        cursorclass=pymysql.cursors.DictCursor)
            self.conn.autocommit(True)

        if (not self.checkConn(self.conn)):
            # self.conn.close()
            self.conn = ''
            return self.db_session()

        return self.conn

    def checkConn(self,conn):
        sq = "SELECT NOW()"

        try:
            cursor = conn.cursor()
            cursor.execute(sq)
            cursor.close()
            return True
        except Exception as e:
            desired_trace = traceback.format_exc()
            self.log("ERROR: DB Connection failed {}".format(desired_trace))
            return False

    def client_session(self):
        """Create a S3 client session and return a client session object"""
        global s3
        if s3 == '':
            s3 = boto3.client('s3',
                              aws_access_key_id=self.properties.get('AWS', 'ACCESS_KEY'),
                              aws_secret_access_key=self.properties.get('AWS', 'SECRET_KEY'))
        return s3

    def onswitchdb_update(self,uid, status):
        """Take uid,status and update the status column of the table"""
        self.log("INFO    : In onswitchdb_update Method UID {}".format(uid))
        records = 0
        try:
            sql = "UPDATE onswitchdb.XX_QCTOOL_LOG SET Status = '{}',Last_Updated_On='{}' WHERE  Image_Key = '{}' and workflow_state='QC_ARRAY_LAYOUT' ".format(status,time.strftime(
                '%Y-%m-%d %H:%M:%S'),uid)
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            conn.commit()
            self.log("INFO    : Record for UID {} in XX_QCTOOL_LOG updated successfully as {} records {}".format(uid, status, records))
            # return records
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log("ERROR    : Record for UID {} in XX_QCTOOL_LOG failed to update with error {} and trace {}".format(uid, ex,desired_trace))
        return records

    def onswitchdb_get_uid(self,username):
        """return uid where status = inprogress"""
        uid=None
        self.log( "INFO    : In onswitchdb_get_uid Method UID {}")
        conn = self.db_session()
        cursor = conn.cursor()
        inProgresslist = 0
        # Release locked images if period exceeds 5 mins
        try:
            self.getPendingIdsCount()
            inProgresslist += self.pendinginqueue
            sql = "SELECT Image_Key FROM onswitchdb.XX_QCTOOL_LOG WHERE Status in ('IN-PROGRESS') AND TIMESTAMPDIFF(SECOND,Last_Updated_On ,now()) >=600  and workflow_state='QC_ARRAY_LAYOUT'"
            cursor.execute(sql)
            response = cursor.fetchall()
            uid_list = []
            for i in range(len(response)):
                print(response[i]['Image_Key'])
                uid_list.append(response[i]['Image_Key'])
            if len(uid_list) > 0:
                uid = random.choice(uid_list)
                inProgresslist += len(uid_list) - 1
            # else:
                # inProgresslist =  self.pendinginqueue
            self.log("INFO    : Retrieved a UID {} from data base".format(uid))
            cursor.close()
        except Exception as e:
            #conn.rollback()
            desired_trace = traceback.format_exc()
            self.log("ERROR    : Retrieving UID {} from data base failed with error {} and trace is {}".format(uid,e,desired_trace))

        return uid,inProgresslist

    def onswitchdb_insert(self,uid,status,username):
        """Take uid, status and insert as a row in the data base"""
        self.log("INFO    : In onswitchdb_insert Method UID {}".format(uid))
        records = 0
        try:
            sql = "INSERT INTO onswitchdb.XX_QCTOOL_LOG(Image_Key,Status,User,Engaged,workflow_state,created_on) VALUES ('"+uid+"','"+status+"','"+ username+"'," \
                "'YES','QC_ARRAY_LAYOUT','" + time.strftime('%Y-%m-%d %H:%M:%S') + "')"
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            cursor.close()
            conn.commit()
            self.log("INFO    : Records in XX_QCTOOL_LOG inserted for UID {} with username {}".format(uid,username))
            # return records
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log("ERROR    : Failed to insert records into XX_QCTOOL_LOG for UID {} with error {} {}".format(uid, ex,desired_trace))
        return records

    def onswitchdb_insert_tracking(self,uid,username,comments):
        """Take uid, status and insert as a row in the data base"""
        self.log("INFO    : In onswitchdb_insert_tracking Method UID {}".format(uid))
        records = 0
        try:
            sql = "INSERT INTO onswitchdb.XX_QCTOOL_LOG_TRACKING(image_key,user,current_step,started_on,comments) VALUES ('"+uid+"','"+ username+"'," \
                   "'QC_ARRAY_LAYOUT','" + time.strftime('%Y-%m-%d %H:%M:%S') + "','" + comments + "')"
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            conn.commit()
            self.log("INFO    : Record for UID {} in XX_QCTOOL_LOG_TRACKING updated successfully with username{}".format(uid,username))
            # return
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log("ERROR    : Record for UID {} in XX_QCTOOL_LOG_TRACKING failed to update with error {} {}".format(uid, ex,desired_trace))

        return records

    def onswitchdb_update_tracking(self,uid):
        """Take uid,status and update the status column of the table"""
        self.log("INFO    : In onswitchdb_update_tracking Method UID {}".format(uid))
        records = 0
        try:
            sql = "UPDATE onswitchdb.XX_QCTOOL_LOG_TRACKING SET Last_Updated_On='" + time.strftime(
                '%Y-%m-%d %H:%M:%S') + "' WHERE " \
                    "Image_Key = '"+uid+"' and current_step='QC_ARRAY_LAYOUT' and Last_Updated_On is null"
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            conn.commit()
            self.log("INFO    : Record for UID {} in XX_QCTOOL_LOG_TRACKING updated successfully".format(uid))
            return
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log("ERROR    : Record for UID {} in XX_QCTOOL_LOG_TRACKING failed to update with error {} {}".format(uid, ex,desired_trace))
        return records

    def get_bg_img(self, uid_name):
        """Take file name, download, encode, send and delete from local"""
        self.log( "INFO    : In get_bg_img Method UID {}".format(uid_name))
        s3 = self.client_session()
        try:
            bg_rgb_image_server_filename = str(uid_name) + '/remap/' + str(uid_name) + '-layoutviz.png'
            bg_rgb_image_local_filename_tif = uid_name + '-layoutviz.png'
            # download the selected image from S3 to local
            s3.download_file(Bucket=self.properties.get('S3', 'BUCKET'),
                             Key=bg_rgb_image_server_filename,
                             Filename=bg_rgb_image_local_filename_tif)
            with open(bg_rgb_image_local_filename_tif, "rb") as imageFile:
                image = base64.b64encode(imageFile.read())
            # Remove file once loaded
            os.remove(bg_rgb_image_local_filename_tif)
            self.log("INFO    : Retrieved RGB Image for UID {}".format(uid_name))
            return image.decode('ascii')
        except Exception as e:
            # print('exception code', e.response['Error']['Code'])
            desired_trace = traceback.format_exc()
            self.log( "ERROR : Retrieved RGB Image for UID {} {}".format(e.response['Error'],desired_trace))

            return None

    def getUserBasedDetails(self, email, rootvalue):
        try:
            url = rootvalue + "qctool/getUserBasedDetails?email=" + email + "&jsonFlag=True"
            alldetails = requests.request("GET", url)
            return alldetails.json()
        except Exception:
            desired_trace = traceback.format_exc()
            self.log( "ERROR: Error in getUserBasedDetails {}".format(desired_trace))

    def getPendingIdsCount(self):
        self.pendinginqueue = 0
        # Umcomment below code when they start sending count in COUNT_SERVICE_URL
        try:
            url = self.properties.get('DB_SERVICE', 'COUNT_SERVICE_URL')

            dbservice1_response = requests.request("GET", url)
            alldetails = dbservice1_response.json()
            if 'pendinginqueue' in alldetails:

                self.pendinginqueue = int(alldetails['pendinginqueue'])
                self.log( "Pending In Queue Are {}".format(self.pendinginqueue))
        except Exception:
            desired_trace = traceback.format_exc()
            self.log(": Error in put_fg_img RGB Image for trace {}".format( desired_trace))

    def service1_get_uid(self):
        """Send a request to db service and get a json and return the uuid"""
        uuid = None
        try:
            url = self.properties.get('DB_SERVICE', 'ELECT_SERVICE')
            dbservice1_response = requests.request("GET", url)
            alldetails = dbservice1_response.json()
            if (alldetails is None):
                return None
            global bucket
            dbservice1_data = alldetails['s3catalog']
            uuid = dbservice1_data['uuid']
            bucket = dbservice1_data['bucket']
            self.log("INFO    : Retrieved UID {} from elect service".format(str(uuid)))
            return str(uuid)
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log("ERROR    : Failed to retrieve any UID from elect service with error {} {}".format(ex,desired_trace))

        return uuid

    def db_service2_process_log(self, uuid, stepName, baseStatus):
        self.log("INFO    : In db_service2_process_log Method UID {}".format(uuid))
        """Receive the uuid,stepName, baseStatus parameters and update the db service accordingly """
        try:
            url = self.properties.get('DB_SERVICE', 'PROCESS_SERVICE_URL')
            payload = {
                        "uuid": uuid,
                        "stepName": stepName,
                        "baseStatus": baseStatus
                      }
            headers = {'content-type': 'application/json'}
            r = requests.post(url, data=json.dumps(payload), headers=headers)
            if eval(str(r.content)) == 'success':
                self.log("INFO    : Process log for UID {} updated with stepName {}, baseStatus {}".format(uuid,stepName,baseStatus))
                return "success"
            else:
                return "failed"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log("ERROR    : Process log update for UID {} failed with error {} {}".format(uuid,ex,desired_trace))
            return "failed"

    def validateSession(self, token2):
        # print("Inside validateSession")
        email = ''
        try:
            # CLIENT_ID = '39080003413-ld4rv4c123cvrmchpfn6s99lg221sod6.apps.googleusercontent.com'
            # Specify the CLIENT_ID of the app that accesses the backend:
            # idinfo = id_token.verify_oauth2_token(token, requests.Request(), CLIENT_ID)

            # print('access token=',token2)
            url = 'https://oauth2.googleapis.com/tokeninfo?access_token=' + token2
            # params = {'access_token': token2}
            r = req.get(url=url, params=None)
            data = r.json()
            if 'email' in data:
                self.log("DEBUG :The Email Id form google Api is {}".format(data['email']))
                # print("The Email Id form google Api is {}".format(data['email']))
                email = data['email']
                # print('email is ', email)
            elif 'error' in data:
                self.log("DEBUG :The session is either Expired/Signed out  for token {}".format(session['token2']))
                # print("The session is either Expired/Signed out  for token {}".format(session['token2']))
                if 'token2' in session:
                    self.log("DEBUG :The session Expired for token {}".format(session['token2']))
                    # print("The session Expired for token {}".format(session['token2']))
                    if 'refreshToken' in session:
                        self.log("DEBUG :Getting refresh Token {}")
                        # print("Getting refresh Token ")
                        access_token = self.refreshToken(session['refreshToken'])
                        self.log("DEBUG :The New Access  token generated is {}".format(access_token))
                        # print("The New Access  token generated is {}".format(access_token))
                        if access_token is not None:
                            session['token2'] = access_token
                            email = self.validateSession(access_token)
                            # print("Here It is ",email)
        except ValueError:
            # Invalid token
            self.log( "The value error {}".format(ValueError))
            # print('the value error',ValueError)
            pass
        except KeyError:
            self.log("The KeyError  {}".format(KeyError))
            # print('error')
            return 'error'
        # print("before return ",email)
        return email


    def db_service3_catalog(self,uuid, stepName, bucket, s3path):
        """Takes uuid, stepName, bucket, s3path, updates the db service with this information once the image is saved"""
        self.log( "INFO    : In db_service3_catalog Method UID {}".format(uuid))
        try:
            url = self.properties.get('DB_SERVICE', 'CATALOG_SERVICE_URL')
            payload = {
                    "uuid": uuid,
                    "stepName": stepName,
                    "bucket": self.properties.get('S3', 'BUCKET'),
                    "s3path": s3path
                    }
            headers = {'content-type': 'application/json'}
            r = requests.post(url, data=json.dumps(payload), headers=headers)
            if eval(str(r.content)) == 'success':
                self.log("INFO    : Catalog update for UUID {} with stepName {} successful".format(uuid,stepName))
                return "success"
            else:
                return "failed"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log("ERROR    : Catalog update for UUID {} failed with error {} {}".format(uuid,ex,desired_trace))
            return "failed"

    def db_service4_publish(self,uuid,rank,category):
        """Takes uuid, updates db service that qc1 and qc2 are completed"""
        self.log( "INFO    : In db_service4_publish Method UID {}".format(uuid))
        try:
            url = self.properties.get('DB_SERVICE', 'PUBLISH_SERVICE_URL')
            payload = {
                "uuid": uuid,
                "rank": rank,
                "category": category
            }
            print('payload is ',payload)
            headers = {'content-type': 'application/json'}
            r = requests.post(url, data=json.dumps(payload), headers=headers)
            # r = requests.post(url)
            if eval(str(r.content)) == 'success':
                self.log("INFO    : UID {} published successfully".format(uuid))
                return "success"
            else:
                return "failed"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log("ERROR    : UID {} failed to publish with error {} {}".format(uuid,ex,desired_trace))
            return "failed"

    def userSecurityCheck(self,session):
        self.log("DEBUG :Inside userSecurityCheck  Method..")
        # print("Inside userSecurityCheck  Method..")
        if 'username' in session and 'token2' in session:
            self.log("DEBUG :username and  token2  are in session..")
            # print("username and  token2  are in session..")
            token2 = session['token2']
            if token2 is not None:
                email = self.validateSession(token2)
                if email is not '' and email is not 'error':
                    self.log("DEBUG :TvalidateSessionoken validated Successfully")
                    # print("Token validated Successfully")
                    if 'applicationList' in session:
                        self.log("DEBUG :applicationList is in session")
                        # print("applicationList is in session")
                        if 'arraylayout' in session['applicationList']:
                            self.log("DEBUG :qctool is in applicationList")
                            # print("arraylayout is in applicationList")
                            return True
                        else:
                            self.log("DEBUG :arraylayout is not in applicationList")
                            return False
                    else:
                        self.log("DEBUG :applicationList is not in session")
                        return False
                else:
                    self.log("DEBUG :email is  '' or  error : {}".format(email))
                    # print("email return is", email)
                    return False
            else:
                self.log("DEBUG :Token 2 is None ")
                return False
        else:
            self.log("DEBUG :username and  token2  are not in session..")
            return False

    def refreshToken(self, refresh_token):
        self.log("DEBUG :Inside refreshToken Method.. refresh_token is : {}".format(refresh_token))
        client_id = None
        client_secret = None
        CLIENT_SECRET_FILE = self.properties.get('GSign-In', 'Client_Secret')
        # print(CLIENT_SECRET_FILE)
        with open(CLIENT_SECRET_FILE, 'r') as f:
            distros_dict = json.load(f)

        if 'web' in distros_dict:
            web = distros_dict['web']
            if 'client_id' in web:
                client_id = web['client_id']
            if 'client_secret' in web:
                client_secret = web['client_secret']

        params = {
            "grant_type": "refresh_token",
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": refresh_token
        }

        authorization_url = "https://www.googleapis.com/oauth2/v4/token"

        r = requests.post(authorization_url, data=params)

        if r.ok:
            self.log("DEBUG : Access Token refreshed Successfully . The new Access token is : {}".format(r.json()['access_token']))
            print("Access Token refreshed Successfully . The new Access token is : {}".format(r.json()['access_token']))
            return r.json()['access_token']
        else:
            self.log("DEBUG: Access Token is not refreshed . Returning None")
            print("Access Token is not refreshed . Returning None")
            return None
