from __future__ import division
import json
import traceback

import time
import datetime
from flask import Flask, render_template, request, send_file, session,redirect
from flask.json import jsonify
# import custom scripts
from Qc import Qc

# app = Flask(__name__)
app = Flask(__name__, static_url_path='/qctool/static')
app.secret_key = '123456'
qct = Qc()


@app.route('/qctool/main', methods=['GET', 'POST'])
# @app.route('/', methods=['GET', 'POST'])
def qc_tool():
    """Serves the html page@ 0.0.0.0/qctool, 1. Populate LOV on load"""
    start_time = time.time()
    st = datetime.datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S')
    qct.log(qct.DEBUG,"------------------------------------------------------------------------------------------------------------------------------------------")
    qct.log(qct.DEBUG,"QcTool Initiated at {}".format(st))
    qct.log(qct.DEBUG,"------------------------------------------------------------------------------------------------------------------------------------------")

    userName = None
    token2 = None
    if 'username' in session:
        userName = session['username']

    if 'token2' in session:
        token2 = session['token2']

    value = request.url_root;
    session['rootvalue'] = value

    if userName is not None:
        # token2 = request.args.get('token2')
        # token2 = session['token2']
        if token2 is not None:
            email = qct.validateSession(token2)
            if email is not '' and email is not 'error':
                redirectToValue = getUserBasedDetails(email,False)
                if redirectToValue is 'approvalPending':
                    return render_template("approvalPending.html")
                else:
                    if 'qctool' in redirectToValue:
                        return render_template('QATool.html')
                    else:
                        return render_template('home.html')
            else:
                session.pop('username', None)
                return render_template("login.html")
        else:
            return render_template("login.html")
    else:
        return render_template("login.html")


@app.route('/qctool/login', methods=['GET', 'POST'])
def login_tool():
    """ #login page Serves the html page@ 0.0.0.0/qctool, 1. Populate LOV on load"""
    return render_template('login.html')


# @app.route('/qctool/logout', methods=['POST'])
# def logout():
#     # remove the username from the session if it is there
#     if 'username' in session:
#         username = session['username']
#     session.pop('username', None)
#     qct.log(qct.DEBUG,"Session user{} successfully logged out".format(username))
#     return "success"


@app.route('/qctool/initiate_session', methods=['POST'])
def initiate_session():
    """Serves the html page@ 0.0.0.0/qctool, 1. Populate LOV on load"""
    content = json.loads(request.data)
    token2 = content['access_token']
    qct.log(qct.DEBUG, "Google Api token {}".format(token2))

    # email= qct.validateSession(token2)

    email, access_token = qct.verifyOneTimeCode(token2)

    session['username'] = email
    session['token2'] = access_token

    # return getUserBasedDetails(email)
    return 'home'


@app.route('/qctool/save_as_complete', methods=['POST'])
def save_as_complete():
    """3b receive modified image and upload to S3"""
    userCheck = qct.userSecurityCheck(session)
    qct.log(qct.DEBUG, " User SecurityCheck Flag while saving is : {} ".format(userCheck))
    print("user check",userCheck)
    if userCheck is True:
        print("user check", "success")
        qct.log(qct.DEBUG, "User request to save initiated")
        username = session['username']
        content = json.loads(request.data)
        fileName = content['selectimage']
        modified_image = content['save']
        # save changes
        uid = fileName.split('/')[0]
        try:
            qct.put_fg_img(modified_image, uid)
            qct.onswitchdb_update_tracking(uid)
            qct.onswitchdb_insert_tracking(uid, username, "saving image to bucket successful")
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.ERROR, " User request to save for UID {} failed with error {}".format(uid, desired_trace))
        # Time stamps
        end_time = time.time()
        et = datetime.datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S')
        qct.log(qct.DEBUG,"------------------------------------------------------------------------------------------------------------------------------------------")
        qct.log(qct.DEBUG,"QcTool with UID:'{}' successfully Completed at {}".format(uid, et))
        qct.log(qct.DEBUG,"------------------------------------------------------------------------------------------------------------------------------------------")
        print("returning Succ ess")
        return "success"
    else:
        print("returning home")
        return "home"



# @app.route('/qctool/getApplicationDetails', methods=['GET'])
# def appDetails():
#     if 'username' in session:
#         print("/qctool/getApplicationDetails userName in session {}".format(session['username']))
#         if 'applicationList' in session:
#             return jsonify(session['applicationList'])
#         else:
#             return " "
#
#     else:
#         return 'login'


@app.route('/qctool/reject', methods=['POST'])
def rejectImage():
    """User rejected image"""
    userCheck = qct.userSecurityCheck(session)
    qct.log(qct.DEBUG, " User SecurityCheck Flag while rejecting image  is : {} ".format(userCheck))
    if userCheck is True:
        print("User request to rejectImage initiated")
        qct.log(qct.DEBUG, "User request to rejectImage initiated")
        username = session['username']
        content = json.loads(request.data)
        fileName = content['selectimage']
        uid = fileName.split('/')[0]
        try:
            qct.db_service2_process_log(uuid=uid, baseStatus='Reject')
            qct.onswitchdb_update(uid, status='REJECTED')
            qct.onswitchdb_update_tracking(uid)
            qct.onswitchdb_insert_tracking(uid, username, "REJECTED")
            qct.log(qct.DEBUG, "User {} rejected UID {}".format(username, uid))
            return 'Image Rejected'
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.ERROR, "Status update of UID {} as Rejected failed with error {}".format(uid, desired_trace))
            return 'Image Reject failed'
    else:
        return "home"


@app.route('/qctool/approvalPending', methods=['GET'])
def approvalpending():
    return render_template("approvalpending.html")


@app.route('/qctool/home', methods=['GET'])
def home():
    return render_template("home.html")


@app.route('/qctool/approval', methods=['GET'])
def approval():
    # token2 = request.args.get('token2')
    value = request.url_root;
    token2 = session['token2']
    if token2 is None:
        return render_template('login.html')
    else:

        email = qct.validateSession(token2)
        if email is not ' ' and email is not 'error':
            session['username'] = email
            return render_template('approval.html')
        else:
            return render_template('login.html')


@app.route('/qctool/approvalData', methods=['GET'])
def approvalData():
    approvalData = qct.approval_data()
    return jsonify(approvalData)


@app.route('/qctool/updateApprovedData', methods=['POST'])
def updateApprovedData():
    try:
        if request.method == 'POST':
            content = json.loads(request.data)
            # content = json.dumps(json.loads(request.data))

            qct.log(qct.DEBUG, 'Modified Data in Approval table  IS: {}'.format(content))
            status = qct.approve_username(content)
            if (status == "success"):
                approvalData = qct.approval_data()
                return jsonify(approvalData)


    except Exception as ex:
        desired_trace = traceback.format_exc()
        qct.log(qct.DEBUG, "Error in updating ApprovedData failed with trace {}".format(desired_trace))
    return "success"


@app.route('/qctool/getImageDetails', methods=['GET'])
def getImageDetails():
    username = ''
    uid_name = None
    inPipeLineimages = 0
    if 'username' in session:
        username = session['username']

        qct.log(qct.DEBUG, "Active session user {}".format(username))

        # 1. call onswitchdb for uid status = inprogress
        uid_name, inPipeLineimages = qct.onswitchdb_get_uid(username)

    # Hard coded for testing
    #     uid_name = '18ac47fa-1156-4dde-aa31-b82f5599e6c3'

        if uid_name == None or uid_name == '':
            qct.log(qct.DEBUG, "Found no UID with status as IN-PROGRESS from database, Calling elect service for new UID")
            qct.log(qct.DEBUG, "")
            uid_name = qct.db_service1_get_uid()

    if uid_name is not None and uid_name != '':
        try:
            qct.db_service2_process_log(uid_name, baseStatus='inprogress')
            records = qct.onswitchdb_update(uid_name, 'IN-PROGRESS')
            if records == 0:
                qct.onswitchdb_insert(uid=uid_name, status='IN-PROGRESS', username=username)
            qct.onswitchdb_update_tracking(uid_name)
            qct.onswitchdb_insert_tracking(uid_name, username, "In Progress")

            bg = qct.get_bg_img(uid_name)

            fg = qct.get_fg_img(uid_name)
            if fg is None or bg is None:
                qct.db_service2_process_log(uid_name, baseStatus='error')
                records = qct.onswitchdb_update(uid_name, 'ERROR')
                qct.onswitchdb_insert_tracking(uid_name, username, "Error Either FG or BG is Not available")
                return getImageDetails()
            raw_image = uid_name + '/qc1/' + uid_name + '-maskedimage.tif'
            # update process log
            # qct.db_service2_process_log(uid_name, baseStatus='inprogress')

            qct.log(qct.DEBUG, "Images for UID {} rendered successfully".format(uid_name))
            return jsonify([raw_image, bg, fg, uid_name, inPipeLineimages])
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.ERROR, " Image downloading error:{}".format(desired_trace))
            qct.db_service2_process_log(uid_name, baseStatus='error')
            qct.onswitchdb_insert_tracking(uid_name, username, "error " + str(ex))
            records = qct.onswitchdb_update(uid_name, 'ERROR')
            # return render_template('QARoofBoundaries.html', session_images=[uid_name, '', ''])
            qct.log(qct.INFO, "------serving new image as error in previous uid-------------")
            return getImageDetails()

    else:
        qct.log(qct.DEBUG, "Images for UID {} couldnot be rendered".format(uid_name))
        return jsonify([uid_name, '', '', '', inPipeLineimages])


@app.route('/qctool/getToken', methods=['GET'])
def getToken():
    if 'token2' in session:
        return jsonify(session['token2'])


@app.route('/qctool/signout', methods=['GET'])
def signout():
    if 'token2' in session:
        token2 = session['token2']
        qct.signoutUser(token2)
        session.pop('username', None)
        session.pop('token2', None)
        return "success"


@app.route('/qctool/getHomeData', methods=['GET'])
def getHomeData():
    if 'username' in session and 'token2' in session:
        return getUserBasedDetails(session['username'],True)
    else:
        return "login"

@app.route('/qctool/getUserBasedDetails', methods=['GET'])
def getUserDetails():
    eMail = request.args.get('email')
    JFlag = request.args.get('jsonFlag')
    print (eMail,JFlag)
    returnValue = getUserBasedDetails(eMail,JFlag)
    print (returnValue)
    return jsonify(returnValue)

def getUserBasedDetails(email,jsonFlag):
    result = qct.approval_status(email)

    if (result[0] == 'success'):
        user_list = result[1]
        approved_value = user_list[0]['approved_flag']
        admin_value = user_list[0]['admin_flag']
        if approved_value == 'Y':
            valueList = {}
            if user_list[0]['qc1_flag'] == 'Y':
                valueList["qcboundaries"] = "/qcboundaries/main"
            if user_list[0]['qc2_flag'] == 'Y':
                valueList["qctool"] = "/qctool/main"
            if user_list[0]['array_layout_flag'] == 'Y':
                valueList["arraylayout"] = "/arraylayout/main"
            if user_list[0]['biz_portal_flag'] == 'Y':
                valueList["address_portal"] = "/address_portal/main"
            if admin_value == 'Y':
                valueList["approval"] = "approval"

            session['applicationList'] = valueList

            if jsonFlag is True:
                return jsonify(valueList)
            else:
                return valueList
            # else:
            #     if (len(valueList) == 1):
            #         session['applicationList'] = valueList
            #         key = list(valueList.keys())[0]
            #         return valueList[key]
            #     else:
            #         session['applicationList'] = valueList
            #         return "home"
        else:
            return "approvalPending"
    else:
        qct.log(qct.DEBUG, "Session initiation for user {} encountered an error".format(email))
        return 'approvalPending'




if __name__ == '__main__':
    # app.run(debug=True, host='0.0.0.0')
    app.run(debug=True, port='5000')
