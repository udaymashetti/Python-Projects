function handleSignOutClick(event) {
console.log("this signout");

var r = confirm("Do you want to sign-out?");
if (r == true) {
var accesstoken = "";
$.ajax(
{
url: "/qctool/signout",
async : false,
success: function(response){

	window.location.href='login';
}
});

/* $.ajax(
{
async : false,
url: "https://accounts.google.com/o/oauth2/revoke?token="+accesstoken,
success: function(result){

window.location.href='login';
}
}); */

} else {
return;
}
}
function handleHomeClick(event) {
	$.ajax({
		type: 'GET',
		url: 'getHomeData',
		contentType: 'application/json; charset=utf-8'
	}).done(function (data) {
		if (data == 'approvalPending') {
			window.location.href = 'approvalPending';
		} else if (data == 'login') {
			window.location.href = 'login';
		} else {
			for (var key in data) {
				var element = document.getElementById(key);
				var href = document.getElementById(key+"_href")
				$(element).css("display", "block");
//				$(element).parent().css("display", "list-item");
				$(href).attr("href", data[key]);
			}
			$("#visual").css("display", "block");
		}
	}).fail(function () {
		alert("Posting failed.");
	});
}