$(document).ready(function () {



  $.ajax({
		type: 'GET',
		async: false,
		url: '/qctool/approvalData',
		contentType: 'application/json; charset=utf-8'
	}).done(function (data) {
		console.log("Approval data Fetched");
		console.log(data);
		createDataTable(data);

	}).fail(function () {
		alert("Something Went Wrong in callback(/qctool/approvalData)!!");
	});

	function createDataTable(tableData) {
	console.log(tableData);
    var table = $('#dataTableId').DataTable({

        responsive: true,
        searching: false,
        select: true,
        "stripeClasses": ['odd', 'even'],
        paging: false,
        info: false,
        data: tableData,

        'columnDefs': [{
            /* width: '20%', targets: 0, */
            'targets': 2,
            'searchable': false,
            'orderable': false,
            'checkboxes': {
                'selectRow': true
            },
            'className': 'dt-body-center',
            'render': function (data, type, full, meta) {
               let checked = "";
                if(data == 'Y' || data == 'y'){
                   checked = "checked";
                }
                return '<input type="checkbox" name="selectRowCB"'+checked+'>';
            }
        },
        {
            "targets": 0,
            'className': 'dt-body-center',
            'render': function (data, type, full, meta) {
                 let checked = "";
//                if(data == 'Y' || data == 'y'){
//                   checked = "checked";
//                }
                return '<input type="checkbox" name="changedRows" disabled'+checked+'>';
            }
            },
        {
            "targets": 3,
            'className': 'dt-body-center',
            'render': function (data, type, full, meta) {
                 let checked = "";
                if(data == 'Y' || data == 'y'){
                   checked = "checked";
                }
                return '<input type="checkbox" name="selectRowCB"'+checked+'>';
            }
            },
            {
            "targets": 4,
            'className': 'dt-body-center',
            'render': function (data, type, full, meta) {
                 let checked = "";
                if(data == 'Y' || data == 'y'){
                   checked = "checked";
                }
                return '<input type="checkbox" name="selectRowCB"'+checked+'>';
            }
            },
            {
            "targets": 5,
            'className': 'dt-body-center',
            'render': function (data, type, full, meta) {
                 let checked = "";
                if(data == 'Y' || data == 'y'){
                   checked = "checked";
                }
                return '<input type="checkbox" name="selectRowCB"'+checked+'>';
            }
            },
            {
            "targets": 6,
            'className': 'dt-body-center',
            'render': function (data, type, full, meta) {
                 let checked = "";
                if(data == 'Y' || data == 'y'){
                   checked = "checked";
                }
                return '<input type="checkbox" name="selectRowCB"'+checked+'>';
            }
            },
            {
            "targets": 7,
            'className': 'dt-body-center',
            'render': function (data, type, full, meta) {
                 let checked = "";
                if(data == 'Y' || data == 'y'){
                   checked = "checked";
                }
                return '<input type="checkbox" name="selectRowCB"'+checked+'>';
            }
            },

//        {
//            "targets": 4,
//            'className': 'dt-body-center',
//            'render': function (data, type, full, meta) {
//                let onSAN  = "";
//                let readOnly = "";
////                if(full.onswitchAccountName){
////                   onSAN = full.onswitchAccountName;
////                   readOnly = "readonly";
////                }
//                return '<input type="text" value = "' + $('<div/>').text(onSAN).html() + '" name="acctnames[] "'+readOnly+' >';
//            }

//        }

        ],
        dom: '1Bfrtip',
        buttons: [

        ],
        select: {
            style: 'multi'//,//os
            //selector: 'td:first-child'
        },
        destroy: true,
        'order': [[1, 'asc']],
        "columns": [
            {
                "title": 'Changed',
                targets: 0,
//                data: 'user_id',
                defaultContent: '',
                "className": "dt-center1 dt-center2 dt-defaultColor dt-checkboxes-cell",
                orderable: false,

//                 "width" : "10%",
            },
            {
                "title": "User Name",
                "className": "dt-left dt-defaultColor all-copy",
                data : 'user_name',
            },
            {
                "title": "Active",
                "className": "dt-center1 dt-center2 dt-ownershipColor ",
                  data : 'approved_flag',

            },
            {
                "title": "Admin",
                "className": "dt-center1 dt-center2 dt-ownershipColor ",
                  data : 'admin_flag',

            },
            {
                "title": "Building & Business Information",
                "className": "dt-center1 dt-center2 dt-ownershipColor ",
                  data : 'biz_portal_flag',

            },

            {
                "title": "Training Data (Building)",
                "className": "dt-center1 dt-center2 dt-ownershipColor ",
                  data : 'qc1_flag',

            },
            {
                "title": "Training Data (Features)",
                "className": "dt-center1 dt-center2 dt-ownershipColor ",
                  data : 'qc2_flag',

            },
            {
                "title": "Array Layout Ranking",
                "className": "dt-center1 dt-center2 dt-ownershipColor ",
                  data : 'array_layout_flag',

            },
            

        ],
        keys: {
            clipboard: true
        },
    });

    $('#dataTableId td').on('change',function () {
         $(this).parent().find('input[name = "changedRows"]').prop('checked', true);
         $(this).parent().toggleClass('selected');
      });
    }

$("#Updatebtn").click(function () {
        $('#htmlDoc').css("cursor", "wait");
        let table = $('#dataTableId').DataTable();
        var index = 0;
        wData = []
        table.rows().every(function (index, element) {
        rowData = []
        var row = $(this.node());
        var td = $(row.children()[0]);
        if($(td.children()[0]).prop("checked") == true){
           for(var index = 1 ; index < row.children().length ;index++  ){
               var td = $(row.children()[index]);
              if(index == 1){
                var user_name = td.html();
                rowData.push(user_name);
              }
              else{
              if($(td.children()[0]).prop("checked") == true){
                rowData.push("Y");
              }
              else{
                rowData.push(' ');
              }
           }

        }
        wData.push(rowData);
            }
    });
    console.log(wData);
    $.ajax({
            type: 'POST',
            url: '/qctool/updateApprovedData',
            data: JSON.stringify(wData),
            contentType: 'application/json; charset=utf-8'
        }).done(function (data) {
           createDataTable(data);
           $('#htmlDoc').css("cursor", "default");
           alert("Data updated Successfully");
//           table.columns.adjust().draw();

        }).fail(function () {
           $('#htmlDoc').css("cursor", "default");

            alert("Something Went Wrong in updating ApprovedData!!");
        });
    });




	$('button').click(function () {


		user_data = [];
		$(".modifyflag").each(function () {
			user_flag = $(this).is(":checked") ? 'Y' : 'N';
			user_data.push({
				"userid": $(this).attr('data-userid'),
				"userflag": user_flag
			});
		});
		// alert(user_data);
		$.ajax({
			type: "POST",
			url: "initiate_session_a",
			// data:'{"id":"' + profile.getId() + '","email":"' + profile.getEmail() + '"}'
			data: JSON.stringify(user_data),

			//data:'{"key":"' + userMap.get(user_name) + '","value":"' +user_chk+ '"}',

			contentType: 'application/json; charset=utf-8',
			success: function (msg) {
				$(".check").removeClass("modifyflag");
				console.log("success");
				alert("Changes Updated Successfully")
			}
		});
	});
	// var chk = document.getElementById("chkbox").checked;

	// if (chk == true) {

	//   var chkval = $("#checkboxid").val();

	//   $.ajax({
	//     url: 'approvaldone',
	//     type: 'POST',
	//     data: chkval,
	//     success: function (response) {
	//       $('#main').text(response)
	//     }
	//   })
	// }
});

$(".check").click(function () {
	//if($(this).is(":checked")){
	$(this).addClass("modifyflag");
	//}else{
	//$(this).removeClass("modifyflag");
	// }
});

function onLoad() {
	gapi.load('auth2', function () {
		gapi.auth2.init();
	});
}


