import re

from PIL import Image


# st = "David's Bridal"
#
# print(st.replace("'","\\'"))

# print(re.escape(st))
img = Image.open('63bc4bd6-3cb5-4eb1-8b66-5ea401f232a9-qcroofmask.tif')
img = img.convert("RGBA")
print(type(img))
pixdata = img.load()
#
width,height = img.size

for y in xrange(height):
    for x in xrange(width):
        # print(pixdata[x,y])
        # if pixdata[x,y]  != 0:
        #     print(pixdata[x,y])
        #     pixdata[x,y] = int(255)
        #     img.putpixel((x,y),255)
        if pixdata[x,y]  != (0,0,0,255):
            print(pixdata[x, y])
            pixdata[x,y] = (255,255,255,255)
img.save("test1112.png","PNG")