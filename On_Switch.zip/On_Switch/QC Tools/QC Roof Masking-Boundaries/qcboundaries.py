# import libs
from __future__ import division

import traceback

import time
import json
import datetime
from flask import Flask, render_template, request, send_file, session, jsonify,redirect
# import custom scripts
from Qc import Qc


app = Flask(__name__, static_url_path='/qcboundaries/static')
app.secret_key = '123456'
qct = Qc()


@app.route('/qcboundaries/main', methods=['GET', 'POST'])
def qc_tool():
    """Serve the page @ https://qc.onswitchenergy.com/qcboundaries/main"""
    start_time = time.time()
    st = datetime.datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S')
    qct.log(qct.DEBUG,"------------------------------------------------------------------------------------------------------------------------------------------")
    qct.log(qct.DEBUG,"Qcboundaries Initiated at {}".format(st))
    qct.log(qct.DEBUG,"------------------------------------------------------------------------------------------------------------------------------------------")

    userName = None
    token2 = None
    if 'username' in session:
        userName = session['username']

    if 'token2' in session:
        token2 = session['token2']

    value = request.url_root;
    session['rootvalue'] = value

    if userName is not None:
        # token2 = request.args.get('token2')
        # token2 = session['token2']
        if token2 is not None:
            email = qct.validateSession(token2)
            if email is not '' and email is not 'error':
                redirectToValue = qct.getUserBasedDetails(email, value)
                if redirectToValue is 'approvalPending':
                    return redirect(value + "qctool/approvalPending")
                else:
                    if 'qcboundaries' in redirectToValue:
                        return render_template('QARoofBoundaries.html')
                    else:
                        return redirect(value + 'qctool/home')
            else:
                session.pop('username', None)
                session.pop('token2', None)
                return redirect(value + "qctool/login")
        else:
            return redirect(value + "qctool/login")
    else:
        return redirect(value + "qctool/login")


# Function not in use
# @app.route('/qcboundaries/initiate_session', methods=['POST'])
# # @app.route('/', methods=['GET', 'POST'])
# def initiate_session():
#     """Serves the html page@ 0.0.0.0/qctool"""
#     content = json.loads(request.data)
#     try:
#         email = content['email']
#         session['username'] = email
#         qct.log(qct.INFO," Session initiated with email{}".format(email))
#         return 'success'
#     except Exception as ex:
#         desired_trace = traceback.format_exc()
#         qct.log(qct.ERROR," Session initiation encountered an error:{}".format(ex))
#

@app.route('/qcboundaries/save_as_complete', methods=['POST'])
def save_as_complete():
    """3b receive modified image and upload to S3"""
    userCheck = qct.userSecurityCheck(session)
    qct.log(qct.DEBUG, " User SecurityCheck Flag while Saving image  is : {} ".format(userCheck))
    if userCheck is True:
        content = json.loads(request.data)
        # Auto = content['Auto']
        # Qcd = content['Qcd']
        # print(qct.accuracy_qc1(Auto,Qcd))
        originalFileName = content['selectimage']
        modified_masked_image = content['save']
        original_bg_image = content['bgImage']
        uid = originalFileName.split('/')[0]
        qct.log(qct.DEBUG," User request to save for UID {} initiated".format(uid))
        # save modified images in s3
        try:
            qct.put_fg_img(modified_masked_image, original_bg_image, originalFileName)
            qct.log(qct.INFO,"User request to save for UID {} successful".format(uid))
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.ERROR," User request to save for UID {} failed with error {}".format(uid,desired_trace))

        # update the catalog service
        key = uid + "/qc1/" + uid + "-maskedimage.tif"
        qct.log(qct.INFO," s3 key for UID {} is {}".format(uid, key))

        # 5. update the catalog log service
        try:
            qct.db_service3_catalog(uuid=uid,
                                    stepName="qc1",
                                    bucket=qct.properties.get('S3', 'BUCKET'),
                                    s3path=key)
            qct.log(qct.INFO," Catalog update for UID {} successful".format(uid))
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.ERROR," Catalog update for UID {} failed with error {}".format(uid, desired_trace))

        # 6. update the process log service
        try:
            qct.db_service2_process_log(uuid=uid, stepName="qc1", baseStatus='complete')
            qct.log(qct.INFO," Process log update for UID {} successful".format(uid))
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.DEBUG," Process log update for UID {} failed with error {}".format(uid, desired_trace))

        # 8. publish qc1 step
        qct.db_service4_publish(uuid=uid)
        qct.log(qct.INFO," UID {} published successfully".format(uid))

        # 9. update onswitch_db() with status = Published
        qct.onswitchdb_update(uid, status='PUBLISHED')
        # qct.onswitchdb_update_tracking(uid)
        qct.onswitchdb_insert_tracking(uid, '', "PUBLISHED")
        # Time stamps
        end_time = time.time()
        et = datetime.datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S')
        qct.log(qct.DEBUG,"-----------------------------------------------------------------------------------------------------------------------------------------")
        qct.log(qct.DEBUG,"QcBoundaries with UID:'{}' successfully Completed at {}".format(uid,et))
        qct.log(qct.DEBUG,"------------------------------------------------------------------------------------------------------------------------------------------")
        return "success"
    else:
        return "home"


@app.route('/qcboundaries/reject', methods=['POST'])
def rejectImage():
    """3b receive modified image and upload to S3"""
    userCheck = qct.userSecurityCheck(session)
    qct.log(qct.DEBUG, " User SecurityCheck Flag while rejecting image  is : {} ".format(userCheck))
    if userCheck is True:
        content = json.loads(request.data)
        fileName = content['selectimage']
        uid = fileName.split('/')[0]
        qct.log(qct.INFO," User rejected UID {}".format(uid))
        # update onswitch_db() with status = Rejected
        try:
            qct.db_service2_process_log(uuid=uid, stepName="qc1", baseStatus='Reject')
            qct.onswitchdb_update(uid, status='REJECTED')
            qct.onswitchdb_insert_tracking(uid, '', "REJECTED")
            # qct.onswitchdb_update_tracking(uid)
            return 'Image Rejected'
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.ERROR," Status update of UID {} as Rejected failed with error {}".format(uid, desired_trace))
    else:
        return "home"

@app.route('/qcboundaries/getImageDetails', methods=['GET'])
def getImageDetails():
    username = ''
    uid_name = None
    inPipeLineimages = 0
    if 'username' in session:
        username = session['username']
        qct.log(qct.INFO, ": Active session user {}".format(username))

    # 1. call onswitchdb for uid status = inprogress
        uid_name,inPipeLineimages = qct.onswitchdb_get_uid(username)

    # Hard coded for testing
    # uid_name = '01fd4855-6253-4010-893b-c07d139c54a4'

    if uid_name == None:
        qct.log(qct.DEBUG, " Found no UID with status as IN-PROGRESS from database, Calling elect service for new UID")
        uid_name = qct.db_service1_get_uid()

    if uid_name is not None and uid_name != '':
        try:
            qct.db_service2_process_log(uid_name, stepName='qc1', baseStatus='inprogress')
            records = qct.onswitchdb_update(uid_name, 'IN-PROGRESS')
            if records == 0:
                qct.log(qct.DEBUG, " No records  for UID {} to update".format(uid_name))
                qct.onswitchdb_insert(uid=uid_name, status='IN-PROGRESS', username=username)
            qct.onswitchdb_update_tracking(uid_name)
            qct.onswitchdb_insert_tracking(uid_name, username, "In progress")

            bg = qct.get_bg_img(uid_name)
            fg = qct.get_fg_img(uid_name)
            if fg is None or bg is None:
                qct.db_service2_process_log(uid_name, stepName='qc1', baseStatus='error')
                records = qct.onswitchdb_update(uid_name, 'ERROR')
                qct.onswitchdb_insert_tracking(uid_name, username, "Error Either FG or BG is Not available")
                return getImageDetails()

            raw_image = uid_name + '/graster/' + uid_name + '-grasterrgb.tif'
            # 4. update db_service2_process_log() with baseStaus = inprogress
            # qct.db_service2_process_log(uid_name, stepName='qc1', baseStatus='inprogress')

            qct.log(qct.DEBUG, " Images for UID {} rendered successfully".format(uid_name))
            return jsonify([raw_image, bg, fg,inPipeLineimages])
            # returrn render_template('QARoofBoundaries.html', session_images=[raw_image, bg, fg])
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.ERROR, " Image downloading error:{}".format(desired_trace))
            qct.db_service2_process_log(uid_name, stepName='qc1', baseStatus='error')
            qct.onswitchdb_insert_tracking(uid_name, username, "error " + str(ex))
            records = qct.onswitchdb_update(uid_name, 'ERROR')
            # return render_template('QARoofBoundaries.html', session_images=[uid_name, '', ''])
            qct.log(qct.INFO, "------serving new image as error in previous uid-------------")
            return getImageDetails()
    else:
        qct.log(qct.INFO, " Images for UID {} couldnot be rendered".format(uid_name))
        return jsonify([uid_name, '', '',inPipeLineimages]);
        # return render_template('QARoofBoundaries.html', session_images=[uid_name, '', ''])

@app.route('/qcboundaries/home', methods=['GET'])
def home1():
    if 'rootvalue' in session:
        root = session['rootvalue']
        return redirect(root+"qctool/home")

@app.route('/qcboundaries/login', methods=['GET'])
def login():
    value = session['rootvalue']
    return redirect(value + "qctool/login")

if __name__ == '__main__':
    app.run(host = '0.0.0.0',debug=True)
