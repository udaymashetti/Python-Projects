from PIL import Image

img = Image.open('SunAPI_Mask_copy.tif')
img = img.convert("RGBA")

pixdata = img.load()

width,height = img.size
print(img.getbands())
count = 0
for y in xrange(height):
    for x in xrange(width):
        # print(pixdata[x,y])
        # if pixdata[x,y] != 0 :
        #     print(pixdata[x, y])
             # count = count + 1
        if pixdata[x,y]  == (1,1,1,255):
            pixdata[x,y] = (255,0,0,255)
#         if pixdata[x,y]  == (0,0,0,255):
#             pixdata[x,y] = (255,255,255,0)
#             pixdata[x, y] = int(255)
#             print(pixdata[x, y])
img.save("test3.png","PNG")


#
# print(count)
# print(int(255))