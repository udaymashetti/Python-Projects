var defaultGlobalAlpha = 0.4;
var currentGlobalAlpha = 0.4;
var session_images;


window.onload = function(e){

   $("#loadingIcon").css("display", "none");

   $("#parentContainer").css("visibility", "visible");
}

$(document).ready(function () {

//	$(".wPaint-menu-icon-name-applyZoom").click(function () {
//		if ($(this).attr('class').includes('active')) {
//			$(".fa-search-plus").css("display", "none");
//			$(".fa-search-minus").css("display", "block");
//		}
//	});

	$(".wPaint-menu-icon-name-zoom").click(function () {

		$(".fa-search-minus").css("display", "none");
		$(".fa-search-plus").css("display", "block");
	});


	$.ajax({
		type: 'GET',
		async: false,
		url: '/qcboundaries/getImageDetails',
		contentType: 'application/json; charset=utf-8'
	}).done(function (imageDetails) {
		session_images = imageDetails;
	}).fail(function () {
		alert("Something Went Wrong in callback(/qcboundaries/getImageDetails)!!");
	});


	//alert('hello');
	var bgImage = session_images[1];
	var fgImage = session_images[2];
	currentFileName = session_images[0];
	var pendingInpipeline  = session_images[3];

	console.log(pendingInpipeline)
    if(pendingInpipeline){
      $("#pipeLinecount").val(pendingInpipeline);
    }
    else{
      $("#pipeLinecount").val(0);
    }


	if (currentFileName == '404' || currentFileName == 'None' || !currentFileName) {
	     $("#pContainer").css("display", "block");
         $("#parentContainer").css("display", "none");
         $("#loadingIcon").css("display", "none");
		return;
	} else {
		//currentFileName = currentFileName.split("/")[2];
	}
	assignImageToCanvas(bgImage, fgImage);
	$("#currentImageSpanId").append(currentFileName.split("/")[2]);

	$('#opacityBar').change(function () {
		var val = $(this).val();
		if (val == 0) {
			val = 0.1;
		}
		if (toolObject.childCanvas == "false") {
			context.clearRect(0, 0, canvas.width, canvas.height);
			context.globalAlpha = val;
			//context.drawImage(opacityCanvas, 0, 0);
			context.drawImage(fgOriginalcanvas, 0, 0, canvas.width, canvas.height);
		} else {
			/* if (val == 0){
				val = 0.1;
			} */

			fgZoomBoxcontext.clearRect(0, 0, canvas.width, canvas.height);
			fgZoomBoxcontext.globalAlpha = val;
			var zoomTempCanvas = document.getElementById("paintcanvas-zoomTemp")
			fgZoomBoxcontext.drawImage(zoomTempCanvas, 0, 0, canvas.width, canvas.height);

//			var canvasZoomTemp = document.createElement('canvas'),
//				ctxcanvasZoomTemp = canvasZoomTemp.getContext('2d');
//
//			canvasZoomTemp.width = canvas.width;
//			canvasZoomTemp.height = canvas.height;
//			//ctxcanvasZoomTemp.globalAlpha = 1;
//			ctxcanvasZoomTemp.drawImage(fgZoomBoxcanvas, 0, 0);
//
//			var imageData = ctxcanvasZoomTemp.getImageData(0, 0, canvas.width, canvas.height);
//			var data = imageData.data;
//			var count = 0;
//			// iterate over all pixels
//			for (var i = 0, n = data.length; i < n; i += 4) {
//				var red = data[i];
//				var green = data[i + 1];
//				var blue = data[i + 2];
//				var alpha = data[i + 3];
//				//white
//
//				if (red > 0) {
//					//console.log("red-" + red + "-green-" + green + "-blue-" + blue + "-alpha-" + alpha);
//					//count = count + 1;
//				}
//				/* if(red > 0){
//	              //if(red == 255 && green == 255 && blue == 255 && alpha == 255){
//	            	//  if(red == 255 && green == 255 && blue == 255 ){
//	            	//data[i ] = 255;
//	              	data[i + 1] = 0;
//	              	data[i + 2] = 0;
//	              	data[i + 3] = 255;
//	              } */
//				//black
//				/* if(red == 0 && green == 0 && blue == 0 && alpha == 255){ */
//				if (red == 255 && green == 0 && blue == 0) {
//					/* data[i ] = 255;
//					data[i + 1] = 255;
//					data[i + 2] = 255; */
//					data[i + 3] = 255;
//				} else if (red == 0) {
//					//  data[i + 1] = 0;
//					// 	data[i + 2] = 0;
//					//data[i + 3] = 255;
//					//data[i + 3] = 0;
//				}
//			}
//			ctxcanvasZoomTemp.clearRect(0, 0, canvas.width, canvas.height);
//			ctxcanvasZoomTemp.globalAlpha = 1;
//
//			ctxcanvasZoomTemp.putImageData(imageData, 0, 0);
//
//			fgZoomBoxcontext.clearRect(0, 0, canvas.width, canvas.height);
//			fgZoomBoxcontext.globalAlpha = val;
//
//			//fgOriginalcontext.putImageData(imageData,0,0);
//
//			//context.drawImage(opacityCanvas, 0, 0);
//			fgZoomBoxcontext.drawImage(canvasZoomTemp, 0, 0, canvas.width, canvas.height);
		}
		currentGlobalAlpha = val;
		console.log(val);
	});

	$('#lineWidthBar').change(function () {
		var val = $(this).val();
		val = Math.round(val)
		console.log(val);
		toolObject.setLineWidth(val);
	});
	$(".wPaint-menu-icon-name-undo").append('<i style = "font-size : 20px;" class="fa fa-undo" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-redo").append('<i style = "font-size : 20px;" class="fa fa-redo" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-clear").append('<i style = "font-size : 20px;" class="fas fa-brush fa-rotate-180" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-zoom").append('<i style = "font-size : 20px;" class="fas fa-search-plus" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-zoom").append('<i style = "font-size : 20px;display:none;" class="fas fa-search-minus" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-applyZoom").append('<i style = "font-size : 20px;" class="fa fa-arrows-alt" aria-hidden="true"></i>');

	$(".wPaint-menu-icon-name-pencil").append('<i style = "font-size : 20px;" class="fa fa-pencil" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-eraser").append('<i style = "font-size : 20px;" class="fa fa-eraser" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-bucket").append('<i style = "font-size : 20px;" class="fas fa-fill-drip" aria-hidden="true"></i>');

	$(".wPaint-menu-icon-name-save").append('<i style = "font-size : 20px;" class="fa fa-save" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-reject").append('<i style = "font-size : 20px;" class="fa fa-remove" aria-hidden="true"></i>');
	$(".wPaint-menu-icon-name-signout").append('<i style = "font-size : 20px;" class="fa fa-sign-out" aria-hidden="true"></i>');
});