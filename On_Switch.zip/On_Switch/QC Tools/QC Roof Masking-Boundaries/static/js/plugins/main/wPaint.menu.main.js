var clearAndRebuild = false;
var zoomOutAlpha = 0.5;
(function ($) {

  // setup menu
  $.fn.wPaint.menus.main = {
    img: 'qcboundaries/static/js/plugins/main/img/icons-menu-main.png',
    items: {
      undo: {
        icon: 'generic',
        title: 'Undo',
        index: 0,
        callback: function () { this.undo(); }
      },
      redo: {
        icon: 'generic',
        title: 'Redo',
        index: 1,
        callback: function () { this.redo(); }
      },
      clear: {
    	  img: 'qcboundaries/static/js/plugins/main/img/Edit-clear.png',
        icon: 'generic',
        title: 'Clear',
        index: 2,
        callback: function () { this.clear(); }
      },
      zoom: {
    	  img: 'qcboundaries/static/js/plugins/main/img/zoomin.png',
          icon: 'activate',
          title: 'Pointer',
          index: 3,
          callback: function () { 
        	  //this.setZoom();
        	  this.initiateZoom();
        	  }
        },
        applyZoom: {
      	  img: 'qcboundaries/static/js/plugins/main/img/apply.png',
            icon: 'activate',
            title: 'applyZoom',
            index: 4,
            callback: function () { 
          	  this.applyChangedZoom();
          	  this.setMode('pencil'); }
          },
      
      pencil: {
        icon: 'activate',
        title: 'Pencil',
        index: 6,
        callback: function () { this.setMode('pencil'); }
      },
      eraser: {
        icon: 'activate',
        title: 'Eraser',
        index: 8,
        callback: function () { this.setMode('eraser'); }
      },
      bucket: {
        icon: 'activate',
        title: 'Bucket',
        index: 9,
        callback: function () { this.setMode('bucket'); }
      }
      /*,
      fillStyle: {
        title: 'Fill Color',
        icon: 'colorPicker',
        callback: function (color) { this.setFillStyle(color); }
      },*/
      /*lineWidth: {
        icon: 'select',
        title: 'Stroke Width',
        range: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        value: 2,
        callback: function (width) { this.setLineWidth(width); }
      }*//*,
      strokeStyle: {
        icon: 'colorPicker',
        title: 'Stroke Color',
        callback: function (color) { this.setStrokeStyle(color); }
      }*/      
    }
  };

  // extend cursors
  $.extend($.fn.wPaint.cursors, {
	  zoom: {path: 'qcboundaries/static/js/plugins/main/img/zoomin.png', left: 7, top: 7},
    applyZoom: {path: 'qcboundaries/static/js/plugins/main/img/pan.png', left: 0, top: 7},
    dropper:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-dropper.png', left: 0, top: 12},
    pencil:    {path: 'qcboundaries/static/js/plugins/main/img/cursor-pencil.png', left: 0, top: 11.99},
    bucket:    {path: 'qcboundaries/static/js/plugins/main/img/cursor-bucket.png', left: 0, top: 10},
    eraser1:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser1.png', left: 1, top: 1},
    eraser2:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser2.png', left: 2, top: 2},
    eraser3:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser3.png', left: 2, top: 2},
    eraser4:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser4.png', left: 3, top: 3},
    eraser5:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser5.png', left: 3, top: 3},
    eraser6:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser6.png', left: 4, top: 4},
    eraser7:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser7.png', left: 4, top: 4},
    eraser8:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser8.png', left: 5, top: 5 },
    eraser9:   {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser9.png', left: 5, top: 5},
    eraser10:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser11:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser12:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser13:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser14:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser15:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser16:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser17:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser18:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser19:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6},
    eraser20:  {path: 'qcboundaries/static/js/plugins/main/img/cursor-eraser10.png', left: 6, top: 6}

  });

  // extend defaults
  $.extend($.fn.wPaint.defaults, {
    mode:        'pencil',  // set mode
    lineWidth:   '5',       // starting line width
    //fillStyle:   '#ff0000', // starting fill style
    //strokeStyle: '#ff0000',  // start stroke style
	fillStyle:   'rgba(255, 0, 0, 1)', // starting fill style
    strokeStyle: 'rgba(255, 0, 0, 1)',
	childfillStyle:   'rgba(255, 1, 0, 1)', // starting fill style
    childstrokeStyle: 'rgba(255, 1, 0, 1)'
  });

  // extend functions
  $.fn.wPaint.extend({
    undoCurrent: -1,
    undoArray: [],
    undoFGOriginalArray: [],
    setUndoFlag: true,

    generate: function () {
    	if(!this.menus.all.main){
      this.menus.all.main = this._createMenu('main', {
        offsetLeft: this.options.menuOffsetLeft,
        offsetTop: this.options.menuOffsetTop
      });
    	}
    },

    _init: function () {
      // must add undo on init to set the first undo as the initial drawing (bg or blank)
      //this._addUndo();
      this.menus.all.main._setIconDisabled('clear', true);
      this.menus.all.main._setIconDisabled('applyZoom', true);
      this.menus.all.main._setIconDisabled('undo', true);
      this.menus.all.main._setIconDisabled('redo', true);
      this.menus.all.main._setIconDisabled('zoom', true);
      this.menus.all.main._setIconDisabled('applyZoom', true);
      this.menus.all.main._setIconDisabled('pencil', true);
	  	this.menus.all.main._setIconDisabled('eraser', true);
	  	this.menus.all.main._setIconDisabled('bucket', true);
	  	
	  	//this.menus.all.main._setIconDisabled('save', true);
	  	//this.menus.all.main._setIconDisabled('loadBg', true);
  	
    },

    setStrokeStyle: function (color) {
      this.options.strokeStyle = color;
      this.menus.all.main._setColorPickerValue('strokeStyle', color);
    },

    setLineWidth: function (width) {
      this.options.lineWidth = width;
      this.menus.all.main._setSelectValue('lineWidth', width);

      // reset cursor here based on mode in case we need to update cursor (for instance when changing cursor for eraser sizes)
      this.setCursor(this.options.mode);
    },

    setFillStyle: function (color) {
      this.options.fillStyle = color;
      this.menus.all.main._setColorPickerValue('fillStyle', color);
    },

    setCursor: function (cursor) {
      if (cursor === 'eraser') {
        this.setCursor('eraser' + this.options.lineWidth);
      }
    },

    /****************************************
     * undo / redo
     ****************************************/
    undo: function () {
    	if (this.childCanvas=="true" && childEditCount <= 1 ){
        	  return;
          }
      if (this.undoArray[this.undoCurrent - 1]) {
        this._setUndo(--this.undoCurrent);
        if (this.childCanvas=="true"){
      	  childEditCount --;
        }
      }

      this._undoToggleIcons();
    },
    
    initiateZoom: function (){
    	if (this.menus.all.main._isIconDisabled('zoom')) {
    		return;
    	}
    if(toolObject.childCanvas == "false"){

        zoomOutAlpha = currentGlobalAlpha;

    	this.menus.all.main._setIconDisabled('applyZoom', false);
    	this.menus.all.main._setIconDisabled('clear', false);
    	
    	this.menus.all.main._setIconDisabled('zoom', true);
    	this.menus.all.main._setIconDisabled('pencil', true);
    	this.menus.all.main._setIconDisabled('eraser', true);
    	this.menus.all.main._setIconDisabled('bucket', true);
    	
    	this.menus.all.main._setIconDisabled('save', true);
	  	this.menus.all.main._setIconDisabled('loadBg', true);
    	
	  	var centerX = canvas.width / 3;
	    var centerY = canvas.height / 3;
	    
	    var bgImageOriginalWidth = bgImage.width;
		var bgImageOriginalHeight	=	bgImage.height;
		
	    var imageAspectRatio = bgImageOriginalWidth/bgImageOriginalHeight;
		
	    var selectionWidth	=	canvas.width/3;
	    var selectionHeight	=	canvas.height/3;
	    
	    //selectionWidth = selectionWidth * imageAspectRatio;
	    
    	//theSelection = new Selection(200, 200, 200, 200);Math.round(posx), Math.round(posy)
	    theSelection = new Selection(Math.round(centerX), Math.round(centerY), Math.round(selectionWidth), Math.round(selectionHeight));
    	tempcontext.clearRect(0, 0, context.canvas.width, context.canvas.height);
    	tempcontext.globalAlpha = currentGlobalAlpha;
    	tempcontext.drawImage(this.canvasFgOriginal, 0, 0, context.canvas.width, context.canvas.height);
    	drawScene();
    	zoomBoxExists = "true";
    	 this.setMode('zoom');
    	
    }else{
    	
    	zoomBoxExists = "false";

        var canvas1 = document.createElement('canvas');
        var context1 = canvas1.getContext('2d');
        var currCtx	=	this.ctxZoomBoxFg;
        var currCanvas	=	this.canvasZoomBoxFg;


        $(".wPaint-menu-icon-name-pencil").addClass('active');
	    $(".wPaint-menu-icon-name-pencil").siblings('.active').removeClass('active');

        /*var img = new Image();
        img.src = currCanvas.toDataURL();*/
        
        // below modification of width, height is for canvas resizing during zoom
        var widthModified = (this.canvas.width*theSelection.w)/zoomboxStartWidth;
        var heightModified = (this.canvas.height*theSelection.h)/zoomboxStartHeight;
        
        widthModified = Math.round(widthModified);
        heightModified = Math.round(heightModified);
        
        var posxModified = (this.canvas.width*theSelection.x)/zoomboxStartWidth;
        var posyModified = (this.canvas.height*theSelection.y)/zoomboxStartHeight;
        
        posxModified = Math.round(posxModified);
        posyModified = Math.round(posyModified);
        
        canvas1.width = widthModified;
        canvas1.height = heightModified;
        context1.globalAlpha = zoomOutAlpha;
        context1.drawImage(this.ctxZoomTemp.canvas, 0, 0,widthModified,heightModified );
        var myData = context1.getImageData(0, 0, widthModified, heightModified);
        //document.getElementById('demo1').appendChild(canvas1);
        
       // var originalImageData = this.ctx.getImageData(0, 0, toolObject.width, toolObject.height);
        
        var originalImageData = this.ctxTemp.getImageData(0, 0, toolObject.width, toolObject.height);
        
        var childReturnRGB = getRGB(this.options.childstrokeStyle);
        
        var parentReturnRGB = getRGB(this.options.strokeStyle);
        
        for (row = 0; row < heightModified; row++){
      	  for (col = 0; col < widthModified; col++){
      	  //find current pixel
      		  index = (col + (row * myData.width)) * 4;
      		  r = myData.data[index + 0];
      		  g = myData.data[index + 1];
      		  b = myData.data[index + 2];
      		  a = myData.data[index + 3];
      		  var originalIndex = ((col + posxModified) + ( (row +posyModified) * toolObject.width)) * 4;
      		  var originalR	=	originalImageData.data[originalIndex];
      		  
      		  /*if(r > 0 ){
      			  //alert("orginal index-"  + originalIndex + "-original R-" + originalR + " index-"  + index + "- R-" + r );
      		  }*/
      		  
      		  /*if(originalR != r && (originalR ==0 || originalR == 127)){
      			  alert("orginal index-"  + originalIndex + "-original R-" + originalR + " index-"  + index + "- R-" + r );
      		  }*/
      		//if(r == 255 && g == 1 && b == 0 ){
      		  
      		  //commented below code 
      		  //if(r != originalR)
      		//if(r == childReturnRGB.red && g == childReturnRGB.green && b == childReturnRGB.blue )
      		{
      			//console.log("in red-" + r + "-green-" + g + "-blue-" + b + "-alpha-" + a);
      			//console.log("org red-" + originalImageData.data[originalIndex] + "-green-" + originalImageData.data[originalIndex+1] + "-blue-" +  originalImageData.data[originalIndex+2]  + "-alpha-" +  originalImageData.data[originalIndex+3] );
	      		  originalImageData.data[originalIndex] = parentReturnRGB.red;
	      		  originalImageData.data[originalIndex+1] = parentReturnRGB.green;
	      		  originalImageData.data[originalIndex+2] = parentReturnRGB.blue;
	      		  //if(a==255){
	      		  
	      			  originalImageData.data[originalIndex+3] = a;
	      		  //}
      		  }
      	  
      	  }
        }
        currCanvas.style.display="none";
        this.canvasZoomBoxBg.style.display="none";
        this.ctx.clearRect(0,0,toolObject.width, toolObject.height);
        this.ctx.putImageData(originalImageData, 0, 0);
        toolObject.childCanvas = "false";
        
        var canvas2 = document.createElement('canvas');
        var context2 = canvas2.getContext('2d');
        
        var widthx = (this.canvasFgOriginal.width/this.canvas.width)*widthModified;
        var heighty = (this.canvasFgOriginal.height/this.canvas.height)*heightModified;
        
        widthx = Math.round(widthx);
        heighty = Math.round(heighty);
        
        canvas2.width = widthx;
        canvas2.height = heighty;
        fgZoomBoxcontext.clearRect(0, 0, canvas.width, canvas.height);
			fgZoomBoxcontext.globalAlpha = 1;
			var zoomTempCanvas = document.getElementById("paintcanvas-zoomTemp")
			fgZoomBoxcontext.drawImage(zoomTempCanvas, 0, 0, canvas.width, canvas.height);
        
        context2.drawImage(fgZoomBoxcontext.canvas, 0, 0,canvas2.width,canvas2.height);
        
        myData = context2.getImageData(0, 0,canvas2.width,canvas2.height);
        //myData = context1.getImageData(0, 0, theSelection.w, theSelection.h);
        //document.getElementById('demo1').appendChild(canvas1);
        
       // var originalImageData = this.ctx.getImageData(0, 0, toolObject.width, toolObject.height);
        
        /*this.ctxFgOriginal.mozImageSmoothingEnabled = true;
        this.ctxFgOriginal.webkitImageSmoothingEnabled = true;
        this.ctxFgOriginal.msImageSmoothingEnabled = true;
        this.ctxFgOriginal.imageSmoothingEnabled = true;*/
        
        var fgoriginalImageData = this.ctxFgOriginal.getImageData(0, 0, this.ctxFgOriginal.canvas.width, this.ctxFgOriginal.canvas.height);
        
        var posx = (this.canvasFgOriginal.width/this.canvas.width)*posxModified;
        var posy = (this.canvasFgOriginal.height/this.canvas.height)*posyModified;
        
        posx = Math.round(posx);
        posy = Math.round(posy);
        
        for (row = 0; row < heighty; row++){
      	  for (col = 0; col < widthx; col++){
      	  //find current pixel
      		  index = (col + (row * myData.width)) * 4;
      		  r = myData.data[index + 0];
      		  g = myData.data[index + 1];
      		  b = myData.data[index + 2];
      		  a = myData.data[index + 3];
      		  var originalIndex = ((col + posx) + ( (row +posy) * this.ctxFgOriginal.canvas.width)) * 4;
      		  var originalR	=	fgoriginalImageData.data[originalIndex];
      		  var originalG	=	fgoriginalImageData.data[originalIndex+1];
      		  var originalB	=	fgoriginalImageData.data[originalIndex+2];
      		  var originalA	=	fgoriginalImageData.data[originalIndex+3];
      		  
      		  if(r > 0 ){
      			  //alert("orginal index-"  + originalIndex + "-original R-" + originalR + " index-"  + index + "- R-" + r );
      		  }
      		  
      		  /*if(originalR != r && (originalR ==0 || originalR == 127)){
      			  alert("orginal index-"  + originalIndex + "-original R-" + originalR + " index-"  + index + "- R-" + r );
      		  }*/
      		//if(r == 255 && g == 1 && b == 0 ){
      			
      		 if(r != originalR  )
      		//if(r == childReturnRGB.red && g == childReturnRGB.green && b == childReturnRGB.blue )
      		{
      			/*fgoriginalImageData.data[originalIndex] = r;
      			fgoriginalImageData.data[originalIndex+1] = 0;
      			fgoriginalImageData.data[originalIndex+2] = b;*/
      			
      			fgoriginalImageData.data[originalIndex] = parentReturnRGB.red;
      			fgoriginalImageData.data[originalIndex+1] = parentReturnRGB.green;
      			fgoriginalImageData.data[originalIndex+2] = parentReturnRGB.blue;
	      		  
      			//if(a==255){
      		/*if (a > 0)
    			  a = 255;*/
      				fgoriginalImageData.data[originalIndex+3] = a;
      			//}
      		}
      	  
      	  }
        }
        //currCanvas.style.display="none";
        //this.canvasZoomBoxBg.style.display="none";
//       this.ctxFgOriginal.clearRect(0,0,this.ctxFgOriginal.canvas.width, this.ctxFgOriginal.canvas.height);
        this.ctxFgOriginal.putImageData(myData, posx, posy);    
        
        
        this.canvas.removeEventListener('mousemove',canvasHandleMouseMove,false);
        this.canvas.removeEventListener('mousedown',canvasHandleMousedown,false);
        this.canvas.removeEventListener('mouseup',canvasHandleMouseup,false);
        document.getElementById('wPaint-menu-icon-name-zoom').style.backgroundImage="url(static/js/plugins/main/img/zoomin.png)";
        
        this.ctxTemp.clearRect(0, 0, this.ctxTemp.canvas.width, this.ctxTemp.canvas.height);
        
        this.menus.all.main._setIconDisabled('clear', false);
        this.setMode('pencil');
        
        while ( childEditCount > 0){
        	
        	this.undoCurrent --;
        	this.undoArray.pop();
        	this.undoFGOriginalArray.pop();
        	childEditCount--;
        }
        this._addUndo();
        
        this.menus.all.main._setIconDisabled('save', false);
	  	this.menus.all.main._setIconDisabled('loadBg', false);
		var input = document.getElementById("opacityBar");
		input.value = zoomOutAlpha;
		currentGlobalAlpha = zoomOutAlpha;

    }
    	
    },
    applyChangedZoom: function () {
    	
    	//$("#paintcanvas").imgAreaSelect({ x1: 120, y1: 90, x2: 280, y2: 210 });
    	//toolObject.generate.createCanvas("test");
    	
    	if (this.menus.all.main._isIconDisabled('applyZoom')&& !clearAndRebuild) {
    		return;
    	}
    	var temp_ctx;
    	if(toolObject.childCanvas == "false" || clearAndRebuild){
    		zoomBoxExists	=	"false";
	    	document.getElementById('wPaint-menu-icon-name-zoom').style.backgroundImage="url(static/js/plugins/main/img/zoomout.png)";
	    	
	    	this.menus.all.main._setIconDisabled('applyZoom', true);
	    	this.menus.all.main._setIconDisabled('zoom', false);
	    	this.menus.all.main._setIconDisabled('pencil', false);
	    	this.menus.all.main._setIconDisabled('eraser', false);
	    	this.menus.all.main._setIconDisabled('bucket', false);

	    	$(".wPaint-menu-icon-name-pencil").addClass('active');
	    	$(".wPaint-menu-icon-name-pencil").siblings('.active').removeClass('active');
	    	$(".fa-search-plus").css("display", "none");
			$(".fa-search-minus").css("display", "block");
	    	
                var widthInO = (this.canvasFgOriginal.width/this.canvas.width)*theSelection.w;
        var heightInO = (this.canvasFgOriginal.height/this.canvas.height)*theSelection.h;

		widthInO = Math.round(widthInO);
        heightInO = Math.round(heightInO);

		 var posx = (this.canvasFgOriginal.width/this.canvas.width)*theSelection.x;
        var posy = (this.canvasFgOriginal.height/this.canvas.height)*theSelection.y;

		 posx = Math.round(posx);
         posy = Math.round(posy);
	    	/*var name = "testbg";
	    	var newName = (name ? name.capitalize() : ''),
	        canvasName = 'canvas' + newName,
	        ctxName = 'ctx' + newName;*/
		  /*  if(!this.canvasZoomBoxFg){
		    	toolObject[canvasName] = document.createElement('canvas');
		    	toolObject[ctxName] = toolObject[canvasName].getContext('2d');
		    	toolObject['$' + canvasName] = $(toolObject[canvasName]);
		    
		    	toolObject['$' + canvasName]
		    .attr('class', 'wPaint-canvas' + (name ? '-' + name : ''))
		    .attr('width', toolObject.width + 'px')
		    .attr('height', toolObject.height + 'px')
		    .attr('style', 'border:1px solid #000000;')
		    .attr('id', 'paintcanvas' + (name ? '-' + name : ''))
		    .css({position: 'absolute', left: 0, top: 0});
		
		    	toolObject.$el.append(toolObject['$' + canvasName]);
		    	
		    	temp_ctx = toolObject[canvasName].getContext('2d');
		    	
	    	}
		    	else*/
		    	/*{
		    		temp_ctx = this.ctxZoomBoxBg;
		    	}*/
		    	this.ctxZoomBoxBg.canvas.width = canvas.width;
		    	this.ctxZoomBoxBg.canvas.height = canvas.height;
	    
	    //temp_ctx.clearRect(0, 0, temp_ctx.canvas.width, temp_ctx.canvas.height);
		    	this.ctxZoomBoxBg.drawImage(bgcanvas, theSelection.x, theSelection.y, theSelection.w, theSelection.h, 0, 0, canvas.width, canvas.height);
		    	
		    	zoomboxStartWidth = canvas.width;
		    	zoomboxStartHeight = canvas.height;
        //var vData = temp_canvas.toDataURL();
    	/*if(!this.canvasZoomBoxFg){
	    	var name = "test";
	    	var newName = (name ? name.capitalize() : ''),
	        canvasName = 'canvas' + newName,
	        ctxName = 'ctx' + newName;
	
	    	toolObject[canvasName] = document.createElement('canvas');
	    	toolObject[ctxName] = toolObject[canvasName].getContext('2d');
	    	toolObject['$' + canvasName] = $(toolObject[canvasName]);
	    
	    	toolObject['$' + canvasName]
	    .attr('class', 'wPaint-canvas' + (name ? '-' + name : ''))
	    .attr('width', toolObject.width + 'px')
	    .attr('height', toolObject.height + 'px')
	    .attr('style', 'border:1px solid #000000;')
	    .attr('id', 'paintcanvas' + (name ? '-' + name : ''))
	    .css({position: 'absolute', left: 0, top: 0});
	
	    	
	    	toolObject.$el.append(toolObject['$' + canvasName]);
	    	
	    	
	    	
	    	temp_ctx = toolObject[canvasName].getContext('2d');
	    	toolObject.childCanvas = "true";
	    	toolObject.generate();

	    	name = "zoomTemp";
	    	canvasName = 'canvas' + name;
	    	ctxName = 'ctx' + name;
	    	toolObject[canvasName] = document.createElement('canvas');
	    	toolObject[ctxName] = toolObject[canvasName].getContext('2d');
	    	toolObject['$' + canvasName] = $(toolObject[canvasName]);

	    	toolObject['$' + canvasName]
		    .attr('class', 'wPaint-canvas' + (name ? '-' + name : ''))
		    .attr('width', toolObject.width + 'px')
		    .attr('height', toolObject.height + 'px')
		    .attr('style', 'border:1px solid #000000;')
		    .attr('id', 'paintcanvas' + (name ? '-' + name : ''))
		    .css({position: 'absolute', left: 0, top: 0});

	    	toolObject['$' + canvasName] = $(toolObject[canvasName]);

    	}else*/
    	/*{
    		temp_ctx = this.ctxTest;
    	}*/
    	this.ctxZoomBoxFg.canvas.width = canvas.width;
    	this.ctxZoomBoxFg.canvas.height = canvas.height;
	    
    	//temp_ctx.clearRect(0, 0, temp_ctx.canvas.width, temp_ctx.canvas.height);
    	this.ctxZoomBoxFg.drawImage(tempcontext.canvas, theSelection.x, theSelection.y, theSelection.w, theSelection.h, 0, 0, canvas.width, canvas.height);
        //var vData = temp_canvas.toDataURL();
    	
    	this.ctxZoomTemp.canvas.width = canvas.width;
    	this.ctxZoomTemp.canvas.height = canvas.height;
	    
    	this.ctxZoomTemp.clearRect(0, 0, this.ctxZoomBoxFg.canvas.width, this.ctxZoomBoxFg.canvas.height);
    	this.ctxZoomTemp.drawImage(this.canvasFgOriginal,posx, posy, widthInO, heightInO, 0, 0, canvas.width, canvas.height);

    	this.canvasZoomBoxFg.style.display="initial";
        this.canvasZoomBoxBg.style.display="initial";
        
        var $canvas = $("#paintcanvas-zoomBoxFg");
        $canvas.bindMobileEvents();
    	
    	toolObject.childCanvas = "true";
    	//toolObject['$' + canvasName].on('mousedown', toolObject.generate);
    	//toolObject.generate();
    	while(this.undoFGOriginalArray.length  != this.undoCurrent+1){
    	     this.undoFGOriginalArray.pop();
    	}


	if(!clearAndRebuild){
    	this._addUndo();
	}
    	clearAndRebuild = false;
    }
    
    },

    redo: function () {
    	if (this.childCanvas=="true" && childEditCount < 1 ){
      	  return;
        }
      if (this.undoArray[this.undoCurrent + 1]) {
        this._setUndo(++this.undoCurrent);
        if (this.childCanvas=="true"){
    	  childEditCount ++;
      }

      }

      this._undoToggleIcons();
      

    },

    _addUndo: function () {

      //if it's not at the end of the array we need to repalce the current array position
      if (this.undoCurrent < this.undoArray.length - 1) {
        this.undoArray[++this.undoCurrent] = this.getImage(false);
        if (true){
        	this.undoFGOriginalArray[this.undoCurrent] = this.getImageFGOriginal(false);
        }
      }
      else { // owtherwise we push normally here
        this.undoArray.push(this.getImage(false));
        if (true){
        	this.undoFGOriginalArray.push(this.getImageFGOriginal(false));
        }
        //if we're at the end of the array we need to slice off the front - in increment required
        if (this.undoArray.length > this.undoMax) {
          this.undoArray = this.undoArray.slice(1, this.undoArray.length);
          if (true){
        	  this.undoFGOriginalArray = this.undoFGOriginalArray.slice(1, this.undoFGOriginalArray.length);
          }
        }
        //if we're NOT at the end of the array, we just increment
        else { this.undoCurrent++; }
      }

      //for undo's then a new draw we want to remove everything afterwards - in most cases nothing will happen here
      while (this.undoCurrent !== this.undoArray.length - 1) {
    	  this.undoArray.pop(); 
    	  if (this.childCanvas !="true"){
    		  this.undoFGOriginalArray.pop();
      }  
      }

      this._undoToggleIcons();
      this.menus.all.main._setIconDisabled('clear', false);
      
      if (this.childCanvas=="true"){
    	  childEditCount ++;
      }
//      alert("this.childCanvas : "+this.childCanvas);
//      alert("this.undoCurrent: "+this.undoCurrent);
//      alert("childEditCount  : "+childEditCount);
//      alert("undoFGOriginalArray Length : "+this.undoFGOriginalArray.length);
    },

    _undoToggleIcons: function () {
      var undoIndex = (this.undoCurrent > 0 && this.undoArray.length > 1) ? 0 : 1,
          redoIndex = (this.undoCurrent < this.undoArray.length - 1) ? 2 : 3;

      this.menus.all.main._setIconDisabled('undo', undoIndex === 1 ? true : false);
      this.menus.all.main._setIconDisabled('redo', redoIndex === 3 ? true : false);
    },

    _setUndo: function (undoCurrent) {
    	
      this.setImage(this.undoFGOriginalArray[undoCurrent], null, null, true);
      if (this.childCanvas !="true"){
    	  this.setImageFGOriginal(this.undoFGOriginalArray[undoCurrent], "fgOriginal", null, true);
      }
      else{
          this.setImageFGOriginal(this.undoFGOriginalArray[undoCurrent], "ZoomTemp", null, true);
      }
    },

    /****************************************
     * clear
     ****************************************/
    clear: function () {
    	
    	if (this.menus.all.main._isIconDisabled('clear')) {
    		return;
    	}
    	
      // only run if not disabled (make sure we only run one clear at a time)
    	
    	if (this.options.mode=='zoom' && zoomBoxExists == "true") {
    		
    		this.ctx.clearRect(0,0,toolObject.width, toolObject.height);
            //this.ctx.putImageData(originalImageData, 0, 0);
    		//this.ctx.drawImage(currCanvas, 0, 0,theSelection.w,theSelection.h );
    		this.ctx.drawImage(this.canvasFgOriginal, 0, 0,this.canvasFgOriginal.width,this.canvasFgOriginal.height,0,0, canvas.width, canvas.height);
            toolObject.childCanvas = "false";
            
            this.canvas.removeEventListener('mousemove',canvasHandleMouseMove,false);
            this.canvas.removeEventListener('mousedown',canvasHandleMousedown,false);
            this.canvas.removeEventListener('mouseup',canvasHandleMouseup,false);
            document.getElementById('wPaint-menu-icon-name-zoom').style.backgroundImage="url(static/js/plugins/main/img/zoomin.png)";
            this.menus.all.main._setIconDisabled('clear', true);

            this.menus.all.main._setIconDisabled('applyZoom', true);
	    	this.menus.all.main._setIconDisabled('zoom', false);

	    	this.menus.all.main._setIconDisabled('pencil', false);
	    	this.menus.all.main._setIconDisabled('eraser', false);
	    	this.menus.all.main._setIconDisabled('bucket', false);

	    	this.setMode('pencil');

	    	zoomBoxExists	=	"false";
            return;
    	}
      if (!this.menus.all.main._isIconDisabled('clear')) {
        if(toolObject.childCanvas == "false"){
        	var r = confirm("Do you want to clear all changes?");
        	if (r == true) {
        		this.ctx.clearRect(0, 0, this.width, this.height);
        		drawInitialFGImage();
        	}
        	else{
        		return;
        	}
        }
        else{
        	var r = confirm("Do you want to clear all changes?");
        	if (r == true) {
                clearAndRebuild = true;
                drawInitialFGImage();

                this.applyChangedZoom();
        		this.ctxZoomBoxFg.clearRect(0, 0, this.width, this.height);
                this.ctxZoomBoxFg.globalAlpha = currentGlobalAlpha;
        		this.ctxZoomBoxFg.drawImage(this.ctxZoomTemp.canvas,0,0);
        		this._addUndo();//Added only in else block  because inside if already we are doing this action.

        	}
        	else{
        		return;
        	}
        }

//        this._addUndo(); commented and added in else block.
        this.menus.all.main._setIconDisabled('clear', true);
      }
      
      //this.menus.all.main._setIconDisabled('save', true);
	  	//this.menus.all.main._setIconDisabled('loadBg', true);
    },

    /****************************************
     * rectangle
     ****************************************/
    _drawRectangleDown: function (e) { this._drawShapeDown(e); },

    _drawRectangleMove: function (e) {
      this._drawShapeMove(e);

      this.ctxTemp.rect(e.x, e.y, e.w, e.h);
      this.ctxTemp.stroke();
      this.ctxTemp.fill();
    },

    _drawRectangleUp: function (e) {
      this._drawShapeUp(e);
      this._addUndo();
    },

    /****************************************
     * ellipse
     ****************************************/
    _drawEllipseDown: function (e) { this._drawShapeDown(e); },

    _drawEllipseMove: function (e) {
      this._drawShapeMove(e);

      this.ctxTemp.ellipse(e.x, e.y, e.w, e.h);
      this.ctxTemp.stroke();
      this.ctxTemp.fill();
    },

    _drawEllipseUp: function (e) {
      this._drawShapeUp(e);
      this._addUndo();
    },

    /****************************************
     * line
     ****************************************/
    _drawLineDown: function (e) { this._drawShapeDown(e); },

    _drawLineMove: function (e) {
      this._drawShapeMove(e, 1);

      var xo = this.canvasTempLeftOriginal;
      var yo = this.canvasTempTopOriginal;
      
      if (e.pageX < xo) { e.x = e.x + e.w; e.w = e.w * - 1; }
      if (e.pageY < yo) { e.y = e.y + e.h; e.h = e.h * - 1; }
      
      this.ctxTemp.lineJoin = 'round';
      this.ctxTemp.beginPath();
      this.ctxTemp.moveTo(e.x, e.y);
      this.ctxTemp.lineTo(e.x + e.w, e.y + e.h);
      this.ctxTemp.closePath();
      this.ctxTemp.stroke();
    },

    _drawLineUp: function (e) {
      this._drawShapeUp(e);
      this._addUndo();
    },

    /****************************************
     * pencil
     ****************************************/
    _drawPencilDown: function (e) {
    	if (this.menus.all.main._isIconDisabled('pencil')) {
    		return;
    	}
    	var currCtx	=	this.ctx;
    	currCtx.lineJoin = 'round';
        currCtx.lineCap = 'round';
        currCtx.strokeStyle = this.options.strokeStyle;
        currCtx.fillStyle = this.options.strokeStyle;
        
    	if (this.childCanvas=="true"){
    		currCtx	=	this.ctxZoomBoxFg;
    		
    		currCtx.lineJoin = 'round';
    	      currCtx.lineCap = 'round';
    	      currCtx.strokeStyle = this.options.childstrokeStyle;
    	      currCtx.fillStyle = this.options.childfillStyle;
    	}
      
      
      //currCtx.strokeStyle = "rgba(255, 0, 0, 1)";
      //currCtx.fillStyle = "rgba(255, 0, 0, 1)";
      
      
      currCtx.lineWidth = this.options.lineWidth;
      
      currCtx.beginPath();
      currCtx.translate(toolObject.panX,toolObject.panY);

      currCtx.arc( e.pageX, e.pageY, this.options.lineWidth / 2, 0, Math.PI * 2, true);
      currCtx.closePath();
      currCtx.fill();
      
      var x = e.pageX;
      var y = e.pageY;
      
      //start the path for a drag
      currCtx.beginPath();
      currCtx.moveTo(e.pageX, e.pageY);
      //currCtx.moveTo(mouseXT, mouseYT);
      
      if (this.childCanvas !="true"){
       //
    	  
    	  var fgCanvasLineWidth = (this.canvasFgOriginal.width/this.canvas.width)*this.options.lineWidth;
    	  fgCanvasLineWidth = Math.round(fgCanvasLineWidth);
    	  
	      this.ctxFgOriginal.lineJoin = 'round';
	      this.ctxFgOriginal.lineCap = 'round';
	      this.ctxFgOriginal.strokeStyle = this.options.strokeStyle;
	      this.ctxFgOriginal.fillStyle = this.options.strokeStyle;
	      //this.ctxFgOriginal.lineWidth = this.options.lineWidth;
	      this.ctxFgOriginal.lineWidth = fgCanvasLineWidth;
	      
	      this.ctxFgOriginal.beginPath();
	      this.ctxFgOriginal.translate(toolObject.panX,toolObject.panY);
	      
	      var posx = (this.canvasFgOriginal.width/this.canvas.width)*e.pageX;
	      var posy = (this.canvasFgOriginal.height/this.canvas.height)*e.pageY;
	      
	      posx = Math.round(posx);
	      posy = Math.round(posy);
	        
	      /*document.getElementById('display1').innerHTML = "evt.pageX " + e.pageX + " -evt.pageY-"+e.pageY +"-posx-"+posx +"-eposy-"+posy;
	      
	      */
	      //this.ctxFgOriginal.arc( posx, posy, this.options.lineWidth / 2, 0, Math.PI * 2, true);
	      this.ctxFgOriginal.arc( posx, posy, fgCanvasLineWidth / 2, 0, Math.PI * 2, true);
	      this.ctxFgOriginal.closePath();
	      this.ctxFgOriginal.fill();
	      
	      this.ctxFgOriginal.beginPath();
	      this.ctxFgOriginal.moveTo(posx, posy);
	      //
      }
      else{
      var fgCanvasLineWidth = (this.ctxZoomTemp.canvas.width/this.canvas.width)*this.options.lineWidth;
    	  fgCanvasLineWidth = Math.round(fgCanvasLineWidth);

	      this.ctxZoomTemp.lineJoin = 'round';
	      this.ctxZoomTemp.lineCap = 'round';
	      this.ctxZoomTemp.strokeStyle = this.options.strokeStyle;
	      this.ctxZoomTemp.fillStyle = this.options.strokeStyle;
	      //this.ctxFgOriginal.lineWidth = this.options.lineWidth;
	      this.ctxZoomTemp.lineWidth = fgCanvasLineWidth;

	      this.ctxZoomTemp.beginPath();
	      this.ctxZoomTemp.translate(toolObject.panX,toolObject.panY);

	      var posx = (this.ctxZoomTemp.canvas.width/this.canvas.width)*e.pageX;
	      var posy = (this.ctxZoomTemp.canvas.height/this.canvas.height)*e.pageY;

	      posx = Math.round(posx);
	      posy = Math.round(posy);

	      /*document.getElementById('display1').innerHTML = "evt.pageX " + e.pageX + " -evt.pageY-"+e.pageY +"-posx-"+posx +"-eposy-"+posy;

	      */
	      //this.ctxFgOriginal.arc( posx, posy, this.options.lineWidth / 2, 0, Math.PI * 2, true);
	      this.ctxZoomTemp.arc( posx, posy, fgCanvasLineWidth / 2, 0, Math.PI * 2, true);
	      this.ctxZoomTemp.closePath();
	      this.ctxZoomTemp.fill();

	      this.ctxZoomTemp.beginPath();
	      this.ctxZoomTemp.moveTo(posx, posy);
      }
      
    },
    
    _drawPencilMove: function (e) {
    	if (this.menus.all.main._isIconDisabled('pencil')) {
    		return;
    	}
    	
    	var currCtx	=	this.ctx;
    	if (this.childCanvas=="true"){
    		currCtx	=	this.ctxZoomBoxFg;
    	}
    	//currCtx.setStrokeColor('#ff0000', '255');
    	//currCtx.globalAlpha = 1;
      currCtx.lineTo(e.pageX, e.pageY);
      currCtx.stroke();
      
      var posx = (this.canvasFgOriginal.width/this.canvas.width)*e.pageX;
      var posy = (this.canvasFgOriginal.height/this.canvas.height)*e.pageY;
      
      posx = Math.round(posx);
      posy = Math.round(posy);
      
      if (this.childCanvas !="true"){
	      this.ctxFgOriginal.lineTo(posx, posy);
	      this.ctxFgOriginal.stroke();
      }
      else{
         var posx1 = (this.ctxZoomTemp.canvas.width/this.canvas.width)*e.pageX;
          var posy1 = (this.ctxZoomTemp.canvas.height/this.canvas.height)*e.pageY;
          this.ctxZoomTemp.lineTo(posx1, posy1);
	      this.ctxZoomTemp.stroke();
      }
    },
    
    _drawPencilUp: function () {
    	
    	if (this.menus.all.main._isIconDisabled('pencil')) {
    		return;
    	}
    	
    	var currCtx	=	this.ctx;
    	var currCanvas	=	this.canvas;
    	if (this.childCanvas=="true"){
    		currCtx	=	this.ctxZoomBoxFg;
    		currCanvas	=	this.canvasZoomBoxFg;
    	}
      currCtx.closePath();
      
      if (this.childCanvas !="true"){
    	  this.ctxFgOriginal.closePath();
      }
      else{
         this.ctxZoomTemp.closePath();
      }
      
      this._addUndo();
      if (this.childCanvas=="false"){
      this.menus.all.main._setIconDisabled('save', false);
	  	this.menus.all.main._setIconDisabled('loadBg', false);
      }
      /*var image = new Image();
      image.id = "pic"
      image.src = currCanvas.toDataURL();
      image.style.width = theSelection.w + "px";
      image.style.height = theSelection.h + "px";
      document.getElementById('demo2').appendChild(image);*/
      
    
    },

    /****************************************
     * eraser
     ****************************************/
    _drawEraserDown: function (e) {
    	
    	if (this.menus.all.main._isIconDisabled('eraser')) {
    		return;
    	}
    	
    	var currCtx	=	this.ctx;
    	if (this.childCanvas=="true"){
    		currCtx	=	this.ctxZoomBoxFg;
    	}
      currCtx.save();
      currCtx.globalCompositeOperation = 'destination-out';
      
      if (this.childCanvas !="true"){
    	  this.ctxFgOriginal.save();
    	  this.ctxFgOriginal.globalCompositeOperation = 'destination-out';
      }
      else{

      this.ctxZoomTemp.save();
    	  this.ctxZoomTemp.globalCompositeOperation = 'destination-out';
      }
      
      this._drawPencilDown(e);
    },
    
    _drawEraserMove: function (e) {
    	
    	if (this.menus.all.main._isIconDisabled('eraser')) {
    		return;
    	}
    	
      this._drawPencilMove(e);
    },
    
    _drawEraserUp: function (e) {
    	
    	if (this.menus.all.main._isIconDisabled('eraser')) {
    		return;
    	}
    	
    	var currCtx	=	this.ctx;
    	if (this.childCanvas=="true"){
    		currCtx	=	this.ctxZoomBoxFg;
    	}
      this._drawPencilUp(e);
      currCtx.restore();
      
      if (this.childCanvas !="true"){
    	  this.ctxFgOriginal.restore();
      }
      else{
         	this.ctxZoomTemp.restore();
      }
      if (this.childCanvas=="false"){
      this.menus.all.main._setIconDisabled('save', false);
	  	this.menus.all.main._setIconDisabled('loadBg', false);
      }
    },

    /****************************************
     * bucket
     ****************************************/
    _drawBucketDown: function (e) {
    	
    	if (this.menus.all.main._isIconDisabled('bucket')) {
    		return;
    	}
    	var bucketFillStyle = this.options.fillStyle;
    	var currCtx	=	this.ctx;
    	if (this.childCanvas=="true"){
    		currCtx	=	this.ctxZoomBoxFg;
    		bucketFillStyle = this.options.childfillStyle;
    	}
      //var success	=	currCtx.fillArea(e.pageX, e.pageY, this.options.fillStyle);
    	var success	=	currCtx.fillArea(e.pageX, e.pageY, bucketFillStyle);
      
      var posx = (this.canvasFgOriginal.width/this.canvas.width)*e.pageX;
      var posy = (this.canvasFgOriginal.height/this.canvas.height)*e.pageY;
      
      posx = Math.round(posx);
      posy = Math.round(posy);
      
      if (this.childCanvas !="true"){
    	  this.ctxFgOriginal.fillArea(Math.round(posx), Math.round(posy), this.options.fillStyle);
      }
      else{
          var posx1 = (this.ctxZoomTemp.canvas.width/this.canvas.width)*e.pageX;
          var posy1 = (this.ctxZoomTemp.canvas.height/this.canvas.height)*e.pageY;
          this.ctxZoomTemp.fillArea(Math.round(posx1), Math.round(posy1), this.options.fillStyle);
      }
      if(success){
    	  this._addUndo();
      }
      
    }
  });
})(jQuery);
