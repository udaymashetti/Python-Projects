from __future__ import division

import traceback

from boto3.s3.transfer import TransferConfig
from botocore.exceptions import ClientError
import boto3
import io
import os
import base64
import json
import pymysql
import requests
from PIL import Image
import random
import time
# import custom scripts
from Logger import Logger
import CommonUtils as utils
import requests as req
import numpy as np
from flask import session

s3 = ''


class Qc:
    """Class contains helper methods"""

    CRITICAL = 50
    FATAL = CRITICAL
    ERROR = 40
    WARNING = 30
    WARN = WARNING
    INFO = 20
    DEBUG = 10
    NOTSET = 0
    pendinginqueue = 0

    def __init__(self):
        self.conn = ''
        self.properties = utils.getPropertyFile()
        self.logger = Logger()

    def log(self,level, message):
        # print("level is-",level)
        Logger.log(level,self.__class__.__name__, message)
        # print(message)

    def db_session(self):
        """Connect to db and return cursor object"""
        if self.conn == '' or (not self.conn.open):
            self.log(self.DEBUG, "Creating new DB connection")
            self.conn = pymysql.connect(host=self.properties.get('MYSQL', 'HOST'),
                                        user=self.properties.get('MYSQL', 'USER'),
                                        password=self.properties.get('MYSQL', 'PASSWORD'),
                                        db=self.properties.get('MYSQL', 'DB'),
                                        cursorclass=pymysql.cursors.DictCursor)
            self.conn.autocommit(True)
        if (not self.checkConn(self.conn)):
            #self.conn.close()
            self.conn = ''
            return self.db_session()

        return self.conn

    def checkConn(self,conn):
        sq = "SELECT NOW()"

        try:
            cursor = conn.cursor()
            cursor.execute(sq)
            return True
        except Exception as e:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,"DB Connection failed {}".format(desired_trace))
            return False

    def client_session(self):
        """Create a S3 client session and return a client session object"""
        # Create a s3 client
        global s3
        if s3 == '':
            s3 = boto3.client('s3',
                              aws_access_key_id=self.properties.get('AWS', 'ACCESS_KEY'),
                              aws_secret_access_key=self.properties.get('AWS', 'SECRET_KEY'))
        return s3

    def get_bg_img(self, uid_name):
        """Take file name, download, encode, send and delete from local"""
        self.log(self.DEBUG, "In get_bg_img Method UID {}".format(uid_name))
        s3 = self.client_session()
        image = None
        bg_rgb_img_server_filename = uid_name + '/graster/' + uid_name + '-grasterrgb.tif'
        bg_rgb_img_local_filename_tif = uid_name + '-grasterrgb.tif'
        bg_rgb_img_local_fileName_png = bg_rgb_img_local_filename_tif.replace('.tif', '.png')
        # download the selected image from S3 to local
        try:
            s3.download_file(Bucket=self.properties.get('S3', 'BUCKET'),
                             Key=bg_rgb_img_server_filename,
                             Filename=bg_rgb_img_local_filename_tif)

            bg_image = Image.open(bg_rgb_img_local_filename_tif)
            # .tif to .png conversion
            bg_image.save(bg_rgb_img_local_fileName_png, "JPEG", quality=100)
            bg_image.close()
            self.log(self.DEBUG,": Retrieved get_bg_img RGB Image for UID {}".format(uid_name))

            with open(bg_rgb_img_local_fileName_png, "rb") as imageFile:
                image = base64.b64encode(imageFile.read())
            os.remove(bg_rgb_img_local_fileName_png)
            os.remove(bg_rgb_img_local_filename_tif)
            if(image is not None):
                return image.decode('ascii')
            else:
                return None
        except Exception as e:

            desired_trace = traceback.format_exc()
            self.log(self.ERROR, ": Error in get_bg_img RGB Image for UID {} trace {}".format(uid_name,desired_trace))

            return None



    def get_fg_img(self, uid_name):
        """Take file name, download, encode, send and delete from local"""
        self.log(self.DEBUG, "In get_fg_img Method UID {}".format(uid_name))
        s3 = self.client_session()

        containfg = False
        fg_rgbmask_img_local_filename_tif=None
        try:
            fg_rgbmask_img_server_filename = uid_name + '/roofmasking/' + uid_name + '-autoroofmask.tif'
            fg_rgbmask_img_local_filename_tif = uid_name + '-autoroofmask.tif'
            # download the selected image from S3 to local
            s3.download_file(Bucket=self.properties.get('S3', 'BUCKET'),
                             Key=fg_rgbmask_img_server_filename,
                             Filename=fg_rgbmask_img_local_filename_tif)
            self.log(self.DEBUG,"Retrived get_fg_img Mask image from Bucket for UID {}".format(uid_name))
            containfg = True
        except Exception as e:
            # print('exception code', e.response['Error']['Code'])
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, ": Error in get_fg_img for UID {} trace {}".format(uid_name, desired_trace))
            if e.response['Error']['Code'] == "404":
                try:
                    fg_rgbmask_img_server_filename = uid_name + '/rpmasking/' + uid_name + '-autoroofmask.tif'
                    fg_rgbmask_img_local_filename_tif = uid_name + '-autoroofmask.tif'
                    # download the selected image from S3 to local
                    s3.download_file(Bucket=self.properties.get('S3', 'BUCKET'),
                                     Key=fg_rgbmask_img_server_filename,
                                     Filename=fg_rgbmask_img_local_filename_tif)
                    self.log(self.DEBUG,"Retrived Mask image for UID".format(uid_name))
                    containfg = True
                except Exception as exp:
                    pass
            else:
                # TODO: handle other errors there
                pass
        if containfg:
            try:
                self.log(self.DEBUG, "In get_fg_img Method before converting image  {}".format(fg_rgbmask_img_local_filename_tif))
                fg_image = Image.open(fg_rgbmask_img_local_filename_tif)
                # .tif to .png conversion
                fg_rgbmask_img_local_fileName_png = fg_rgbmask_img_local_filename_tif.replace('.tif', '.png')
                fg_image.save(fg_rgbmask_img_local_fileName_png, "JPEG", quality=100)
                fg_image.close()
                img = Image.open(fg_rgbmask_img_local_fileName_png)
                img = img.convert("RGBA")
                img.save(fg_rgbmask_img_local_fileName_png, "PNG")
                # open and encode the image to base64
                with open(fg_rgbmask_img_local_fileName_png, "rb") as imageFile:
                    image = base64.b64encode(imageFile.read())
                # Remove file once loaded
                os.remove(fg_rgbmask_img_local_fileName_png)
                os.remove(fg_rgbmask_img_local_filename_tif)
                return image.decode('ascii')
            except Exception as e:
                desired_trace = traceback.format_exc()
                self.log(self.ERROR,
                         ": Error in get_bg_img RGB Image for UID {} trace {}".format(uid_name, desired_trace))
                return None

        else:
            return None

    def put_fg_img(self, modified_masked_image, original_bg_image, originalFileName):
        """Take the modified masked_image, decode , save , upload to s3 bucket, delete from local"""
        self.log(self.DEBUG, "In put_fg_img Method UID {}".format(originalFileName))
        s3 = self.client_session()
        try:
            uid = originalFileName.split('/')[0]
            modified_masked_image_data = modified_masked_image.split(",")[1]
            original_bg_image_data = original_bg_image.split(",")[1]
            original_convdata = base64.b64decode(str(original_bg_image_data), ' /')
            org_bg_image = Image.open(io.BytesIO(original_convdata))
            org_bg_image = org_bg_image.convert("RGBA")
            bg_pixdata = org_bg_image.load()
            fileName_png = uid + '_qcroofmask.png'
            fileName_tif = uid + '_qcroofmask.tif'
            with open(fileName_png, "wb") as fh:
                convdata = base64.b64decode(str(modified_masked_image_data), ' /')
                fh.write(convdata)
            masked_image = Image.open(fileName_png)
            masked_image = masked_image.convert("I")
            mask_pixdata = masked_image.load()
            width, height = masked_image.size
            for y in range(height):
                for x in range(width):
                    if mask_pixdata[x, y] != 0:
                        mask_pixdata[x, y] = int(1)
                    else:
                        bg_pixdata[x, y] = (0, 0, 0, 255)
            masked_image.save(fileName_png, 'PNG')
            img = Image.open(fileName_png)
            img.save(fileName_tif)
            key = uid + '/qc1/' + uid + '-qcroofmask.tif'
            self.uploadFileS3(fileName_tif, key, self.properties.get('S3', 'BUCKET'))
            os.remove(fileName_tif)
            os.remove(fileName_png)
            key = uid + '/qc1/' + uid + '-maskedimage.tif'
            fileName_png = uid + '_maskedimage.png'
            fileName_tif = uid + '_maskedimage.tif'
            org_bg_image.save(fileName_png, 'PNG')
            img = Image.open(fileName_png)
            img.save(fileName_tif)
            self.uploadFileS3(fileName_tif, key, self.properties.get('S3', 'BUCKET'))
            os.remove(fileName_tif)
            os.remove(fileName_png)
            self.log(self.DEBUG,": Mask Image for uid {} saved in s3".format(uid))
            return "Image saved successfully"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,
                     ": Error in put_fg_img RGB Image for UID {} trace {}".format(originalFileName, desired_trace))
            return "Failed"

    def uploadFileS3(self, filename, key, bucket):
        config = TransferConfig(multipart_threshold=1024 * 25, max_concurrency=10,
                                multipart_chunksize=1024 * 25, use_threads=True)
        s3.upload_file(filename, bucket, key,
                       ExtraArgs={'ACL': 'public-read', 'ContentType': 'image/tif'},
                       Config=config,
                       Callback=self.ProgressPercentage(filename)
                       )

    def ProgressPercentage(self, filename):
        print('file in ProgressPercentage is ', filename)

    def modify_bg_img(self, mask_pixdata, original_bg_image, bucketFilePath):
        """Take the modified image, decode , save , upload to s3 bucket, delete from local"""
        self.log(self.DEBUG, "In modify_bg_img Method original_bg_image {}".format(original_bg_image))
        try:
            original_bg_image_data = original_bg_image.split(",")[1]
            convdata = base64.b64decode(str(original_bg_image_data), ' /')
            org_bg_image = Image.open(io.BytesIO(convdata))
            org_bg_image = org_bg_image.convert("RGBA")
            bg_pixdata = org_bg_image.load()
            width, height = org_bg_image.size
            count = 0
            for y in range(height):
                for x in range(width):
                    if mask_pixdata[x, y] == int(0):
                        bg_pixdata[x, y] = (0, 0, 0, 255)
            uid = bucketFilePath.split('/')[0]
            key = uid + '/qc1/' + uid + '-maskedimage.tif'
            b = io.BytesIO()
            org_bg_image.save(b, 'TIFF')
            image_bytes = b.getvalue()
            s3.put_object(Body=image_bytes,
                          Bucket=self.properties.get('S3', 'BUCKET'),
                          Key=key)
        except Exception as e:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,
                     ": Error in modify_bg_img RGB Image for original_bg_image {} trace {}".format(original_bg_image, desired_trace))
        return 'success'

    def getUserBasedDetails(self, email, rootvalue):
        try:
            url = rootvalue + "qctool/getUserBasedDetails?email=" + email + "&jsonFlag=True"
            alldetails = requests.request("GET", url)
            return alldetails.json()
        except Exception:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, ": Error in getUserBasedDetails {}".format(desired_trace))

    def getPendingIdsCount(self):
        self.pendinginqueue = 0
        # Umcomment below code when they start sending count in COUNT_SERVICE_URL
        try:
            url = self.properties.get('DB_SERVICE', 'COUNT_SERVICE_URL')

            dbservice1_response = requests.request("GET", url)
            alldetails = dbservice1_response.json()
            if 'pendinginqueue' in alldetails:
                self.pendinginqueue = int(alldetails['pendinginqueue'])
                self.log(self.DEBUG, "Pending In Queue Are {}".format(self.pendinginqueue))
        except Exception:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, ": Error in put_fg_img RGB Image for trace {}".format(desired_trace))

    def onswitchdb_get_uid(self, username):
        """return uid where status = inprogress"""
        uid = None
        self.log(self.DEBUG, "In onswitchdb_get_uid Method UID")
        conn = self.db_session()
        cursor = conn.cursor()
        inProgresslist = 0
        try:
            self.getPendingIdsCount()
            inProgresslist += self.pendinginqueue
            # Release locked images if period exceeds 5 mins
            sql = "SELECT Image_Key FROM onswitchdb.XX_QCTOOL_LOG WHERE Status in ('IN-PROGRESS') AND (now()- Last_Updated_On) >=300  and workflow_state='QC_BOUNDARIES'"
            cursor.execute(sql)
            response = cursor.fetchall()
            cursor.close()
            uid_list = []
            for i in range(len(response)):
                uid_list.append(response[i]['Image_Key'])
            if len(uid_list) > 0:
                inProgresslist += len(uid_list) - 1
                uid = random.choice(uid_list)
                self.log(self.DEBUG,"Retrieved UID {} from database".format(uid))
            # else :
            #     inProgresslist = self.pendinginqueue


        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,"UID retrieval from database failed with error {} trace {}".format(ex,desired_trace))
            # conn.rollback()

        return uid,inProgresslist

    def onswitchdb_update(self, uid, status):
        self.log(self.DEBUG, "In onswitchdb_update Method UID {}".format(uid))
        """Take uid,status and update the status column of the table"""
        records = 0
        try:
            sql = "UPDATE onswitchdb.XX_QCTOOL_LOG SET Status = '" + status + "',Last_Updated_On='" + time.strftime(
            '%Y-%m-%d %H:%M:%S') + "' WHERE Image_Key = '" + uid + "' and workflow_state='QC_BOUNDARIES' "
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            cursor.close()
            conn.commit()
            self.log(self.INFO,"Record for UID {} in XX_QCTOOL_LOG updated successfully as {}".format(uid, status))


        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "UID onswitchdb_update failed with uid {} trace {}".format(uid, desired_trace))
        return records


    def onswitchdb_insert(self, uid, status, username):
        self.log(self.DEBUG, "In onswitchdb_insert Method UID {}".format(uid))
        """Take uid, status and insert as a row in the data base"""
        records = 0
        try:
            sql = "INSERT INTO onswitchdb.XX_QCTOOL_LOG(Image_Key,Status,User,Engaged,workflow_state,created_on) VALUES ('" + uid + "','" + status + "','" + username + "'," \
                                                                                                                                                                        "'YES','QC_BOUNDARIES','" + time.strftime(
                '%Y-%m-%d %H:%M:%S') + "')"
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            cursor.close()
            conn.commit()
            self.log(self.DEBUG,"Record inserted for UID {} with status {} count {}".format(uid, status, records))
            # return records

        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "UID onswitchdb_insert failed with uid {} trace {}".format(uid, desired_trace))
        return records

    def onswitchdb_insert_tracking(self, uid, username,comments):
        self.log(self.DEBUG, "In onswitchdb_insert_tracking Method UID {}".format(uid))
        records = 0
        """Take uid, status and insert as a row in the data base"""
        try:
            sql = "INSERT INTO onswitchdb.XX_QCTOOL_LOG_TRACKING(image_key,user,current_step,started_on,comments) VALUES ('" + uid + "','" + username + "'," \
                                                                                                                                               "'QC_BOUNDARIES','" + time.strftime(
                '%Y-%m-%d %H:%M:%S') + "','" + comments + "')"
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            cursor.close()
            conn.commit()
            self.log(self.DEBUG,"Records in XX_QCTOOL_LOG_TRACKING inserted for UID {} with count {} comment {}".format(uid, records,comments))
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "UID onswitchdb_insert_tracking failed with uid {} trace {}".format(uid, desired_trace))

        return records


    def onswitchdb_update_tracking(self, uid):
        self.log(self.DEBUG, "In onswitchdb_update_tracking Method UID {}".format(uid))
        records = 0
        try:
            """Take uid,status and update the status column of the table"""
            sql = "UPDATE onswitchdb.XX_QCTOOL_LOG_TRACKING SET Last_Updated_On='" + time.strftime(
                '%Y-%m-%d %H:%M:%S') + "' WHERE " \
                                       "Image_Key = '" + uid + "' and current_step='QC_BOUNDARIES' and Last_Updated_On is null"
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            cursor.close()
            conn.commit()
            self.log(self.DEBUG,"Record for UID {} in XX_QCTOOL_LOG_TRACKING updated successfully count {}".format(uid,records))


        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "UID onswitchdb_update_tracking failed with uid {} trace {}".format(uid, desired_trace))
        return records

    def db_service1_get_uid(self):
        self.log(self.DEBUG, "In db_service1_get_uid Method UID ")
        """Send a request to db service and get a json and return the uuid"""
        uuid = None

        try:

            url = self.properties.get('DB_SERVICE', 'ELECT_SERVICE_URL')
            dbservice1_response = requests.request("GET", url)
            # dbservice1_data = json.loads(dbservice1_response.text)
            alldetails = dbservice1_response.json()
            # if 'pendinginqueue' in  alldetails:
            #     self.pendinginqueue = int(alldetails['pendinginqueue'])
            #     self.log(self.DEBUG , "Pending In Queue Are {}".format(self.pendinginqueue))

            dbservice1_data = alldetails['pipelinedetails']

            if (dbservice1_data is None):
                return None
            for i in range(len(dbservice1_data['processlogs'])):
                if dbservice1_data['processlogs'][i]['stepName'] == 'gvector' and dbservice1_data['processlogs'][i][
                    'baseStatus']:
                    uuid = dbservice1_data['processlogs'][i]['uuid']
            self.log(self.DEBUG,"Retrieved UID {} from elect service".format(uuid))

        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,"UID db_service1_get_uid failed  trace {}".format( desired_trace))
        return str(uuid)

    def db_service2_process_log(self, uuid, stepName, baseStatus):
        self.log(self.DEBUG, "In db_service2_process_log Method UID {}".format(uuid))
        try:
            """Receive the uuid,stepName, baseStatus parameters and update the db service accordingly """
            url = self.properties.get('DB_SERVICE', 'PROCESS_SERVICE_URL')
            payload = {
                "uuid": uuid,
                "stepName": stepName,
                "baseStatus": baseStatus
            }
            headers = {'content-type': 'application/json'}
            r = requests.post(url, data=json.dumps(payload), headers=headers)
            if eval(str(r.content)) == 'success':
                self.log(self.DEBUG,"Process log update for UID {} with step name {}, status {} successful".format(uuid,stepName,baseStatus))
                return "success"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,"UID db_service2_process_log failed  trace {} {}".format(uuid, desired_trace))


    def db_service3_catalog(self, uuid, stepName, bucket, s3path):
        self.log(self.DEBUG, "In db_service3_catalog Method UID {}".format(uuid))
        """Takes uuid, stepName, bucket, s3path, updates the db service with this information once the image is saved"""
        try:
            url = self.properties.get('DB_SERVICE', 'CATALOG_SERVICE_URL')
            payload = {
                "uuid": uuid,
                "stepName": stepName,
                "bucket": bucket,
                "s3path": s3path
            }
            headers = {'content-type': 'application/json'}
            r = requests.post(url, data=json.dumps(payload), headers=headers)
            if eval(str(r.content)) == 'success':
                return "success"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,"UID db_service3_catalog failed {}  trace {}".format( uuid,desired_trace))

    def db_service4_publish(self, uuid):
        self.log(self.DEBUG, "In db_service4_publish Method UID {}".format(uuid))
        try:
            """Takes uuid, updates db service that qc1 and qc2 are completed"""
            url = self.properties.get('DB_SERVICE', 'PUBLISH_SERVICE_URL')
            url = url + uuid
            r = requests.post(url)
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,"UID db_service4_publish failed {} trace {}".format( uuid,desired_trace))
        return "success"

    def userSecurityCheck(self, session):
        self.log(self.DEBUG, "Inside userSecurityCheck  Method..")
        # print("Inside userSecurityCheck  Method..")
        if 'username' in session and 'token2' in session:
            self.log(self.DEBUG, "username and  token2  are in session..")
            # print("username and  token2  are in session..")
            token2 = session['token2']
            if token2 is not None:
                email = self.validateSession(token2)
                if email is not '' and email is not 'error':
                    self.log(self.DEBUG, "TvalidateSessionoken validated Successfully")
                    # print("Token validated Successfully")
                    if 'applicationList' in session:
                        self.log(self.DEBUG, "applicationList is in session")
                        # print("applicationList is in session")
                        if 'qcboundaries' in session['applicationList']:
                            self.log(self.DEBUG, "qcboundaries is in applicationList")
                            # print("qctool is in applicationList")
                            return True
                        else:
                            self.log(self.DEBUG, "qcboundaries is not in applicationList")
                            return False
                    else:
                        self.log(self.DEBUG, "applicationList is not in session")
                        return False
                else:
                    self.log(self.DEBUG, "email is  '' or  error : {}".format(email))
                    # print("email return is", email)
                    return False
            else:
                self.log(self.DEBUG, "Token 2 is None ")
                return False
        else:
            self.log(self.DEBUG, "username and  token2  are not in session..")
            return False

    def refreshToken(self, refresh_token):
        self.log(self.DEBUG, "Inside refreshToken Method.. refresh_token is : {}".format(refresh_token))
        client_id = None
        client_secret = None
        CLIENT_SECRET_FILE = self.properties.get('GSign-In', 'Client_Secret')
        # print(CLIENT_SECRET_FILE)
        with open(CLIENT_SECRET_FILE, 'r') as f:
            distros_dict = json.load(f)

        if 'web' in distros_dict:
            web = distros_dict['web']
            if 'client_id' in web:
                client_id = web['client_id']
            if 'client_secret' in web:
                client_secret = web['client_secret']

        params = {
            "grant_type": "refresh_token",
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": refresh_token
        }

        authorization_url = "https://www.googleapis.com/oauth2/v4/token"

        r = requests.post(authorization_url, data=params)

        if r.ok:
            self.log(self.DEBUG, "Access Token refreshed Successfully . The new Access token is : {}".format(
                r.json()['access_token']))
            print("Access Token refreshed Successfully . The new Access token is : {}".format(r.json()['access_token']))
            return r.json()['access_token']
        else:
            self.log(self.DEBUG, "Access Token is not refreshed . Returning None")
            print("Access Token is not refreshed . Returning None")
            return None

    def validateSession(self, token2):
        # print("Inside validateSession")
        email = ''
        try:
            # CLIENT_ID = '39080003413-ld4rv4c123cvrmchpfn6s99lg221sod6.apps.googleusercontent.com'
            # Specify the CLIENT_ID of the app that accesses the backend:
            # idinfo = id_token.verify_oauth2_token(token, requests.Request(), CLIENT_ID)

            # print('access token=',token2)
            url = 'https://oauth2.googleapis.com/tokeninfo?access_token=' + token2
            # params = {'access_token': token2}
            r = req.get(url=url, params=None)

            data = r.json()
            if 'email' in data:
                self.log(self.DEBUG, "The Email Id form google Api is {}".format(data['email']))
                # print("The Email Id form google Api is {}".format(data['email']))
                email = data['email']
                # print('email is ', email)
            elif 'error' in data:
                self.log(self.DEBUG, "The session is either Expired/Signed out  for token {}".format(session['token2']))
                # print("The session is either Expired/Signed out  for token {}".format(session['token2']))
                if 'token2' in session:
                    self.log(self.DEBUG, "The session Expired for token {}".format(session['token2']))
                    # print("The session Expired for token {}".format(session['token2']))
                    if 'refreshToken' in session:
                        self.log(self.DEBUG, "Getting refresh Token {}")
                        # print("Getting refresh Token ")
                        access_token = self.refreshToken(session['refreshToken'])
                        self.log(self.DEBUG, "The New Access  token generated is {}".format(access_token))
                        # print("The New Access  token generated is {}".format(access_token))
                        if access_token is not None:
                            session['token2'] = access_token
                            email = self.validateSession(access_token)
                            # print("Here It is ",email)
        except ValueError:
            # Invalid token
            self.log(self.ERROR, "The value error {}".format(ValueError))
            # print('the value error',ValueError)
            pass
        except KeyError:
            self.log(self.ERROR, "The KeyError  {}".format(KeyError))
            # print('error')
            return 'error'
        # print("before return ",email)
        return email
