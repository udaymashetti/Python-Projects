# import libraries
import os
import logging
import time
import datetime
from configparser import ConfigParser


class Logger:
    """Class handles logging"""
    loghandler = logging.getLogger("QCTOOL")
    loghandler.setLevel(logging.DEBUG)
    logfilepath = ""
    fh = ""


    def __init__(self):
        self.today = time.strftime('%Y%m%d')
        self.hour = datetime.datetime.now().hour
        self.formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(user)s - %(message)s')
        # method call
        self.initializeLogger()

    def initializeLogger(self):
        """Take input from properties file and return a log handler object"""
        cfg = ConfigParser()
        property_file_path = os.path.join(os.curdir, "config", "properties.ini")
        cfg.read(property_file_path)
        logdirectory = str(cfg.get("LOG", "LOG_DIRECTORY"))
        logfilename = "QcBoundaries-{}{}{}.log".format(self.today, self.hour, datetime.datetime.now().minute)
        Logger.logfilepath = os.path.join(logdirectory, logfilename)

        print('exists path-', logdirectory)
        if(not os.path.exists(logdirectory)):
            os.makedirs(logdirectory)

        print('exists path- after', os.path.exists(logdirectory))
            #print(logfilepath)
        self.defineLoggerProperties("D", Logger.logfilepath, self.formatter)
        return self.loghandler

    def defineLoggerProperties(self, logFileType, logFileName, formatter):
        Logger.fh = logging.FileHandler(logFileName)
        Logger.fh.setFormatter(formatter)
        if logFileType == 'D':
            Logger.fh.setLevel(logging.DEBUG)
        else:
            Logger.fh.setLevel(logging.ERROR)
        Logger.loghandler.addHandler(Logger.fh)

    @staticmethod
    def log(level,className, message):
        # Logger.loghandler.debug(message, extra={'user':className})
        # print('lvel is',level)
        Logger.loghandler.log(level,message, extra={'user':className})

    @staticmethod
    def closelog():
        #print(Logger.fh)
        Logger.loghandler.removeHandler(Logger.fh)
        del Logger.loghandler, Logger.fh
        logging.shutdown()


if __name__ == "__main__":
    log = Logger()
    Logger.closelog()


