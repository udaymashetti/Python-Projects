# import libs
from __future__ import division

import traceback

import time
import boto3
import os
import base64
import json
import pymysql
import requests
from PIL import Image
# import custom scripts
from Logger import Logger
import CommonUtils as utils
import requests as req
from flask import session

s3 = ''


class Qc:
    """Class contains helper methods"""
    CRITICAL = 50
    FATAL = CRITICAL
    ERROR = 40
    WARNING = 30
    WARN = WARNING
    INFO = 20
    DEBUG = 10
    NOTSET = 0

    def __init__(self):
        self.conn = ''
        self.properties = utils.getPropertyFile()
        self.logger = Logger()

    def log(self, level, message):
        Logger.log(level, self.__class__.__name__, message)
        # print(message)

    def db_session(self):
        """Connect to db and return cursor object"""
        if self.conn == '' or (not self.conn.open):
            self.log(self.DEBUG, "Creating new DB Connection ")
            self.conn = pymysql.connect(host=self.properties.get('MYSQL', 'HOST'),
                                        user=self.properties.get('MYSQL', 'USER'),
                                        password=self.properties.get('MYSQL', 'PASSWORD'),
                                        db=self.properties.get('MYSQL', 'DB'),
                                        cursorclass=pymysql.cursors.DictCursor)
            self.conn.autocommit(True)
        if (not self.checkConn(self.conn)):
            # self.conn.close()
            self.conn = ''
            return self.db_session()
        return self.conn
    def checkConn(self,conn):
        sq = "SELECT NOW()"

        try:
            cursor = conn.cursor()
            cursor.execute(sq)
            return True
        except Exception as e:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,"DB Connection failed {}".format(desired_trace))
            return False

    def client_session(self):
        """Create a S3 client session and return a client session object"""
        # Create a s3 client
        global s3
        if s3 == '':
            s3 = boto3.client('s3',
                              aws_access_key_id=self.properties.get('AWS', 'ACCESS_KEY'),
                              aws_secret_access_key=self.properties.get('AWS', 'SECRET_KEY'))
        return s3

    def get_bg_img(self, uid_name):
        """Take file name, download, encode, send and delete from local"""
        self.log(self.DEBUG, "In get_bg_img Method UID {}".format(uid_name))
        try:
            s3 = self.client_session()
            bg_rgb_image_server_filename = str(uid_name) + '/qc1/' + str(uid_name) + '-maskedimage.tif'
            bg_rgb_image_local_filename_tif = uid_name + '-maskedimage.tif'
            # download the selected image from S3 to local
            s3.download_file(Bucket=self.properties.get('S3', 'BUCKET'),
                             Key=bg_rgb_image_server_filename,
                             Filename=bg_rgb_image_local_filename_tif)
            # open and encode the image to base64
            bg_rgb_image_local_fileName_png = bg_rgb_image_local_filename_tif.replace('.tif', '.png')
            bg_image = Image.open(bg_rgb_image_local_filename_tif)
            bg_image.save(bg_rgb_image_local_fileName_png, "PNG", quality=100)
            bg_image.close()
            with open(bg_rgb_image_local_fileName_png, "rb") as imageFile:
                image = base64.b64encode(imageFile.read())
            # Remove file once loaded
            os.remove(bg_rgb_image_local_filename_tif)
            os.remove(bg_rgb_image_local_fileName_png)
            self.log(self.DEBUG,"Retrieved RGB Image for UID {}".format(uid_name))
            return image.decode('ascii')
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, ": Error in get_bg_img RGB Image for UID {} trace {}".format(uid_name, desired_trace))
            return None

    def get_roof_plane_masks(self, uid_name):
        """Take each_roofplane_file name, download, encode, send and delete from local"""
        self.log(self.DEBUG, "In get_roof_plane_masks Method UID {}".format(uid_name))
        s3 = self.client_session()
        roofPlanesDict = {}
        roofPlanesTypeDict = {}
        try:
            folderName = uid_name + '/rtcai/autoroofclass/'
            response = s3.list_objects(Bucket=self.properties.get('S3', 'BUCKET'),
                                       Prefix=folderName)

            for content in response.get('Contents', []):
                each_roofplane_file = content.get('Key')
                if not each_roofplane_file.endswith('.tif'):
                    continue
                each_roofplane_server_filename = each_roofplane_file
                each_roofplane_local_filename_tif = each_roofplane_file.split('/')[-1]
                s3.download_file(Bucket=self.properties.get('S3', 'BUCKET'),
                                 Key=each_roofplane_server_filename,
                                 Filename=each_roofplane_local_filename_tif)
                each_roofplane_localfilename_png = each_roofplane_local_filename_tif.replace('.tif', '.png')
                bg_image = Image.open(each_roofplane_local_filename_tif)
                pixdata = bg_image.load()
                width, height = bg_image.size
                image_type = 0
                for y in xrange(height):
                    for x in xrange(width):
                        if pixdata[x, y] != 0:
                            image_type = pixdata[x, y]
                            break
                    else:
                        continue
                    break
                roofPlanesTypeDict[each_roofplane_local_filename_tif] = image_type
                bg_image.save(each_roofplane_localfilename_png, "PNG", quality=100)
                with open(each_roofplane_localfilename_png, "rb") as imageFile:
                    image = base64.b64encode(imageFile.read())
                roofPlanesDict[each_roofplane_local_filename_tif] = image.decode('ascii')
                self.log(self.DEBUG,"Retrieved Roof plane mask Images for UID {}".format(uid_name))
                os.remove(each_roofplane_localfilename_png)
                os.remove(each_roofplane_local_filename_tif)
        except Exception as e:

            desired_trace = traceback.format_exc()
            self.log(self.ERROR, ": Error in get_roof_plane_masks Image for UID {} trace {}".format(uid_name,desired_trace))

        return roofPlanesDict,roofPlanesTypeDict

    def get_bg_img_type(self, raw_image):
        """Take file name, download, encode, send and delete from local"""
        s3 = self.client_session()
        roofPlanesTypeDict = {}
        try:
            raw_image = raw_image.replace('masked_images', 'roof_planes')
            folderName = raw_image.split('.')[0] + '/'
            response = s3.list_objects(Bucket='sample-pipeline-version2', Prefix=folderName)

            for content in response.get('Contents', []):
                file = content.get('Key')
                key = file
                filename = file.split('/')[4]
                s3.download_file(Bucket=self.properties.get('S3', 'BUCKET'),
                                 Key=key,
                                 Filename=filename)

                img = Image.open( filename)
                pixdata = img.load()
                width, height = img.size
                image_type = 0
                for y in xrange(height):
                    for x in xrange(width):
                        if pixdata[x, y] != 0:
                            image_type = pixdata[x, y]
                roofPlanesTypeDict[filename] = image_type
                self.log(self.DEBUG,"Retrieved roof plane type for roof plane mask image for image {}".format(raw_image))
        except Exception as e:

            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "Error in get_bg_img_type trace {}".format(desired_trace))

        return roofPlanesTypeDict

    def change_roof_type(self, uid_name, each_roofplane_name, each_roofplane_type_value, index):
        """Take the modified image, decode , save , upload to s3 bucket, delete from local"""
        self.log(self.DEBUG, "In change_roof_type uid {} ".format(uid_name))
        s3 = self.client_session()
        try:
            each_roofplane_server_filename = uid_name + '/rtcai/autoroofclass/' + each_roofplane_name
            each_roofplane_local_filename = uid_name + each_roofplane_name

            print("server file-" ,each_roofplane_server_filename)
            print("bucket",self.properties.get('S3', 'BUCKET'))
            print("local file",each_roofplane_local_filename)
            # download the selected image from S3 to local
            s3.download_file(Bucket=self.properties.get('S3', 'BUCKET'),
                             Key=each_roofplane_server_filename,
                             Filename=each_roofplane_local_filename)
            # open and encode the image to base64
            img = Image.open(each_roofplane_local_filename)
            pixdata = img.load()
            width, height = img.size
            for y in xrange(height):
                for x in xrange(width):
                    if pixdata[x, y] != 0:
                        pixdata[x, y] = int(each_roofplane_type_value)

            # img.save(each_roofplane_local_filename, "PNG")
            img.save(each_roofplane_local_filename, "TIFF", quality=100)
            each_roofplane_server_filename = uid_name + "/qc2/qcroofclass/" + uid_name + '-qc2-roofplane-' + str(index) + '.tif'
            s3.upload_file(Filename=each_roofplane_local_filename,
                           Bucket=self.properties.get('S3', 'BUCKET'),
                           Key=each_roofplane_server_filename)
            # Remove file once loaded

            self.db_service3_catalog(uid_name,each_roofplane_server_filename)
            os.remove(each_roofplane_local_filename)
            self.log(self.DEBUG,"Roof type mask images for UID {} saved successfully".format(uid_name))
            return "Image saved successfully"
        except Exception as e:

            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "Error in change_roof_type uid {} trace {}".format(uid_name,desired_trace))
        return "error"

    def db_service2_process_log(self, uuid, baseStatus):
        """Receive the uuid,stepName, baseStatus parameters and update the db service accordingly """
        self.log(self.DEBUG, "In db_service2_process_log Method UID ")
        try:
            url = self.properties.get('DB_SERVICE', 'PROCESS_SERVICE_URL')
            payload = {
                    "uuid": uuid,
                    "stepName": "qc2",
                    "baseStatus": baseStatus
                }
            headers = {'content-type': 'application/json'}
            r = requests.post(url, data=json.dumps(payload), headers=headers)
            if eval(str(r.content)) == 'success':
                self.log(self.DEBUG,"Process update for UID {} successful".format(uuid))
                return "success"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "UID db_service2_process_log failed  trace {} {}".format(uuid, desired_trace))

    def db_service3_catalog(self, uuid,s3path):
        """Takes uuid, stepName, bucket, s3path, updates the db service with this information once the image is saved"""
        self.log(self.DEBUG, "In db_service3_catalog Method UID {}".format(uuid))
        try:
            url = self.properties.get('DB_SERVICE', 'CATALOG_SERVICE_URL')
            # s3path = uuid + "/qc2/" + uuid + "-qcfeaturemask.tif"
            payload = {
                        "uuid": uuid,
                        "stepName": "qc2",
                        "bucket": 'dev-onswitch-pipline-v2',
                        "s3path": s3path
                    }
            headers = {'content-type': 'application/json'}
            r = requests.post(url, data=json.dumps(payload), headers=headers)
            if eval(str(r.content)) == 'success':
                self.log(self.DEBUG,"Catalog update for UID {} successful".format(uuid))
                return "success"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "UID db_service3_catalog failed {}  trace {}".format(uuid, desired_trace))

    def db_service4_publish(self, uuid):
        self.log(self.DEBUG, "In db_service4_publish Method UID {}".format(uuid))
        try:
            """Takes uuid, updates db service that qc1 and qc2 are completed"""
            url = self.properties.get('DB_SERVICE', 'PUBLISH_SERVICE_URL')
            url = url + uuid
            r = requests.post(url)
            self.log(self.DEBUG,"UID {} published successfully".format(uuid))
            return "success"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "UID db_service4_publish failed {} trace {}".format(uuid, desired_trace))

    def onswitchdb_update(self,uid, status):
        """Take uid,status and update the status column of the table"""
        self.log(self.DEBUG, "In onswitchdb_update Method UID {}".format(uid))
        try:
            sql = "UPDATE onswitchdb.XX_QCTOOL_LOG SET Status = '"+status+"',Last_Updated_On='" +  time.strftime('%Y-%m-%d %H:%M:%S')  + "' WHERE " \
                    "Image_Key = '"+uid+"' and workflow_state='QC_FEATURE_MASK' "
            conn = self.db_session()
            cursor = conn.cursor()
            cursor.execute(sql)
            conn.commit()
            self.log(self.DEBUG,"Record for UID {} in XX_QCTOOL_LOG updated successfully as {}".format(uid, status))
            return
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "UID onswitchdb_update failed with uid {} trace {}".format(uid, desired_trace))

    def onswitchdb_update_tracking(self,uid):
        """Take uid,status and update the status column of the table"""
        self.log(self.DEBUG, "In onswitchdb_update_tracking Method UID {}".format(uid))
        try:
            sql = "UPDATE onswitchdb.XX_QCTOOL_LOG_TRACKING SET Last_Updated_On='" + time.strftime(
                '%Y-%m-%d %H:%M:%S') + "' WHERE " \
                    "Image_Key = '"+uid+"' and current_step='QC_ROOF_TYPE' and Last_Updated_On is null"
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            conn.commit()
            self.log(self.DEBUG,"Record for UID {} in XX_QCTOOL_LOG_TRACKING updated successfully count {}".format(uid,records))
            return
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,
                     "UID onswitchdb_update_tracking failed with uid {} trace {}".format(uid, desired_trace))

    def onswitchdb_insert_tracking(self,uid,username,comments):
        """Take uid, status and insert as a row in the data base"""
        self.log(self.DEBUG, "In onswitchdb_insert_tracking Method UID {}".format(uid))
        try:
            sql = "INSERT INTO onswitchdb.XX_QCTOOL_LOG_TRACKING(image_key,user,current_step,started_on,comments) VALUES ('"+uid+"','"+ username+"'," \
                   "'QC_ROOF_TYPE','" + time.strftime('%Y-%m-%d %H:%M:%S') + "','" + comments + "')"
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            conn.commit()
            self.log(self.DEBUG,"Records in XX_QCTOOL_LOG_TRACKING inserted for UID {} with count {} comment {}".format(uid, records,comments))
            return
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,
                     "UID onswitchdb_insert_tracking failed with uid {} trace {}".format(uid, desired_trace))

    def validateSession(self, token2):
        email = ''
        try:

            url = 'https://oauth2.googleapis.com/tokeninfo?access_token=' + token2
            # params = {'access_token': token2}
            r = req.get(url=url, params=None)
            data = r.json()
            if 'email' in data:
                self.log(self.DEBUG, "The Email Id form google Api is {}".format(data['email']))
                # print("The Email Id form google Api is {}".format(data['email']))
                email = data['email']
                # print('email is ', email)
            elif 'error' in data:
                self.log(self.DEBUG, "The session is either Expired/Signed out  for token {}".format(session['token2']))
                # print("The session is either Expired/Signed out  for token {}".format(session['token2']))
                if 'token2' in session:
                    self.log(self.DEBUG, "The session Expired for token {}".format(session['token2']))
                    # print("The session Expired for token {}".format(session['token2']))
                    if 'refreshToken' in session:
                        self.log(self.DEBUG, "Getting refresh Token {}")
                        # print("Getting refresh Token ")
                        access_token = self.refreshToken(session['refreshToken'])
                        self.log(self.DEBUG, "The New Access  token generated is {}".format(access_token))
                        # print("The New Access  token generated is {}".format(access_token))
                        if access_token is not None:
                            session['token2'] = access_token
                            email = self.validateSession(access_token)
                            # print("Here It is ",email)
        except ValueError:
            # Invalid token
            self.log(self.ERROR, "The value error {}".format(ValueError))
            # print('the value error',ValueError)
            pass
        except KeyError:
            self.log(self.ERROR, "The KeyError  {}".format(KeyError))
            # print('error')
            return 'error'
        # print("before return ",email)
        return email

    def getUserBasedDetails(self, email, rootvalue):
        try:
            url = rootvalue + "qctool/getUserBasedDetails?email=" + email + "&jsonFlag=True"
            alldetails = requests.request("GET", url)
            return alldetails.json()
        except Exception:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, ": Error in getUserBasedDetails {}".format(desired_trace))

    def userSecurityCheck(self, session):
        self.log(self.DEBUG, "Inside userSecurityCheck  Method..")
        # print("Inside userSecurityCheck  Method..")
        if 'username' in session and 'token2' in session:
            self.log(self.DEBUG, "username and  token2  are in session..")
            # print("username and  token2  are in session..")
            token2 = session['token2']
            if token2 is not None:
                email = self.validateSession(token2)
                if email is not '' and email is not 'error':
                    self.log(self.DEBUG, "TvalidateSessionoken validated Successfully")
                    # print("Token validated Successfully")
                    if 'applicationList' in session:
                        self.log(self.DEBUG, "applicationList is in session")
                        # print("applicationList is in session")
                        if 'qctool' in session['applicationList']:
                            self.log(self.DEBUG, "qctool is in applicationList")
                            # print("qctool is in applicationList")
                            return True
                        else:
                            self.log(self.DEBUG, "qctool is not in applicationList")
                            return False
                    else:
                        self.log(self.DEBUG, "applicationList is not in session")
                        return False
                else:
                    self.log(self.DEBUG, "email is  '' or  error : {}".format(email))
                    # print("email return is", email)
                    return False
            else:
                self.log(self.DEBUG, "Token 2 is None ")
                return False
        else:
            self.log(self.DEBUG, "username and  token2  are not in session..")
            return False

    def refreshToken(self, refresh_token):
        self.log(self.DEBUG, "Inside refreshToken Method.. refresh_token is : {}".format(refresh_token))
        client_id = None
        client_secret = None
        CLIENT_SECRET_FILE = self.properties.get('GSign-In', 'Client_Secret')
        # print(CLIENT_SECRET_FILE)
        with open(CLIENT_SECRET_FILE, 'r') as f:
            distros_dict = json.load(f)

        if 'web' in distros_dict:
            web = distros_dict['web']
            if 'client_id' in web:
                client_id = web['client_id']
            if 'client_secret' in web:
                client_secret = web['client_secret']

        params = {
            "grant_type": "refresh_token",
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": refresh_token
        }

        authorization_url = "https://www.googleapis.com/oauth2/v4/token"

        r = requests.post(authorization_url, data=params)

        if r.ok:
            self.log(self.DEBUG, "Access Token refreshed Successfully . The new Access token is : {}".format(
                r.json()['access_token']))
            print("Access Token refreshed Successfully . The new Access token is : {}".format(r.json()['access_token']))
            return r.json()['access_token']
        else:
            self.log(self.DEBUG, "Access Token is not refreshed . Returning None")
            print("Access Token is not refreshed . Returning None")
            return None