# import libs
import traceback

import time
import json
import datetime
from flask import Flask, render_template, request, send_file,session,redirect
from flask import jsonify
# import custom scripts
from Qc import Qc

app = Flask(__name__, static_url_path='/qcrooftype/static')
app.secret_key = '123456'
qct = Qc()


@app.route('/qcrooftype/main',methods=['GET'])
def qc_tool():
    """# user name details
    Serves the html page@ 0.0.0.0/qctool, 1. Populate LOV on load"""
    start_time = time.time()
    t_uid = request.args.get('uid')
    # count = request.args.get('count')
    st = datetime.datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S')
    qct.log(qct.DEBUG,
            "------------------------------------------------------------------------------------------------------------------------------------------")
    qct.log(qct.DEBUG, "Qcrooftype Initiated at {}".format(st))
    qct.log(qct.DEBUG,
            "------------------------------------------------------------------------------------------------------------------------------------------")
    # session['username'] = 'triniti@triniti.com'
    # if 'username' in session:
    #     username = session['username']
    #     return render_template('QARooftype.html',session_images=[t_uid])
    # else:
    #     qct.log(qct.DEBUG, "User authentication failed")
    #     qct.log(qct.DEBUG, "Redirecting to login page...")
    #     return render_template('login.html')

    userName = None
    token2 = None
    if 'username' in session:
        userName = session['username']

    if 'token2' in session:
        token2 = session['token2']

    value = request.url_root;
    session['rootvalue'] = value

    if userName is not None:
        # token2 = request.args.get('token2')
        # token2 = session['token2']
        if token2 is not None:
            email = qct.validateSession(token2)
            if email is not '' and email is not 'error':
                redirectToValue = qct.getUserBasedDetails(email, value)
                if redirectToValue is 'approvalPending':
                    return redirect(value + "qctool/approvalPending")
                else:
                    if 'qctool' in redirectToValue:
                        # return render_template('QARooftype.html',session_images=[t_uid,count])
                        return render_template('QARooftype.html', session_images=[t_uid])
                    else:
                        return redirect(value + 'qctool/home')
            else:
                session.pop('username', None)
                session.pop('token2', None)
                return redirect(value + "qctool/login")
        else:
            return redirect(value + "qctool/login")
    else:
        return redirect(value + "qctool/login")


@app.route('/qcrooftype/getdata', methods=['GET'])
def qc_tool_get_data():
    uid_name = request.args.get('uid')
    qct.log(qct.DEBUG, "uid_name for {} and type {}".format(uid_name,type(uid_name)))

    # Hard Coded for testing
    # uid_name = '18ac47fa-1156-4dde-aa31-b82f5599e6c3'
    # uid_name =''

    # username = ''
    if 'username' in session:
        username = session['username']
    imageData = ''
    roofPlanesDict = {}
    roofPlanesTypeDict = {}
    with open('roof_type_key.json') as f:
        data = json.load(f)
    response = json.dumps(data)
    print("rooftype",response)

        #loads and prints the image

    if  uid_name != '':
        try:
            imageData = qct.get_bg_img(uid_name)

            if imageData is None: #error and return to json
                qct.db_service2_process_log(uuid=uid_name, baseStatus='error')

                qct.onswitchdb_update(uid_name, status='ERROR')
                qct.onswitchdb_insert_tracking(uid_name, username, "Error Image not found in bucket")
                r = {'current_image': uid_name, 'bg_image': '', 'roofPlaneTypes': roofPlanesTypeDict,
                     'roof_type_list': response, 'roofPlanes': roofPlanesDict}

                return jsonify(r)

            roofPlanesDict, roofPlanesTypeDict = qct.get_roof_plane_masks(uid_name)
            qct.onswitchdb_insert_tracking(uid_name, username, "Inprogress")
            raw_image = uid_name + '/qc1/' + uid_name + '-maskedimage.tif'
            qct.log(qct.DEBUG, "Images for image {} rendered successfully".format(raw_image))
            r = {'current_image': raw_image, 'bg_image': imageData, 'roofPlaneTypes': roofPlanesTypeDict,
                 'roof_type_list': response, 'roofPlanes': roofPlanesDict}
            # r=[raw_image,imageData,roofPlanesTypeDict,response,roofPlanesDict]
            return jsonify(r)
            # return render_template('QARooftype.html',current_image=raw_image,bg_image=imageData,roofPlaneTypes=roofPlanesTypeDict,roof_type_list=response,roofPlanes=roofPlanesDict)
        except Exception as ex:
            print("error in image fetching", ex)
            desired_trace = traceback.format_exc()
            qct.log(qct.DEBUG,
                    "UID retrieving image and masks failed with uid {} trace {}".format(uid_name, desired_trace))
            qct.onswitchdb_update(uid_name, status='ERROR')
            qct.onswitchdb_insert_tracking(uid_name, username, "Error " + str(ex))
            bg_img = ''
            r = {'current_image': uid_name, 'bg_image': bg_img, 'roofPlaneTypes': roofPlanesTypeDict,
                 'roof_type_list': response, 'roofPlanes': roofPlanesDict}

            # r=[uid_name,bg_img,roofPlanesTypeDict,response,roofPlanesDict]
            return jsonify(r)

            # return render_template('QARooftype.html', current_image=uid_name, bg_image='',
            #                        roofPlaneTypes=roofPlanesTypeDict, roof_type_list=response,
            #                        roofPlanes=roofPlanesDict)

    else:
        qct.log(qct.DEBUG, "Images for image {} rendered successfully".format(uid_name))
        r = {'current_image': uid_name, 'bg_image': imageData, 'roofPlaneTypes': roofPlanesTypeDict,
             'roof_type_list': response, 'roofPlanes': roofPlanesDict}

        # r = [uid_name, imageData,roofPlanesTypeDict,response,roofPlanesDict]
        return jsonify(r)

#logout details
@app.route('/qcrooftype/logout', methods=[ 'POST'])
def logout():
   # remove the username from the session if it is there
   if 'username' in session:
       username = session['username']
   session.pop('username', None)
   qct.log(qct.DEBUG,"Session user successfully logged out")
   return "success"


@app.route('/qcrooftype/save_as_complete', methods=['POST'])
def save_as_complete():
    """3b receive modified image and upload to S3"""
    uid = None
    userCheck = qct.userSecurityCheck(session)
    qct.log(qct.DEBUG, " User SecurityCheck Flag while saving image  is : {} ".format(userCheck))
    if userCheck is True:
        try:
            content = request.get_json()
            fileName = content['selectimage']
            uid = fileName.split('/')[0]
            qct.log(qct.DEBUG,"User request to save for UID {} initiated".format(uid))
            modified_image = content['save']
            original_images_dict = content['originalTypes']
            count = 1
            for each_roofplane_filename, each_roofplane_type_value in original_images_dict.iteritems():
                if each_roofplane_filename in modified_image:
                    each_roofplane_type_value = modified_image[each_roofplane_filename]
                qct.change_roof_type(uid, each_roofplane_filename, each_roofplane_type_value, count)
                count += 1

            s3path = uid + "/qc2/" + uid + "-qcfeaturemask.tif"
            qct.db_service3_catalog(uuid=uid,s3path=s3path)
            qct.db_service2_process_log(uuid=uid, baseStatus='complete')
            qct.db_service4_publish(uuid=uid)
            qct.onswitchdb_update(uid, status='PUBLISHED')
            qct.onswitchdb_update_tracking(uid)
            qct.onswitchdb_insert_tracking(uid, '', "PUBLISHED")
            # Time stamps
            end_time = time.time()
            et = datetime.datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S')
            qct.log(qct.DEBUG,"------------------------------------------------------------------------------------------------------------------------------------------")
            qct.log(qct.DEBUG,"QcRoofType with UID:'{}' successfully Completed at {}".format(uid, et))
            qct.log(qct.DEBUG,"------------------------------------------------------------------------------------------------------------------------------------------")
            return 'images modified successfully'
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.ERROR, "QcRoofType with UID:'{}' save failed {}".format(uid, desired_trace))
            qct.onswitchdb_update(uid, status='ERROR')
            qct.onswitchdb_insert_tracking(uid, '', "saving Error " + str(ex))
            return "failed saving"
    else:
        return "home"

@app.route('/qcrooftype/reject', methods=['POST'])
def rejectImage():
    """3b receive modified image and upload to S3"""
    userCheck = qct.userSecurityCheck(session)

    qct.log(qct.DEBUG, " User SecurityCheck Flag while rejecting image  is : {} ".format(userCheck))
    if userCheck is True:
        try:
            content = json.loads(request.data)
            fileName = content['selectimage']
            uid = fileName.split('/')[0]
            qct.log(qct.DEBUG,"User rejected UID {}".format(uid))
            qct.db_service2_process_log(uuid=uid, baseStatus='Reject')
            qct.onswitchdb_update(uid, status='REJECTED')
            qct.onswitchdb_update_tracking(uid)
            qct.onswitchdb_insert_tracking(uid, '', "REJECTED")
            return 'Image Rejected'
        except Exception as ex:
            desired_trace = traceback.format_exc()
            qct.log(qct.ERROR," Status update of UID {} as Rejected failed with error {}".format(uid, desired_trace))
            return 'Image Reject failed'
    else:
        return "home"

if __name__ == '__main__':
    app.run(host = '0.0.0.0')


