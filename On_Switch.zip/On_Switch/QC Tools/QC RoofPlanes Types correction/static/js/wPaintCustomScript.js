$('#mobi-icon').click(function () {
	if ($('#mobi-icon').hasClass('open')) {
		$('#mobile-menu').animate({
			opacity: 0,
			height: 0
		}, 250, function () {
			$(this).css('visibility', 'hidden');
			$('#mobi-icon').removeClass('open');
		});
	} else {
		$('#mobile-menu').css('visibility', 'visible')
		$('#mobile-menu').animate({
			opacity: 1,
			height: 350
		}, 250);
		$('#mobi-icon').addClass('open');
	}
});
var images = [
	'/test/uploads/wPaint.png'
];


function changeRoofType() {

	var selectedImage = $('#selectImage').val();
	var selectedRoofType = $('#roofTypesListId').val();
	if (selectedRoofType != '0' && selectedImage != '0') {
		modifiedRoofPlaneTypesArray[selectedImage] = selectedRoofType;
		/* $.ajax({
      			  type: 'POST',
                    url: '/change_roof_type',
                    //url: 'qctool/save',
                    data:'{"selectimage":"' + selectedImage + '","newRoofType":"' + selectedRoofType + '"}' ,
                    contentType: 'application/json; charset=utf-8',
                    success: function (resp) {
                        alert('Image Type Modified successfully');
                    },
      		      error: function(XMLHttpRequest, textStatus, errorThrown) {
      		          alert("Status: " + textStatus); alert("Error: " + errorThrown);
      		      }

      		      }); */

	}
}

function onLoad() {
	gapi.load('auth2', function () {
		gapi.auth2.init();
	});
}



function loadImage() {

	var selectedImage = $('#selectImage').val();

	var element = document.getElementById("paintcanvas");
	//element.classList.add("show");
	//bgcontext.clearRect(0, 0, bgcontext.canvas.width, bgcontext.canvas.height);
	context.clearRect(0, 0, context.canvas.width, context.canvas.height);

	fgImage.onload = function () {
		drawInitialFGImage();
		var roofTypeVal = roofPlaneTypesArray[selectedImage];
		$('#roofTypesListId').val(roofTypeVal).change();
	}
	fgImage.src = "data:image/png;base64," + roofPlanesArray[selectedImage];


}

function saveImg(image) {

	if (toolObject._this.menus.all.main._isIconDisabled('save')) {
		//return;
	}
	//pushImageToServer();

	var r = confirm("Do you want to commit changes to Masked Image?");
	if (r == true) {
		pushImageToServer('save_as_complete');
	} else {
		return;
	}
}

function loadImgBg() {

	//pushImageToServer();

	// internal function for displaying background images modal
	// where images is an array of images (base64 or url path)
	// NOTE: that if you can't see the bg image changing it's probably
	// becasue the foregroud image is not transparent.
	//this._showFileModal('bg', images);
}

function saveIncompleteImage() {
	if (toolObject._this.menus.all.main._isIconDisabled('save')) {
		//return;
	}
	// internal function for displaying foreground images modal
	// where images is an array of images (base64 or url path)
	//this._showFileModal('fg', images);
	var r = confirm("Do you want to save partially edited Image?");
	if (r == true) {
		pushImageToServer('save');
	} else {
		return;
	}
}

function rejectImage() {
	if (toolObject._this.menus.all.main._isIconDisabled('save')) {
		//return;
	}
	// internal function for displaying foreground images modal
	// where images is an array of images (base64 or url path)
	//this._showFileModal('fg', images);
	var r = confirm("Do you want to Reject Image?");
	if (r == true) {
		//pushImageToServer('/save');
		sendRejectToServer();
	} else {
		return;
	}
}

// init wPaint
$('#wPaint').wPaint({
	menuOffsetLeft: 595,
	menuOffsetTop: 15,
	saveImg: saveImg,
	loadImgBg: loadImgBg,
	saveIncompleteImage: saveIncompleteImage,
	rejectImage: rejectImage,
	signout: signout
	//loadImgFg: loadImgFg
});

// $(document).ready(function(){

var zoomFactor = 0;

var bgcanvas = document.getElementById("paintcanvas-bg");
var bgcontext = bgcanvas.getContext("2d");

var canvas = document.getElementById("paintcanvas");
var context = canvas.getContext("2d");

var tempcanvas = document.getElementById("paintcanvas-temp");
var tempcontext = tempcanvas.getContext("2d");

var fgOriginalcanvas = document.getElementById("paintcanvas-fgOriginal");
var fgOriginalcontext = fgOriginalcanvas.getContext("2d");

var bgOriginalcanvas = document.getElementById("paintcanvas-bgOriginal");
var bgOriginalcontext = bgOriginalcanvas.getContext("2d");

var fgZoomBoxcanvas = document.getElementById("paintcanvas-zoomBoxFg");
var fgZoomBoxcontext = fgZoomBoxcanvas.getContext("2d");

var bgZoomBoxcanvas = document.getElementById("paintcanvas-zoomBoxBg");
var bgZoomBoxcontext = bgZoomBoxcanvas.getContext("2d");

var canvasLeftStart = 50;
var canvasTopStart = 10;

var fgImage = new Image();
var bgImage = new Image();

context.strokeRect(0, 0, canvas.width, canvas.height);
var scaleFactorNew = 0;
var toolObject;
var theSelection;

var zoomBoxExists = "false";
var childEditCount = 0;
var currentFileName = "";
var fgImageWidth = 0;
var fgImageHeight = 0;

var zoomboxStartWidth = 0;
var zoomboxStartHeight = 0;


function resizeAllCanvases() {

	var windowInnerWidth = window.innerWidth;
	var windowInnerHeight = window.innerHeight;
	var bgImageOriginalWidth = bgImage.width;
	var bgImageOriginalHeight = bgImage.height;
	var newCanvasWidth;
	var newCanvasHeight;

	var imageAspectRatio = bgImageOriginalWidth / bgImageOriginalHeight;

	if (windowInnerWidth < windowInnerHeight) {
		newCanvasWidth = windowInnerWidth;
		newCanvasHeight = windowInnerHeight / imageAspectRatio;
		if (newCanvasHeight > windowInnerHeight) {
			newCanvasHeight = windowInnerHeight;
		}
	} else {
		newCanvasWidth = windowInnerHeight * imageAspectRatio;
		if (newCanvasWidth > windowInnerWidth) {
			newCanvasWidth = windowInnerWidth;
		}
		newCanvasHeight = windowInnerHeight;


	}
	newCanvasWidth = Math.round(newCanvasWidth) - (80 + canvasLeftStart);
	newCanvasHeight = Math.round(newCanvasHeight) - 130;

	var viewportWidth = window.innerWidth;
	var viewportHeight = window.innerHeight;
	var canvasWidth = newCanvasWidth * 1.2;
	var canvasHeight = newCanvasWidth / 2;

	canvas.style.position = "absolute";

	//----------------fg canvas clear and resize---------

	canvas.width = newCanvasWidth;
	canvas.height = newCanvasHeight;

	var canvasLeft = (viewportWidth - canvasWidth) / 2;
	if (canvasLeft < 10) {
		canvasLeft = 45;
	}
	canvas.style.left = canvasLeft + "px";

	//----------------bg canvas clear and resize---------

	bgcanvas.width = newCanvasWidth;
	bgcanvas.height = newCanvasHeight;

	bgcanvas.style.left = canvasLeft + "px";

	//----------for temp canvas image restore---------------
	var canvasSave = document.createElement('canvas'),
		ctxSave = canvasSave.getContext('2d');

	canvasSave.width = tempcanvas.width;
	canvasSave.height = tempcanvas.height;

	bgcanvas.style.left = canvasLeft + "px";

	ctxSave.drawImage(tempcanvas, 0, 0);

	tempcanvas.width = newCanvasWidth;
	tempcanvas.height = newCanvasHeight;

	bgcanvas.style.left = canvasLeft + "px";

	tempcontext.drawImage(canvasSave, 0, 0, newCanvasWidth, newCanvasHeight);

	//----------for zoom fg image restore---------------
	canvasSave.width = fgZoomBoxcanvas.width;
	canvasSave.height = fgZoomBoxcanvas.height;

	bgcanvas.style.left = canvasLeft + "px";

	ctxSave.drawImage(fgZoomBoxcanvas, 0, 0);

	fgZoomBoxcanvas.width = newCanvasWidth;
	fgZoomBoxcanvas.height = newCanvasHeight;

	bgcanvas.style.left = canvasLeft + "px";

	fgZoomBoxcontext.drawImage(canvasSave, 0, 0, newCanvasWidth, newCanvasHeight);


	//----------for zoom bg image restore---------------
	canvasSave.width = bgZoomBoxcanvas.width;
	canvasSave.height = bgZoomBoxcanvas.height;

	bgcanvas.style.left = canvasLeft + "px";

	ctxSave.drawImage(bgZoomBoxcanvas, 0, 0);

	bgZoomBoxcanvas.width = newCanvasWidth;
	bgZoomBoxcanvas.height = newCanvasHeight;

	bgcanvas.style.left = canvasLeft + "px";

	bgZoomBoxcontext.drawImage(canvasSave, 0, 0, newCanvasWidth, newCanvasHeight);
	//-----------------------------------------------

	toolObject.options.menuOffsetLeft = canvasLeft + newCanvasWidth + 3;

	roofPlaneSelectionDivId

	var $roofPlaneSelectionDivId = $("#roofPlaneSelectionDivId");

	$roofPlaneSelectionDivId.css({
		left: canvasLeft,
		position: 'relative'

	});

	toolObject.width = newCanvasWidth;
	toolObject.height = newCanvasHeight;

	var $filePathDivId = $("#filePathDivId");

	$filePathDivId.css({
		left: canvasLeft

	});

	var $menuId = $("#wPaint-menu");

	$menuId.css({
		left: toolObject.options.menuOffsetLeft,
		top: toolObject.options.menuOffsetTop
	});

	var $signoutbuttonId = $("#signout-button");

	$signoutbuttonId.css({

//		position: 'absolute',
//		left: canvas.width - 60
	});

	var $opacityBarId = $("#opacityBar");

	$opacityBarId.css({

		height: newCanvasHeight - 200,
		width: 10,
		background: 'red'
	});

	var $lineWidthBarId = $("#lineWidthBar");

	$lineWidthBarId.css({

		height: newCanvasHeight - 200,
		width: 10,
		background: 'blue'
	});

	var $slidecontainerId = $("#slidecontainerId");

	$slidecontainerId.css({
		left: canvasLeft - 45,
		height: newCanvasHeight - 50
	});

	var $paintcanvasbgId = $("#paintcanvas-bg");

	$paintcanvasbgId.css({

		//left: canvasLeftStart,
		top: canvasTopStart
	});

	var $paintcanvasId = $("#paintcanvas");

	$paintcanvasId.css({

		//left: canvasLeftStart,
		top: canvasTopStart
	});

	var $paintcanvas_zoomBoxFgId = $("#paintcanvas-zoomBoxFg");

	$paintcanvas_zoomBoxFgId.css({

		//left: canvasLeftStart,
		top: canvasTopStart
	});

	var $paintcanvas_zoomBoxBgId = $("#paintcanvas-zoomBoxBg");

	$paintcanvas_zoomBoxBgId.css({

		//left: canvasLeftStart,
		top: canvasTopStart
	});

	var $paintcanvas_tempId = $("#paintcanvas-temp");

	$paintcanvas_tempId.css({

		//left: canvasLeftStart,
		top: canvasTopStart
	});

	var $paintcanvas_zoomTempId = $("#paintcanvas-zoomTemp");

	$paintcanvas_zoomTempId.css({

		//left: canvasLeftStart,
		top: canvasTopStart
	});

}

function assignImageToCanvas(bgImageData) {

	bgImage.onload = function () {

		childEditCount = 0;
		toolObject._this.undoArray = [];
		toolObject._this.undoFGOriginalArray = [];
		toolObject._this.undoCurrent = -1;
		childEditCount = 0;
		zoomBoxExists = "false";
		resizeAllCanvases();
		bgcontext.clearRect(0, 0, bgcontext.canvas.width, bgcontext.canvas.height);
		bgcontext.drawImage(bgImage, 00, 00, bgImage.width, bgImage.height, 0, 0, bgcanvas.width, bgcanvas.height);
		bgcontext.save();
		//drawInitialFGImage();


	}
	bgImage.src = "data:image/png;base64," + bgImageData;

}
bgImage.id = "bgImageId";
fgImage.id = "fgImageId";

function drawInitialFGImage() {


	fgImageWidth = fgImage.width;
	fgImageHeight = fgImage.height;

	fgOriginalcanvas.width = fgImageWidth;
	fgOriginalcanvas.height = fgImageHeight;

	fgOriginalcontext.mozImageSmoothingEnabled = true;
	fgOriginalcontext.webkitImageSmoothingEnabled = true;
	fgOriginalcontext.msImageSmoothingEnabled = true;
	fgOriginalcontext.imageSmoothingEnabled = true;
	fgOriginalcontext.imageSmoothingQuality = "high";

	bgOriginalcanvas.width = fgImageWidth;
	bgOriginalcanvas.height = fgImageHeight;

	var $fgnewcanvas = $("#paintcanvas-fgOriginal");
	var $bgnewcanvas = $("#paintcanvas-bgOriginal");

	/* $fgnewcanvas.css({position: 'absolute', left: 0, top: 600});
        	$bgnewcanvas.css({position: 'absolute', left: 0, top: 600});  */

	$fgnewcanvas.css({
		position: 'absolute',
		left: -10000,
		top: -10000
	});
	$bgnewcanvas.css({
		position: 'absolute',
		left: -10000,
		top: -10000
	});

	context.clearRect(0, 0, context.canvas.width, context.canvas.height);
	//context.drawImage(fgImage,0,0);
	fgOriginalcontext.drawImage(fgImage, 0, 0);

	bgOriginalcontext.drawImage(bgImage, 0, 0);

	//theSelection = new Selection(200, 200, 200, 200);
	//drawScene();

	var imageX = 0;
	var imageY = 0;
	var imageWidth = fgImage.width;
	var imageHeight = fgImage.height;

	//context.drawImage(fgImage, imageX, imageY);

	var imageData = fgOriginalcontext.getImageData(imageX, imageY, imageWidth, imageHeight);
	var data = imageData.data;
	var count = 0;
	// iterate over all pixels
	for (var i = 0, n = data.length; i < n; i += 4) {
		var red = data[i];
		var green = data[i + 1];
		var blue = data[i + 2];
		var alpha = data[i + 3];
		//white

		if (red > 0 && red < 255) {
			//console.log("red-" + red + "-green-" + green + "-blue-" + blue + "-alpha-" + alpha);
			count = count + 1;
		}
		/* if(red > 0){
              //if(red == 255 && green == 255 && blue == 255 && alpha == 255){
            	//  if(red == 255 && green == 255 && blue == 255 ){
            	//data[i ] = 255;
              	data[i + 1] = 0;
              	data[i + 2] = 0;
              	data[i + 3] = 255;
              } */
		//black
		if (red == 0 && green == 0 && blue == 0) {
			//if(red != 255 && green != 255 && blue != 255 ){
			/* data[i ] = 255;
			data[i + 1] = 255;
			data[i + 2] = 255; */
			data[i + 3] = 0;
		} else {
			data[i] = 255;

			data[i + 1] = 0;
			data[i + 2] = 0;
			data[i + 3] = 255;
		}
	}

	console.log("final count-" + count);
	context.clearRect(0, 0, context.canvas.width, context.canvas.height);
	//context.globalAlpha = 0.1
	//context.putImageData(imageData, 0, 0,0,0,canvas.width, canvas.height);

	fgOriginalcontext.putImageData(imageData, 0, 0);

	context.drawImage(fgOriginalcanvas, 0, 0, imageWidth, imageHeight, 0, 0, canvas.width, canvas.height);

	toolObject._this._addUndo();
	toolObject._this.menus.all.main._setIconDisabled('pencil', false);
	toolObject._this.menus.all.main._setIconDisabled('bucket', false);
	toolObject._this.menus.all.main._setIconDisabled('clear', false);
	toolObject._this.menus.all.main._setIconDisabled('eraser', false);
	toolObject._this.menus.all.main._setIconDisabled('zoom', false);
}

function pushImageToServer(targetURL) {
	var element = document.getElementById("paintcanvas");
	element.classList.add("show");
	$.ajax({
		type: 'POST',
		url: targetURL,
		//url: 'qctool/save',
		data: '{"selectimage":"' + currentFileName + '","save":' + JSON.stringify(modifiedRoofPlaneTypesArray) + ',"originalTypes":' + JSON.stringify(roofPlaneTypesArray) + '}',
		contentType: 'application/json; charset=utf-8',
		success: function (resp) {
		    element.classList.remove("show");
		    if(resp == 'home'){
		       alert('Image Save Failed, Unauthorized Access!!');
		       window.location.href = '/qctool/home';
		    }
		    else{
		       alert('Image saved successfully');
			   window.location.href = '/qctool/main';
		    }

		}
	});
	tempcontext.canvas.width = context.canvas.width;
	tempcontext.canvas.height = context.canvas.height;
}

function sendRejectToServer() {
	$.ajax({
		type: 'POST',
		url: 'reject',
		//url: 'qctool/save',
		data: '{"selectimage":"' + currentFileName + '"}',
		contentType: 'application/json; charset=utf-8',
		success: function (resp) {
		   if(resp == 'home'){
		       alert('Image Reject Failed, Unauthorized Access!!');
		       window.location.href = '/qctool/home';
		    }
		    else{
		    alert('Image Rejected successfully');
		    window.location.href = '/qctool/main';
		    }
		}
	});

}

function signout() {
	handleSignOutClick();
}

function getRGB(str) {
	var match = str.match(/rgba?\((\d{1,3}), ?(\d{1,3}), ?(\d{1,3})\)?(?:, ?(\d(?:\.\d?))\))?/);
	return match ? {
		red: match[1],
		green: match[2],
		blue: match[3]
	} : {};
}

var iMouseX, iMouseY = 1;

// define Selection constructor
function Selection(x, y, w, h) {
	this.x = x; // initial positions
	this.y = y;
	this.w = w; // and size
	this.h = h;

	this.orgw = w;
	this.orgh = h;

	this.px = x; // extra variables to dragging calculations
	this.py = y;

	this.csize = 6; // resize cubes size
	this.csizeh = 10; // resize cubes size (on hover)

	this.bHow = [false, false, false, false]; // hover statuses
	this.iCSize = [this.csize, this.csize, this.csize, this.csize]; // resize cubes sizes
	this.bDrag = [false, false, false, false]; // drag statuses
	this.bDragAll = false; // drag whole selection
}

Selection.prototype.draw = function () {

	context.strokeStyle = '#000';
	context.lineWidth = 2;
	context.strokeRect(this.x, this.y, this.w, this.h);

	// draw part of original image
	if (this.w > 0 && this.h > 0) {
		context.drawImage(tempcontext.canvas, this.x, this.y, this.w, this.h, this.x, this.y, this.w, this.h);
		//context.drawImage(tempcontext.canvas, this.x, this.y, this.w, this.h, this.x, this.y, this.w, this.h);
	}

	// draw resize cubes
	context.fillStyle = '#fff';
	context.fillRect(this.x - this.iCSize[0], this.y - this.iCSize[0], this.iCSize[0] * 2, this.iCSize[0] * 2);
	context.fillRect(this.x + this.w - this.iCSize[1], this.y - this.iCSize[1], this.iCSize[1] * 2, this.iCSize[1] * 2);
	context.fillRect(this.x + this.w - this.iCSize[2], this.y + this.h - this.iCSize[2], this.iCSize[2] * 2, this.iCSize[2] * 2);
	context.fillRect(this.x - this.iCSize[3], this.y + this.h - this.iCSize[3], this.iCSize[3] * 2, this.iCSize[3] * 2);
}

function drawScene() { // main drawScene function


	context.clearRect(0, 0, context.canvas.width, context.canvas.height); // clear canvas

	// draw source image
	context.drawImage(tempcontext.canvas, 0, 0, context.canvas.width, context.canvas.height);

	// and make it darker
	context.fillStyle = 'rgba(0, 0, 0, 0.5)';
	context.fillRect(0, 0, context.canvas.width, context.canvas.height);

	// draw selection
	theSelection.draw();

	canvas.addEventListener('mousemove', canvasHandleMouseMove, false);
	canvas.addEventListener('mousedown', canvasHandleMousedown, false);
	canvas.addEventListener('mouseup', canvasHandleMouseup, false);

}

//$('#paintcanvas').mousemove(function(e) { // binding mouse move event
var canvasHandleMouseMove = function (e) {
	var canvasOffset = $(canvas).offset();
	iMouseX = Math.floor(e.pageX - canvasOffset.left);
	iMouseY = Math.floor(e.pageY - canvasOffset.top);

	// in case of drag of whole selector
	if (theSelection.bDragAll) {
		theSelection.x = iMouseX - theSelection.px;
		theSelection.y = iMouseY - theSelection.py;
	}

	for (i = 0; i < 4; i++) {
		theSelection.bHow[i] = false;
		theSelection.iCSize[i] = theSelection.csize;
	}

	// hovering over resize cubes
	if (iMouseX > theSelection.x - theSelection.csizeh && iMouseX < theSelection.x + theSelection.csizeh &&
		iMouseY > theSelection.y - theSelection.csizeh && iMouseY < theSelection.y + theSelection.csizeh) {

		theSelection.bHow[0] = true;
		theSelection.iCSize[0] = theSelection.csizeh;
	}
	if (iMouseX > theSelection.x + theSelection.w - theSelection.csizeh && iMouseX < theSelection.x + theSelection.w + theSelection.csizeh &&
		iMouseY > theSelection.y - theSelection.csizeh && iMouseY < theSelection.y + theSelection.csizeh) {

		theSelection.bHow[1] = true;
		theSelection.iCSize[1] = theSelection.csizeh;
	}
	if (iMouseX > theSelection.x + theSelection.w - theSelection.csizeh && iMouseX < theSelection.x + theSelection.w + theSelection.csizeh &&
		iMouseY > theSelection.y + theSelection.h - theSelection.csizeh && iMouseY < theSelection.y + theSelection.h + theSelection.csizeh) {

		theSelection.bHow[2] = true;
		theSelection.iCSize[2] = theSelection.csizeh;
	}
	if (iMouseX > theSelection.x - theSelection.csizeh && iMouseX < theSelection.x + theSelection.csizeh &&
		iMouseY > theSelection.y + theSelection.h - theSelection.csizeh && iMouseY < theSelection.y + theSelection.h + theSelection.csizeh) {

		theSelection.bHow[3] = true;
		theSelection.iCSize[3] = theSelection.csizeh;
	}

	// in case of dragging of resize cubes
	var iFW, iFH;
	if (theSelection.bDrag[0]) {
		var iFX = iMouseX - theSelection.px;
		var iFY = iMouseY - theSelection.py;
		iFW = theSelection.w + theSelection.x - iFX;
		iFH = theSelection.h + theSelection.y - iFY;
	}
	if (theSelection.bDrag[1]) {
		var iFX = theSelection.x;
		var iFY = iMouseY - theSelection.py;
		iFW = iMouseX - theSelection.px - iFX;
		iFH = theSelection.h + theSelection.y - iFY;
	}
	if (theSelection.bDrag[2]) {
		var iFX = theSelection.x;
		var iFY = theSelection.y;
		iFW = iMouseX - theSelection.px - iFX;
		iFH = iMouseY - theSelection.py - iFY;
	}
	if (theSelection.bDrag[3]) {
		var iFX = iMouseX - theSelection.px;
		var iFY = theSelection.y;
		iFW = theSelection.w + theSelection.x - iFX;
		iFH = iMouseY - theSelection.py - iFY;
	}

	if (iFW > theSelection.csizeh * 2 && iFH > theSelection.csizeh * 2) {

		if (iFW >= theSelection.orgw && iFH >= theSelection.orgh) {
			theSelection.w = iFW;
			theSelection.h = iFH;
		}
		theSelection.x = iFX;
		theSelection.y = iFY;
	}

	drawScene();
};

//$('#paintcanvas').mousedown(function(e) { // binding mousedown event
var canvasHandleMousedown = function (e) {
	var canvasOffset = $(canvas).offset();
	iMouseX = Math.floor(e.pageX - canvasOffset.left);
	iMouseY = Math.floor(e.pageY - canvasOffset.top);

	theSelection.px = iMouseX - theSelection.x;
	theSelection.py = iMouseY - theSelection.y;

	//satish code start
	{

		for (i = 0; i < 4; i++) {
			theSelection.bHow[i] = false;
			theSelection.iCSize[i] = theSelection.csize;
		}

		// hovering over resize cubes
		if (iMouseX > theSelection.x - theSelection.csizeh && iMouseX < theSelection.x + theSelection.csizeh &&
			iMouseY > theSelection.y - theSelection.csizeh && iMouseY < theSelection.y + theSelection.csizeh) {

			theSelection.bHow[0] = true;
			theSelection.iCSize[0] = theSelection.csizeh;
		}
		if (iMouseX > theSelection.x + theSelection.w - theSelection.csizeh && iMouseX < theSelection.x + theSelection.w + theSelection.csizeh &&
			iMouseY > theSelection.y - theSelection.csizeh && iMouseY < theSelection.y + theSelection.csizeh) {

			theSelection.bHow[1] = true;
			theSelection.iCSize[1] = theSelection.csizeh;
		}
		if (iMouseX > theSelection.x + theSelection.w - theSelection.csizeh && iMouseX < theSelection.x + theSelection.w + theSelection.csizeh &&
			iMouseY > theSelection.y + theSelection.h - theSelection.csizeh && iMouseY < theSelection.y + theSelection.h + theSelection.csizeh) {

			theSelection.bHow[2] = true;
			theSelection.iCSize[2] = theSelection.csizeh;
		}
		if (iMouseX > theSelection.x - theSelection.csizeh && iMouseX < theSelection.x + theSelection.csizeh &&
			iMouseY > theSelection.y + theSelection.h - theSelection.csizeh && iMouseY < theSelection.y + theSelection.h + theSelection.csizeh) {

			theSelection.bHow[3] = true;
			theSelection.iCSize[3] = theSelection.csizeh;
		}
	}
	//satish code end

	if (theSelection.bHow[0]) {
		theSelection.px = iMouseX - theSelection.x;
		theSelection.py = iMouseY - theSelection.y;
	}
	if (theSelection.bHow[1]) {
		theSelection.px = iMouseX - theSelection.x - theSelection.w;
		theSelection.py = iMouseY - theSelection.y;
	}
	if (theSelection.bHow[2]) {
		theSelection.px = iMouseX - theSelection.x - theSelection.w;
		theSelection.py = iMouseY - theSelection.y - theSelection.h;
	}
	if (theSelection.bHow[3]) {
		theSelection.px = iMouseX - theSelection.x;
		theSelection.py = iMouseY - theSelection.y - theSelection.h;
	}


	if (iMouseX > theSelection.x + theSelection.csizeh && iMouseX < theSelection.x + theSelection.w - theSelection.csizeh &&
		iMouseY > theSelection.y + theSelection.csizeh && iMouseY < theSelection.y + theSelection.h - theSelection.csizeh) {

		theSelection.bDragAll = true;
	}

	for (i = 0; i < 4; i++) {
		if (theSelection.bHow[i]) {
			theSelection.bDrag[i] = true;
		}
	}
};

//$('#paintcanvas').mouseup(function(e) { // binding mouseup event
var canvasHandleMouseup = function (e) {
	theSelection.bDragAll = false;

	for (i = 0; i < 4; i++) {
		theSelection.bDrag[i] = false;
	}
	theSelection.px = 0;
	theSelection.py = 0;
};

var selectedImage = $('#selectImage').val();


$("#paintcanvas").mouseenter(function () {
	//alert('hi');
	$(this).css('border', '2px solid red');
});
$("#paintcanvas").mouseleave(function () {
	//alert('out');
	$(this).css('border', '0');
});

