var roofPlanesArray = {};
var roofPlaneTypesArray = {};
var modifiedRoofPlaneTypesArray = {};
var data;

window.onload = function(e){
  $("#loadingIcon").css("display", "none");

  $("#parentContainer").css("visibility", "visible");
  
}

$(document).ready(function () {
	
	$.ajax({
		type: 'GET',
		url: '/qcrooftype/getdata?uid='+uid,
		async: false,
		success: function (resp) {
			data = resp;
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			alert("Status: " + textStatus);
			alert("Error: " + errorThrown);
		}

	})


	currentFileName = data.current_image;
	if (currentFileName == '404' || !currentFileName || currentFileName == 'None') {
		$("#pContainer").css("display", "block");
        $("#parentContainer").css("display", "none");
        $("#loadingIcon").css("display", "none");
		return;
	} else {

		//currentFileName = currentFileName.split("/")[2];
	}

	var bgImage = data.bg_image;


	var roofPlanes = data.roofPlanes;


	for (var i in roofPlanes) {
		var key = i;
		var value = roofPlanes[i];

		roofPlanesArray[key] = value;
		$('#selectImage')
			.append($('<option>', {
					value: key
				})
				.text(key));
	}


	var roofPlaneTypes = data.roofPlaneTypes;


	for (var i in roofPlaneTypes) {
		var key = i;
		var value = roofPlaneTypes[i];


		roofPlaneTypesArray[key] = value

	}


	assignImageToCanvas(bgImage);
	$("#currentImageSpanId").append(currentFileName.split("/")[2]);
	var roof_type_list = data.roof_type_list;
	console.log(roof_type_list);
	console.log(typeof (roof_type_list));

	var obj = JSON.parse(roof_type_list, function (key, value) {
		if (key != null && key != '') {
			$('#roofTypesListId')
				.append($('<option>', {
						value: value
					})
					.text(key));
		}
	});


	$('#opacityBar').change(function () {
		var val = $(this).val();

		if (toolObject.childCanvas == "false") {
			context.clearRect(0, 0, canvas.width, canvas.height);
			context.globalAlpha = val;
			//context.drawImage(opacityCanvas, 0, 0);
			context.drawImage(fgOriginalcanvas, 0, 0, canvas.width, canvas.height);
		} else {

			var canvasZoomTemp = document.createElement('canvas'),
				ctxcanvasZoomTemp = canvasZoomTemp.getContext('2d');

			canvasZoomTemp.width = canvas.width;
			canvasZoomTemp.height = canvas.height;
			ctxcanvasZoomTemp.globalAlpha = 1;
			ctxcanvasZoomTemp.drawImage(fgZoomBoxcanvas, 0, 0);

			fgZoomBoxcontext.clearRect(0, 0, canvas.width, canvas.height);
			fgZoomBoxcontext.globalAlpha = val;
			//context.drawImage(opacityCanvas, 0, 0);
			fgZoomBoxcontext.drawImage(canvasZoomTemp, 0, 0, canvas.width, canvas.height);
		}

		console.log(val);
	});

	$('#lineWidthBar').change(function () {
		var val = $(this).val();
		val = Math.round(val)
		console.log(val);
		toolObject.setLineWidth(val);
	});
	$(".wPaint-menu-icon-name-save").append('<i style ="font-size : 20px;" class="fa fa-save"</i>');
	$(".wPaint-menu-icon-name-reject").append('<i style = "font-size : 20px;" class="fa fa-remove"</i>');
	$(".wPaint-menu-icon-name-signout").append('<i style = "font-size : 20px;" class="fa fa-sign-out" aria-hidden="true"></i>');

});