from PIL import Image

img = Image.open('136fc5aa-5dda-416f-8cbd-21afccf0a856-rtcai-roofplane-6.tif')
# img = img.convert("RGBA")

pixdata = img.load()

width,height = img.size
print(img.getbands())
count = 0
for y in xrange(height):
    for x in xrange(width):
        # print(pixdata[x,y])
        if pixdata[x,y] != 0 :
            print(pixdata[x, y])
             # count = count + 1
#         if pixdata[x,y]  == (255,255,255,255):
#             pixdata[x,y] = (255,0,0)
#         if pixdata[x,y]  == (0,0,0,255):
#             pixdata[x,y] = (255,255,255,0)
#             pixdata[x, y] = int(255)
# img.save("test3.tif","PNG")


#
# print(count)
# print(int(255))