import json
import re

import requests
from flask import Flask, render_template, request, session,redirect
import numpy
import pytz
from simple_salesforce import Salesforce
from flask.json import jsonify

sf_rest = ''
class SFDCIntegrator:

    def __init__(self):
        global sf_rest
        print('hello')
        # sf_rest = Salesforce(username='supriya@triniti.com.onswitchde', password='Sridhar@123t',
        #                      security_token='0SaMaPogIXwKlo3S3eB3kAz4', domain='test') # dev

        sf_rest = Salesforce(username='supriya@triniti.com', password='Triniti@123',
                             security_token='T5rHqJkvn4yrBEWzV8vebymvg') #prod

    def queryLeads(self,email):
        generic_Domains = ['gmail.com','yahoo.com','hotmail.com']
        if (email is not None and email.find('@') != -1):
            domain = email[email.find('@')+1:]
            print(domain)
            if domain in generic_Domains:
                queryResult = sf_rest.query_all("select company,Quote_URL__c from lead where email='" + email + "'")
            else:
                print('in corporate domain specifics')
                queryResult = sf_rest.query_all("select company,Quote_URL__c from lead where email like '%" + domain + "' and Quote_Status__c='Quote Completed'")


        recordsList = queryResult['records']
        company = ''
        quoteurl = ''
        ownershipNameList = []
        returnDataList = []
        for eachRecord in recordsList:
            # if (company == ''):
            company = eachRecord.get('Company')

            if(eachRecord.get("Quote_URL__c") != None):
                quoteurl = eachRecord.get("Quote_URL__c")
                # company = eachRecord.get('Company')
                break

                # returnDataList.append(eachRecord)
        if (quoteurl == ''):
            return returnDataList,company

        # returnDataList = []
        print('company is',company)

        if (company != ''):
            returnDataList = self.queryAccountLeads(company)

        return returnDataList,company

    def queryAccountLeads(self,company):

        ownershipNameList = []
        returnDataList = []

        if (company != ''):
            print('before escape',company)
            company = company.replace("'","\\'")
            print('escaped company',company)
            leadResult = sf_rest.query_all("select company,Quote_URL__c,site_street__c,Site_City__c,Site_State__c,  System_Size__c,Purchase_Price_w__c,  Ownership_25_Yr_Savings__c from"
                                       " lead where company='%s' and Quote_Status__c='Quote Completed'" %company)

            # ownershipName = 'RossDressforLess20650'
            recordsList = leadResult['records']
            for eachRecord in recordsList:
                eachRecord.pop("attributes")
                print('quote url is -',eachRecord.get("Quote_URL__c"))
                if (eachRecord.get("Quote_URL__c") != None and eachRecord.get("Quote_URL__c") != ''):

                    ownershipName = eachRecord.get("Quote_URL__c").split('/')[-1]
                    # print ('ownership is ' , ownershipName)
                    if(ownershipName in ownershipNameList):
                        continue

                    ownershipNameList.append(ownershipName)
                    url = 'https://pengine.iq.onswitchenergy.com/portalengine/ws2/portal/info/name/' + ownershipName + '?complete=true'
                    # print(url)
                    wq_response = requests.request("GET", url)
                    # print(type(wq_response))
                    wq_data = wq_response.json()
                    # print('quotiing',wq_data)

                    if  wq_data is None or 'No portal found'  in wq_data:
                        continue

                    eachRecord["System_Size__c"] = round(wq_data['quote']['osSystemSize'])
                    eachRecord["Purchase_Price_w__c"] = round(wq_data['quote']['purchasePriceDollars'])

                    eachRecord["Purchase_Price_perwatt__c"] = round(wq_data['quote']['purchasePriceDollarsPerWatt'],2)

                    eachRecord["Ownership_25_Yr_Savings__c"] = round(wq_data['proforma']['totalSavings'])
                    # print(wq_data['esaProforma25Years']['solarElectricityYear1Price'])

                    if (wq_data['esaProforma25Years'] != None):
                        eachRecord["25_yr_kWH"] = round(wq_data['esaProforma25Years']['solarElectricityYear1Price'] ,3)
                    else:
                        eachRecord["25_yr_kWH"] = "0"
                    if (wq_data['esaProforma15Years'] != None):
                        eachRecord["15_yr_kWH"] = round(wq_data['esaProforma15Years']['solarElectricityYear1Price'] , 3)
                    else:

                        eachRecord["15_yr_kWH"] = "0"

                    if (wq_data['esa15Years'] != None):
                        eachRecord["15_netsavings"] = round(wq_data['esa15Years']['esaSavingsOverTerm'])
                    else:
                        eachRecord["15_netsavings"] = "0"

                    if (wq_data['esa25Years'] != None):
                        eachRecord["25_netsavings"] = round(wq_data['esa25Years']['esaSavingsOverTerm'])
                    else:
                        eachRecord["25_netsavings"] = "0"

                    if (wq_data['quote'] != None):
                        eachRecord["Utility_kWH"] = round(wq_data['quote']['avoidedCost'] , 3)
                    else:
                        eachRecord["Utility_kWH"] = "0"

                    eachRecord["Payback"] = wq_data['proforma']['paybackOn25YearLife']

                    returnDataList.append(eachRecord)
            # print('return data' ,returnDataList)
        return returnDataList

    def queryAccounts(self):


        queryResult = sf_rest.query_all("select  company from lead order by company")

        recordsList = queryResult['records']
        # print(recordsList)
        returnDataList = []
        for eachRecord in recordsList:
            # print('comp is ',eachRecord.get("Company"))
            if(eachRecord.get("Company") != None):
                company = eachRecord.get("Company")
                if company not in returnDataList:
                	returnDataList.append(company)

        return returnDataList

    def createLead(self,firstname,lastname,email,company,address,city,state_short,country,postal_code):
        xre = sf_rest.Lead.create(
			{
			# 'postalcode':'19087',
			# 'street':'Lancaster Ave',
			# 'City': 'Wayne',
			# 'State':'PA',
			# 'Country':'USA',
			'Company': company,
			'Email': email,
			'FirstName': firstname,
			'LastName': lastname,
			'LeadSource': 'OS-webpage',
			'Lead_Source_Details_P__c': '',
			'Lead_Source_Detail_T__c':'Buy Button Click',
			# 'Owner':'Vijay Ananthakrishnan',
            'Sales_Channel_del__c':'Direct/Inside Sales',
            #'Quote_Status__c':'Request new quote',
	        'Quote_Status__c': 'Request - New Quote',
            'Status' : "Open",
            'Positive_Customer_Response__c':"Yes",
                "Project_Sizing_Guidance__c":"Prioritize Economics – Lowest Cost/Watt",
                "Quote_Type__c":"Instant Web Quote",


            'Site_Street__c': address,
            'Site_City__c':city,
            'Site_State__c':state_short,
            'Site_Postal_Code__c':postal_code
		})
        print(xre)
        return  xre

app = Flask (__name__,static_url_path='/sfdc_integration/static')
app.secret_key = '123456'

@app.route('/sfdc_integration/main',methods=['GET'])
def home():
    integrator = SFDCIntegrator()
    # email = 'abid.saifee@onswitchenergy.com'
    resultList = ''
    email = ''
    if request.method == 'GET':
        email = request.args.get('user_email')
    # session['username'] = 'vgubbala@triniti.com'
    # if 'username' in session:
    # email = session['username']

    # email = 'fstephen.tr1i2@gmail.com'
    # email = 'vgubbala@triniti.com'
    # email = 'vijaygubbala@gmail.com'
    # email = 'sgrace.tri2@gmail.com'
    # email = 'vijay.ananthakrishnan@onswitchenergy.com'
    ownername = ''
    print('email is ',email)
    # if email != None and ('triniti.com' in email.lower() or 'onswitchenergy.com' in email.lower()):
    if email != None and ( 'onswitchenergy.com' in email.lower()):
        print ('success')
        accountslist = integrator.queryAccounts()
        print('list is ',accountslist)
        return render_template('admin_quotes.html',accountslist=accountslist)
    if email != None and email != '':
        resultList,ownername = integrator.queryLeads(email)

        # print(resultList)
    # print(resultList['records']['Company'])
    #     with open('sample.json') as json_file:
    #         resultList = json.load(json_file)
    #     ownername = "Pepsi"
    if(ownername != None and ownername != ''):

        if(len(resultList) == 0):
            return render_template("approvalpending.html")
        elif (len(resultList) == 1):
            print(resultList[0]['Quote_URL__c'])
            return redirect(resultList[0]['Quote_URL__c'])

        docs = json.dumps(resultList)
        print(docs)
        return render_template('opportunities.html', resultList=docs, ownername=ownername)
    else:
        return render_template('user_registration.html')
    # else:
    #     return render_template('login.html')
    # print(docs)



@app.route('/sfdc_integration/login', methods=['GET', 'POST'])
# @app.route('/', methods=['GET', 'POST'])
# @app.route('/login', methods=['GET', 'POST'])
def login_tool():
    """Serves the html page@ 0.0.0.0/qctool, 1. Populate LOV on load"""
    # qct = QcTool()
    # 1. Populate drop downs
    # session_images = qct.files_list('raw_images')
    # session_images = ''
    return render_template('login.html')

@app.route('/sfdc_integration/initiate_session', methods=[ 'POST'])
# @app.route('/', methods=['GET', 'POST'])
def initiate_session():
    """Serves the html page@ 0.0.0.0/qctool, 1. Populate LOV on load"""
    # qct = QcTool()
    # 1. Populate drop downs
    # session_images = qct.files_list('raw_images')
    # session_images = ''
    content = json.loads(request.data)
    # print content.keys()
    email = content['email']
    print('in initiate session email is-' + email)

    if email != '':
        session['username'] = email
        return 'success'
    else:
        return 'failed'

@app.route('/sfdc_integration/logout', methods=[ 'POST'])
def logout():
   # remove the username from the session if it is there
   if 'username' in session:
       username = session['username']
       print("in logout = user name is " + username)
   session.pop('username', None)
   return "success"

@app.route('/sfdc_integration/register', methods=[ 'POST'])
def register():
    # remove the username from the session if it is there
    # content = request.form
    content = json.loads(request.data)
    print(content)
    # content = json.loads(request.data)
    # print(content)
    firstname = content['firstname']
    lasttname = content['lastname']
    email = content['email']
    company = content['company']
    state_short=content['administrative_area_level_1']
    country = content['country']
    city = content['locality']
    postal_code = content['postal_code']
    route = content['route']
    street_number= content['street_number']
    address = ''
    if (street_number != None):
        address = street_number + ' '
    if (route != None):
        address = address + route

    print("address is ",address)
    integrator = SFDCIntegrator()
    result = integrator.createLead(firstname,lasttname,email,company,address,city,state_short,country,postal_code)
    if(result != None):
        if(result['success'] == 'True'):
            return "success"
        else:
            return "failed"
    return "failed"

@app.route('/sfdc_integration/getAccountDetails', methods=[ 'POST'])
def accountDetails():
    # remove the username from the session if it is there
    content = json.loads(request.data)
    print(content)
    # content = json.loads(request.data)
    # print(content)
    account = content['account']
    integrator = SFDCIntegrator()
    result = integrator.queryAccountLeads(account)

    print('after return result is ' , result)
    return jsonify({'accountsList': result})

if __name__ == '__main__':
    app.run(debug=True)

