from __future__ import division

import io
import os
import base64
import json
import traceback
import urllib

import pymysql
import requests
import requests as req
import random
import time
# import custom scripts
from pymysql import DatabaseError

from Logger import Logger
import CommonUtils as utils
from flask import session

s3 = ''


class DbHelper:
    """Class contains helper methods"""

    CRITICAL = 50
    FATAL = CRITICAL
    ERROR = 40
    WARNING = 30
    WARN = WARNING
    INFO = 20
    DEBUG = 10
    NOTSET = 0
    pendinginqueue = 0

    def __init__(self):
        self.conn = ''
        self.properties = utils.getPropertyFile()
        self.logger = Logger()

    def log(self,level, message):
        # print("level is-",level)
        Logger.log(level,self.__class__.__name__, message)
        print(message)

    def db_session(self):
        """Connect to db and return cursor object"""
        if self.conn == '' or (not self.conn.open):
            self.conn = pymysql.connect(host=self.properties.get('MYSQL', 'HOST'),
                                        user=self.properties.get('MYSQL', 'USER'),
                                        password=self.properties.get('MYSQL', 'PASSWORD'),
                                        db=self.properties.get('MYSQL', 'DB'),
                                        cursorclass=pymysql.cursors.DictCursor)
        if (not self.checkConn(self.conn)):
            self.conn.close()
            self.conn = ''
            return self.db_session()

        return self.conn

    def checkConn(self, conn):
        sq = "SELECT NOW()"

        try:
            cursor = conn.cursor()
            cursor.execute(sq)
            return True
        except Exception as e:
            desired_trace = traceback.format_exc()
            self.log(self.DEBUG, "DB Connection failed {}".format(desired_trace))
            return False

    def getUserBasedDetails(self,email,rootvalue):
        try:
            url  = rootvalue+"qctool/getUserBasedDetails?email="+email+"&jsonFlag=True"
            alldetails = requests.request("GET", url)
            return alldetails.json()
        except Exception:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,": Error in getUserBasedDetails {}".format( desired_trace))

    def getPendingIdsCount(self):
        self.pendinginqueue = 0;
        # Umcomment below code when they start sending count in COUNT_SERVICE_URL
        try:
            url = self.properties.get('DB_SERVICE', 'COUNT_SERVICE_URL')

            dbservice1_response = requests.request("GET", url)
            alldetails = dbservice1_response.json()
            if 'pendinginqueue' in alldetails:
                self.pendinginqueue = int(alldetails['pendinginqueue'])
                self.log(self.DEBUG , "Pending In Queue Are {}".format(self.pendinginqueue))
        except Exception:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR,
                     ": Error in getPendingIdsCount {}".format( desired_trace))

    def onswitchdb_get_uid(self, username):
        """return uid where status = inprogress"""
        # TODO Insert the time based in
        uuid = None
        address = None

        addr = Address()
        addr.setQCT(self)
        inProgresslist = 0
        try:
            conn = self.db_session()
            cursor = conn.cursor()
            self.getPendingIdsCount()
            inProgresslist += self.pendinginqueue
            #2019-06-04 16:23:27
            sql = "SELECT Image_Key ,Address FROM onswitchdb.XX_QCTOOL_LOG WHERE Status in ('IN-PROGRESS') and TIMESTAMPDIFF(SECOND,Last_Updated_On ,now()) >=600   and workflow_state='bizinfo'"

            self.log(self.DEBUG, "sql is : {}".format(sql))
            cursor.execute(sql)
            response = cursor.fetchall()
            uid_list = []
            if response is not None:
                for i in range(len(response)):
                    addressList = []
                    # print(response[i]['Image_Key'])
                    # print(response[i]['Address'])
                    addressList.append(response[i]['Address'])
                    addressList.append(response[i]['Image_Key'])
                    uid_list.append(addressList)
            if len(uid_list) > 0:
                inProgresslist += len(uid_list) - 1

                print(inProgresslist)
                self.log(self.DEBUG, "There is Inprogress list in bizinfo")
                addressList = random.choice(uid_list)
                self.log(self.DEBUG, "addressList is : {}".format(addressList))
                self.onswitchdb_update(uid = addressList[1], status = 'IN-PROGRESS')
                # self.onswitchdb_update_tracking(uid=addressList[1])
                self.onswitchdb_insert_tracking(uid=addressList[1], username=username,comments='IN-PROGRESS')
                return addressList[0],addressList[1],inProgresslist
            else:
                self.log(self.DEBUG,"Need to get the new UID and insert into database")

                address,uuid = addr.get_address_uuid()
                # inProgresslist = self.pendinginqueue
                self.log(self.DEBUG,"InProgresslist After getting one uid is {}".format(inProgresslist))
                self.log(self.DEBUG,"self.pendinginqueue After getting one uid is {}".format(self.pendinginqueue))

                # address,uuid = '3000 E. Philadelphia', '2d67e209-420d-4096-9ba5-26f9b42c1f18'
                if uuid is not None and address is not None:
                    self.onswitchdb_insert(uid=uuid, status='IN-PROGRESS', username=username,address1 = address)
                    # self.onswitchdb_update_tracking(uid = uuid)
                    self.onswitchdb_insert_tracking(uid = uuid,username = username,comments='IN-PROGRESS')
                return address,uuid,inProgresslist


        except Exception as e:
            desired_trace = traceback.format_exc()
            self.log(self.ERROR, "exception is : {}".format(desired_trace))

            # conn.rollback()
        return address,uuid,inProgresslist

    def onswitchdb_insert(self, uid, status, username , address1):
        """Take uid, status and insert as a row in the data base"""
        records = 0
        try:
            sql = "INSERT INTO onswitchdb.XX_QCTOOL_LOG(Image_Key,Address,Status,User,Engaged,workflow_state,created_on)" \
                  " VALUES ('" + uid + "','"+address1+"','"+ status + "','" + username + "','YES','bizinfo','" + time.strftime('%Y-%m-%d %H:%M:%S') + "')"
            self.log(self.DEBUG, "sql is : {}".format(sql))
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            cursor.close()
            conn.commit()
            self.log(self.DEBUG,"Inserted New UID and Status into XX_QCTOOL_LOG table successfully")
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.DEBUG, "UID onswitchdb_insert failed with uid {} trace {}".format(uid, desired_trace))
        return records

    def onswitchdb_update(self, uid, status):
        """Take uid,status and update the status column of the table"""
        records = 0
        try:
            sql = "UPDATE onswitchdb.XX_QCTOOL_LOG SET Status = '" + status + "',Last_Updated_On='" + time.strftime(
                '%Y-%m-%d %H:%M:%S') + "' WHERE " \
                                       "Image_Key = '" + uid + "' and workflow_state='bizinfo' "
            self.log(self.DEBUG, "sql is : {}".format(sql))
            conn = self.db_session()
            cursor = conn.cursor()
            records = cursor.execute(sql)
            cursor.close()
            conn.commit()
            self.log(self.DEBUG, "Updated the Status in XX_QCTOOL_LOG table successfully")
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.DEBUG, "UID onswitchdb_update failed with uid {} trace {}".format(uid, desired_trace))
        return records

    def onswitchdb_update_tracking(self, uid):
        """Take uid,status and update the status column of the table"""
        try:
            sql = "UPDATE onswitchdb.XX_QCTOOL_LOG_TRACKING SET Last_Updated_On='" + time.strftime(
                '%Y-%m-%d %H:%M:%S') + "' WHERE " \
                                       "Image_Key = '" + uid + "' and current_step='bizinfo' and Last_Updated_On is null"

            self.log(self.DEBUG, "sql is : {}".format(sql))
            conn = self.db_session()
            cursor = conn.cursor()
            cursor.execute(sql)
            cursor.close()
            conn.commit()
            self.log(self.DEBUG, "Updated the Status in XX_QCTOOL_LOG_TRACKING table successfully")
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.DEBUG, "UID onswitchdb_update_tracking failed with uid {} trace {}".format(uid, desired_trace))
        return

    def onswitchdb_insert_tracking(self, uid, username,comments):
        """Take uid, status and insert as a row in the data base"""
        try:
            sql = "INSERT INTO onswitchdb.XX_QCTOOL_LOG_TRACKING(image_key,user,current_step,started_on,comments) VALUES ('" + uid + "','" + username + "'," \
                "'bizinfo','" + time.strftime('%Y-%m-%d %H:%M:%S') + "','" + comments + "')"
            self.log(self.DEBUG, "sql is : {}".format(sql))
            conn = self.db_session()
            cursor = conn.cursor()
            cursor.execute(sql)
            cursor.close()
            conn.commit()
            self.log(self.DEBUG, "Inserted New UID and Status into XX_QCTOOL_LOG table successfully")
        except Exception as ex:
            desired_trace = traceback.format_exc()
            self.log(self.DEBUG, "UID onswitchdb_insert_tracking failed with uid {} trace {}".format(uid, desired_trace))
        return
    def validateSession(self,token2):
        email = ''
        try:
            addr = Address()
            # CLIENT_ID = '39080003413-ld4rv4c123cvrmchpfn6s99lg221sod6.apps.googleusercontent.com'
            # Specify the CLIENT_ID of the app that accesses the backend:
            # idinfo = id_token.verify_oauth2_token(token, requests.Request(), CLIENT_ID)

            url = 'https://oauth2.googleapis.com/tokeninfo?access_token=' + token2
            # params = {'access_token': token2}
            r = req.get(url=url, params=None)

            data = r.json()
            if 'email' in data:
                self.log(self.DEBUG, "The Email Id form google Api is {}".format(data['email']))
                # print("The Email Id form google Api is {}".format(data['email']))
                email = data['email']
                # print('email is ', email)
            elif 'error' in data:
                self.log(self.DEBUG, "The session is either Expired/Signed out  for token {}".format(session['token2']))
                # print("The session is either Expired/Signed out  for token {}".format(session['token2']))
                if 'token2' in session:
                    self.log(self.DEBUG, "The session Expired for token {}".format(session['token2']))
                    # print("The session Expired for token {}".format(session['token2']))
                    if 'refreshToken' in session:
                        self.log(self.DEBUG, "Getting refresh Token {}")
                        # print("Getting refresh Token ")
                        access_token = addr.refreshToken(session['refreshToken'])
                        self.log(self.DEBUG, "The New Access  token generated is {}".format(access_token))
                        # print("The New Access  token generated is {}".format(access_token))
                        if access_token is not None:
                            session['token2'] = access_token
                            email = self.validateSession(access_token)
                            # print("Here It is ",email)
        except ValueError:
            # Invalid token
            self.log(self.ERROR, "The value error {}".format(ValueError))
            # print('the value error',ValueError)
            pass
        except KeyError:
            self.log(self.ERROR, "The KeyError  {}".format(KeyError))
            # print('error')
            return 'error'
        return email
class Address:

    dbhelper = None

    def setQCT(self,qctobj):
        global dbhelper
        dbhelper = qctobj

    def name_method(self,lat,lng):

        # url1 = "https://pipeengine.onswitchenergy.com/pipelineengine/ws2/pipeline/building-info"
        url1 = " https://pengine.iq.onswitchenergy.com/portalengine/ws2/pipeline/bizinfo/search"

        parameters = {'lat' :lat,'lng' : lng }

        address = requests.get(url1, params=parameters)
        dbhelper.log(dbhelper.DEBUG, "address is : {}".format(address.text))
        # test = '[{"googleBizName":"Silicon Valley Leadership Group","onswitchAccountName":"test","types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Four County Development Inc","onswitchAccountName":"vijay","types":"[general_contractor, point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Pluto Labs","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Red Oak Technologies","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Triniti Corporation","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Zumigo","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Star Cafe","onswitchAccountName":null,"types":"[cafe, point_of_interest, food, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/cafe-71.png"},{"googleBizName":"Randstad Office & Administration","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/civic_building-71.png"},{"googleBizName":"Ultimate Staffing Services","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/civic_building-71.png"},{"googleBizName":"Cargotec Holdings Inc","onswitchAccountName":null,"types":"[finance, point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Relevance Lab Inc","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"MCA","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Gary R Nagle Inc","onswitchAccountName":null,"types":"[lawyer, point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Systech Integrators Inc","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"All In One Inc","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/civic_building-71.png"},{"googleBizName":"Emedia Systems","onswitchAccountName":null,"types":"[electronics_store, home_goods_store, store, point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/shopping-71.png"},{"googleBizName":"High Street Partners Inc","onswitchAccountName":null,"types":"[finance, point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Ondot System","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Tamura Kaken Corp USA","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"},{"googleBizName":"Oficina Regional Rocketship","onswitchAccountName":null,"types":"[point_of_interest, establishment]","permanentlyClosed":false,"phoneNumber":null,"url":"https://maps.gstatic.com/mapfiles/place_api/icons/generic_business-71.png"}]'
        details = json.loads(address.text)
        # details = json.loads(test)
        # print(details)
        # placeSearchResults = details['placeSearchResults']
        #
        # name =[]
        # eachRecord = {}
        #
        # for i in range(len(placeSearchResults)):
        #     name.append(placeSearchResults[i]['name'])

        # print(name)
        return details

    def get_lat_lng(self,address):
        apikey = 'AIzaSyCgBHnic5QHQDOMyMogroyhXSwQoWkF9yg'
        lat = None
        lng = None
        formatted_add = None
        # address = address
        try:

            url_geocoding = "https://maps.googleapis.com/maps/api/geocode/json?address=" + urllib.quote(address) + "&key=" + apikey
            dbhelper.log(dbhelper.DEBUG, "url_geocoding : {}".format(url_geocoding))
            response_geocoding = requests.request("GET", url_geocoding)
            json_geocoding = response_geocoding.json()
            # dbhelper.log(dbhelper.DEBUG, "json_geocoding : {}".format(json_geocoding))

            lat = json_geocoding['results'][0]['geometry']['location']['lat']
            lng = json_geocoding['results'][0]['geometry']['location']['lng']
            formatted_add = json_geocoding['results'][0]['formatted_address']

            dbhelper.log(dbhelper.DEBUG, "Lattitude is : {} , Longitude is : {} , Formatted address is : {} ".format(lat,lng,formatted_add))


        except Exception as ex:
            desired_trace = traceback.format_exc()
            dbhelper.log(dbhelper.ERROR, "Exception is : {}".format(desired_trace))

        return lat, lng, formatted_add
    def get_address_uuid(self):
        fullAddress = None
        dbhelper.log(dbhelper.DEBUG, "getting details....")
        uuid = None
        try:
            url = dbhelper.properties.get('DB_SERVICE', 'ELECT_SERVICE_URL')
            # url = "https://pengine.iq.onswitchenergy.com/portalengine/ws2/pipeline/bizinfo/elect"

            dbhelper.log(dbhelper.DEBUG, "ELECT_SERVICE_URL is : {}".format(url))
            get_address = requests.get(url)
            alldetails = json.loads(get_address.text)
            dbhelper.log(dbhelper.DEBUG, "Details are : {}".format(alldetails))

            # if 'pendinginqueue' in  alldetails:
            #     dbhelper.pendinginqueue = int(alldetails['pendinginqueue'])
            #     dbhelper.log(dbhelper.DEBUG , "Pending In Queue Are {}".format(dbhelper.pendinginqueue))

            details = alldetails['pipelineaddress']
            # fullAddress = ''
            if (details is None):
                return None,None
            if 'address' in details:
                address = str(details['address'])
                fullAddress = address + ", "
            if 'city' in details:
                city = str(details['city'])
                fullAddress = fullAddress + city + ", "
            if 'state' in details:
                state = str(details['state'])
                fullAddress = fullAddress  + state + ", "
            # address = address + " ," + city + " ," + state
            if 'zip' in details:
                zip = str(int(float( details['zip'])))

                fullAddress = fullAddress + zip
            uuid = str(details['uuid'])
            dbhelper.log(dbhelper.DEBUG, "fullAddress is : {} , uuid is : {} ".format(fullAddress,uuid))
        except Exception as ex:
            dbhelper.log(dbhelper.ERROR, "erroring out  : {}  ".format(ex))
            pass
        return fullAddress,uuid

    def db_service2_process_log(self, uuid, comments, stepName, baseStatus):
        """Receive the uuid,stepName, baseStatus parameters and update the db service accordingly """
        try:
            # url = 'https://pengine.iq.onswitchenergy.com/portalengine/ws2/pipeline/process-log/create'
            url = dbhelper.properties.get('DB_SERVICE', 'PROCESS_SERVICE_URL')
            payload = {
                        "uuid": uuid,
                        "stepName": stepName,
                        "baseStatus": baseStatus,
                        "comments": comments
                      }
            headers = {'content-type': 'application/json'}
            r = requests.post(url, data=json.dumps(payload), headers=headers)

            if eval(str(r.content)) == 'success':
                return "success"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            dbhelper.log(dbhelper.ERROR, "erroring out  : {}  ".format(desired_trace))
            pass
        return "fail"

    def db_service4_publish(self,uuid,payload):
        """Takes uuid, updates db service that qc1 and qc2 are completed"""
        # url = 'https://pipeengine.onswitchenergy.com/pipelineengine/ws2/pipeline/v2/bizinfo/publish/'+uuid
        try:
            url = dbhelper.properties.get('DB_SERVICE', 'PUBLISH_SERVICE_URL')
            url = url + uuid
            dbhelper.log(dbhelper.DEBUG, "url is  : {}  ".format(url))
            dbhelper.log(dbhelper.DEBUG, "payload is  : {}  ".format(payload))
            headers = {'content-type': 'application/json'}
            r = requests.post(url, data=json.dumps(payload), headers=headers)
            dbhelper.log(dbhelper.DEBUG, "content is  : {}  ".format(r.content))
            if (str(r.content)) == 'Success':
                return "Success"
        except Exception as ex:
            desired_trace = traceback.format_exc()
            dbhelper.log(dbhelper.ERROR,"exception {}".format(desired_trace))
            return "fail"
        # r = requests.post(url)
        # print("from dgservice4")
        # return "success"

    def userSecurityCheck(self,session):
        if 'username' in session and 'token2' in session:
            dbhelper.log(dbhelper.DEBUG, "username and  token2  are in session..")
            # print("username and  token2  are in session..")
            token2 = session['token2']
            if token2 is not None:
                email = dbhelper.validateSession(token2)
                if email is not '' and email is not 'error':
                    dbhelper.log(dbhelper.DEBUG, "Token validated Successfully")
                    # print("Token validated Successfully")
                    if 'applicationList' in session:
                        dbhelper.log(dbhelper.DEBUG, "applicationList is in session")
                        # print("applicationList is in session")
                        if 'address_portal' in session['applicationList']:
                            dbhelper.log(dbhelper.DEBUG, "address_portal is in applicationList")
                            # print("qctool is in applicationList")
                            return True
                        else:
                            dbhelper.log(dbhelper.DEBUG, "address_portal is not in applicationList")
                            return False
                    else:
                        dbhelper.log(dbhelper.DEBUG, "applicationList is not in session")
                        return False
                else:
                    dbhelper.log(dbhelper.DEBUG, "email is  '' or  error : {}".format(email))
                    # print("email return is", email)
                    return False
            else:
                dbhelper.log(dbhelper.DEBUG, "Token 2 is None ")
                return False
        else:
            dbhelper.log(dbhelper.DEBUG, "username and  token2  are not in session..")
            return False

    def refreshToken(self, refresh_token):
        dbhelper.log(dbhelper.DEBUG, "Inside refreshToken Method.. refresh_token is : {}".format(refresh_token))
        client_id = None
        client_secret = None
        CLIENT_SECRET_FILE = dbhelper.properties.get('GSign-In', 'Client_Secret')
        # print(CLIENT_SECRET_FILE)
        with open(CLIENT_SECRET_FILE, 'r') as f:
            distros_dict = json.load(f)

        if 'web' in distros_dict:
            web = distros_dict['web']
            if 'client_id' in web:
                client_id = web['client_id']
            if 'client_secret' in web:
                client_secret = web['client_secret']

        params = {
            "grant_type": "refresh_token",
            "client_id": client_id,
            "client_secret": client_secret,
            "refresh_token": refresh_token
        }

        authorization_url = "https://www.googleapis.com/oauth2/v4/token"

        r = requests.post(authorization_url, data=params)

        if r.ok:
            dbhelper.log(dbhelper.DEBUG, "Access Token refreshed Successfully . The new Access token is : {}".format(
                r.json()['access_token']))
            print("Access Token refreshed Successfully . The new Access token is : {}".format(r.json()['access_token']))
            return r.json()['access_token']
        else:
            dbhelper.log(dbhelper.DEBUG, "Access Token is not refreshed . Returning None")
            print("Access Token is not refreshed . Returning None")
            return None
