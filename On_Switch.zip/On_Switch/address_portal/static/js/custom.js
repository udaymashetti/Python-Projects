var tem=localStorage.getItem('_details');
var marker;

	if(tem=== null){
		//window.location.href = "https://onswitchenergy.com/";
	}
//	var address = localStorage.getItem('_address');
	var address = '2001 Gateway Place Suite 425E San Jose, CA   95110';
	$("#display-addr").html(address);
	/*var v = JSON.parse(tem);

	var text = "";
	for (var i = 0; i < v.length; i++) { 
    		text += v[i];
		}
	for (var i=0; i<v.length; i++){
	}

	var optionsAsString = "";
	for(var i = 0; i < v.length; i++) {
    		optionsAsString += "<option value='" + v[i].companyName + "'>";
	}

	$( 'datalist[name="daorg"]' ).append( optionsAsString );*/
	
	function selectFunction(){
		var text = document.getElementById('org-name').value;
		getPortalIdBasedOnOrganization(text);
	}	

	function getPortalIdBasedOnOrganization(orgName){
		var portalId = null;
		var portalUrl = null
		for (var i=0; i<v.length; i++){
			if(orgName === v[i].companyName){
	   			portalId =  v[i].portalId;
           			portalUrl = v[i].portalUrl;
				break;
		}	
       }  
		if(portalId != null){
			document.getElementById('portalUrl').value = portalUrl;
		        document.getElementById('portalId').value = portalId;

		}else {
			document.getElementById('portalUrl').value = null;
			document.getElementById('portalId').value = null;
			document.getElementById('standbyPortalId').value = v[0].portalId;
		}	

	}

//document.getElementById('standbyPortalId').value = v[0].portalId;

function initMap() {


    // var lati = {{ latitude|safe  }};
       // var lngi = {{ longitude|safe }};
	var map = new google.maps.Map(document.getElementById('map_canvas'), {
        zoom: 19,
        center: {lat : {{ latitude|safe  }}, lng : {{ longitude|safe }}},
	mapTypeId: 'satellite'
        });

        var geocoder = new google.maps.Geocoder();
		geocodeAddress(geocoder, map);

google.maps.event.addListener(map, 'click', function(event) {
  geocoder.geocode({
    'latLng': event.latLng
  }, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
      if (results[0]) {
        // alert(results[0].formatted_address);
      }
    }
  });
  marker.setVisible(false);
   marker = new google.maps.Marker({
	position: event.latLng,
	map: map,
	title: 'Hello World!'
  });
});
		


        }

        function geocodeAddress(geocoder, resultsMap) {
        geocoder.geocode({'address': address }, function(results, status) {
          if (status === 'OK') {
             resultsMap.setCenter(results[0].geometry.location);
              marker = new google.maps.Marker({
              map: resultsMap,
              position: results[0].geometry.location
             });
          } else {
            alert('Geocode was not successful for the following reason: ' + status);
          }
          });
          }
		  
			function getStaticMap( ) {
				var geocoder = new google.maps.Geocoder();
				geocoder.geocode({'address': address }, function(results, status) {
				if (status === 'OK') {
					var latitude = results[0].geometry.location.lat(),
                                 longitude = results[0].geometry.location.lng();
					var centerLongitude 	=	longitude - .0006;
					var staticMapUrl = "https://maps.googleapis.com/maps/api/staticmap";
					staticMapUrl += "?center=" + latitude +"," + centerLongitude ;

					//Set the Google Map Size.
					staticMapUrl += "&size=780x960";
					//Set the Google Map Zoom.
					//staticMapUrl += "&zoom=" + mapOptions.zoom;
					 staticMapUrl += "&zoom= 18";
					  staticMapUrl += "&style=visibility:on";

					 //Set the Google Map Type.
					staticMapUrl += "&maptype=satellite";
					//staticMapUrl += "&markers=size:mid%7Ccolor:red%7C" + latitude +"," + longitude ;
					//staticMapUrl += "&markers=size:mid%7C" + latitude +"," + longitude ;
					staticMapUrl += "&markers=icon:/img/pin.png%7Csize:mid%7C" + latitude +"," + longitude ;
					staticMapUrl += "&scale=2";
					staticMapUrl += "&visible=" + latitude +"," + longitude ;
					staticMapUrl += "&key=AIzaSyCZngbjZg42KCIdQQhmrCGVfjCLAneb7lo"; //onswitch
					
					//$('div#map_canvas').css("background-image", "url('" +  staticMapUrl + "')");
					//alert(staticMapUrl);
					$("#map_canvas").css('background-image', 'none');
					$('.map').css("background-image", "url('" +  staticMapUrl + "')");
				} else {
					alert('Geocode was not successful for the following reason: ' + status);
				}
			  });
			  
			  //$('#map_canvas').css("background-image", "url(/myimage.jpg)");
          }

initMap();
// getStaticMap( );
localStorage.clear();
