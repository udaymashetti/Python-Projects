function handleSignOutClick(event) {
console.log("this signout");

var r = confirm("Do you want to sign-out?");
if (r == true) {
var accesstoken = "";
$.ajax(
{
url: "/qctool/signout",
async : false,
success: function(response){

	window.location.href='login';
}
});

/* $.ajax(
{
async : false,
url: "https://accounts.google.com/o/oauth2/revoke?token="+accesstoken,
success: function(result){

window.location.href='login';
}
}); */

} else {
return;
}
}