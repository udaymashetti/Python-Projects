#############################################
# File handle common utility functions      #
#############################################
# import libs
import os
# import custom scripts
from configparser import ConfigParser


def getPropertyFile():
    """Method returns a config object for the configuration file"""
    cfg = ConfigParser()
    cfg.read(os.path.join(os.curdir, "config", "properties.ini"))
    return cfg

