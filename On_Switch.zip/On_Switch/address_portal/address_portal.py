import traceback
import urllib


import requests
import json
import pymysql
import time
from flask import Flask, render_template, request, session, jsonify,redirect
from Qc import DbHelper, Address

app = Flask(__name__, static_url_path='/address_portal/static')
app.secret_key = '123456'
db_helper = DbHelper()
add = Address()
add.setQCT(db_helper)


@app.route('/address_portal/main', methods=['GET'])
def home():
    userName = None
    token2 = None
    if 'username' in session:
        userName = session['username']

    if 'token2' in session:
        token2 = session['token2']

    value = request.url_root;
    session['rootvalue'] = value

    if userName is not None:
        # token2 = request.args.get('token2')
        # token2 = session['token2']
        if token2 is not None:
            email = db_helper.validateSession(token2)
            if email is not '' and email is not 'error':
                redirectToValue = db_helper. getUserBasedDetails(email,value)
                if redirectToValue is 'approvalPending':
                    return redirect(value+"qctool/approvalPending")
                else:
                    if 'address_portal' in redirectToValue:
                        return render_template('index.html')
                    else:
                        return redirect(value+'qctool/home')
            else:
                session.pop('username', None)
                session.pop('token2', None)
                return redirect(value + "qctool/login")
        else:
            return redirect(value + "qctool/login")
    else:
        return redirect(value + "qctool/login")

    # return render_template('index.html')


@app.route('/address_portal/reject', methods=['POST'])
def rejectImage():
    """3b receive modified image and upload to S3"""
    # add = Address()
    # db = DbHelper()
    userCheck = add.userSecurityCheck(session)
    db_helper.log(db_helper.DEBUG, " User SecurityCheck Flag while rejecting  is : {} ".format(userCheck))
    if userCheck is True:
        try:
            content = json.loads(request.data)
            businessObject = content['businessObject']
            db_helper.log(db_helper.DEBUG, 'BusinessObject IS: {}'.format(businessObject))
            uuid = businessObject['uuid']
            comments = businessObject['comments']
            add.db_service2_process_log(uuid, comments, stepName='bizinfo', baseStatus='Reject')
            # TODO 7b. update onswitch_db() with status = Rejected
            db_helper.onswitchdb_update(uuid, status='REJECTED')
            # db_helper.onswitchdb_update_tracking(uuid)
            db_helper.onswitchdb_insert_tracking(uid=uuid, username='', comments='REJECTED')
        except Exception as ex:
            desired_trace = traceback.format_exc()
            db_helper.log(db_helper.DEBUG, "UID rejectImage failed with trace {}".format(desired_trace))
        return 'Image Rejected'
    else:
        return "home"


@app.route('/address_portal/updateBusinessDetails', methods=['POST', 'GET'])
def updateBusinessDetails():
    # add = Address()
    # db = DbHelper()
    userCheck = add.userSecurityCheck(session)
    db_helper.log(db_helper.DEBUG, " User SecurityCheck Flag while updating  is : {} ".format(userCheck))
    if userCheck is True:
        try:
            if request.method == 'POST':
                content = json.loads(request.data)
                # content = json.dumps(json.loads(request.data))
                # print(content)
                businessObject = content['businessObject']
                db_helper.log(db_helper.DEBUG, 'BusinessObject IS: {}'.format(businessObject))
                uuid = businessObject['uuid']
                add.db_service2_process_log(uuid, 'UPDATING  STATUS AS COMPLETE', stepName="bizinfo", baseStatus='complete')
                add.db_service4_publish(uuid, businessObject)
                db_helper.onswitchdb_update(uuid, status='PUBLISHED')
                # db_helper.onswitchdb_update_tracking(uuid)
                db_helper.onswitchdb_insert_tracking(uid=uuid, username='', comments='PUBLISHED')
                return "success"
            # print request
        except Exception as ex:
            desired_trace = traceback.format_exc()
            db_helper.log(db_helper.DEBUG, "UID updateBusinessDetails failed with trace {}".format(desired_trace))
            return "Fail"
    else:
        return "home"



@app.route('/address_portal/businessdetails', methods=['POST', 'GET'])
def businessdetails():
    # db = DbHelper()
    add = Address()
    userCheck = add.userSecurityCheck(session)
    db_helper.log(db_helper.DEBUG, " User SecurityCheck Flag while getting details  is : {} ".format(userCheck))
    if userCheck is True:
        if request.method == 'POST':
            content = json.loads(request.data)
            db_helper.log(db_helper.DEBUG, 'Content IS: {}'.format(content))
            lat = content['lat']
            lng = content['lng']
            latint = float(lat)
            lngint = float(lng)
            db_helper.log(db_helper.DEBUG, 'latint is: {}'.format(latint))
            db_helper.log(db_helper.DEBUG, 'lngint is: {}'.format(lngint))
            businessDetails = add.name_method(latint, lngint)
            session['businessname'] = businessDetails
            # db.onswitchdb_update(uid, status='PUBLISHED')
            # db.onswitchdb_update_tracking(uid)
            # print (businessDetails)
            # data = json.dumps(businessDetails)
            # print(data)
            return jsonify({'businessDetails': businessDetails})
    else:
        return "home"


@app.route('/address_portal/addressDetails', methods=['POST', 'GET'])
def getAddressDetails():
    userName = ''
    inPipeLineimages = 0
    if 'username' in session:
        userName = session['username']
    # userName = session['username']
    # Replace with service from where we get the address
    # address = '2001 Gateway Place Suite 425E San Jose, CA   95110'
    # uuid = None

    address, uuid,inPipeLineimages = db_helper.onswitchdb_get_uid(userName)
    db_helper.log(db_helper.DEBUG, "inPipeLineimages {}".format(inPipeLineimages))
    # address = None

    if address is None and uuid is None:
        db_helper.log(db_helper.DEBUG, "Address and UID are none")
        return jsonify({"latitude": '', "longitude": '', "address": 'None', "uuid": uuid, "formatted_address": '',"pipeLineCount" : ''})

    elif address is None:
        db_helper.log(db_helper.DEBUG, 'ADDRESS IS NONE SO ERRORING OUT : {}'.format(uuid))
        add.db_service2_process_log(uuid, 'ADDRESS IS NONE SO ERRORING OUT', stepName='bizinfo', baseStatus='error')
        db_helper.onswitchdb_update(uuid, status='Error')
        # db_helper.onswitchdb_update_tracking(uuid)
        db_helper.onswitchdb_insert_tracking(uid=uuid, username=userName, comments='ADDRESS IS NONE SO ERRORING OUT')
        return home()
    db_helper.log(db_helper.DEBUG, 'UUID IS: {}'.format(uuid))
    add.db_service2_process_log(uuid, 'UPDATING  STATUS AS INPROGRSS', stepName='bizinfo', baseStatus='inprogress')
    lat, lng, formatted_add = add.get_lat_lng(address)

    if (lat is None or lng is None):
        db_helper.log(db_helper.DEBUG, "LAT OR LONG IS NULL SO ERRORING OUT")
        add.db_service2_process_log(uuid, 'LAT OR LONG IS NULL SO ERRORING OUT', stepName='bizinfo', baseStatus='error')
        db_helper.onswitchdb_update(uuid, status='Error')
        # db_helper.onswitchdb_update_tracking(uuid)
        db_helper.onswitchdb_insert_tracking(uid=uuid, username=userName,
                                             comments='LAT OR LONG IS NULL SO ERRORING OUT')
        return home()

    # businessDetails = add.name_method(lat, lng)

    # data = json.dumps(businessDetails)
    # data = ''
    # uuid = '123456789'
    db_helper.log(db_helper.DEBUG, "inPipeLineimages befor sending to html {}".format(inPipeLineimages))

    return jsonify(
        {"latitude": lat, "longitude": lng, "address": address, "uuid": uuid, "formatted_address": formatted_add,"pipeLineCount":inPipeLineimages})

@app.route('/address_portal/home', methods=['GET'])
def home1():
    if 'rootvalue' in session:
        root = session['rootvalue']
        return redirect(root+"qctool/home")

@app.route('/address_portal/login', methods=['GET'])
def login():
    value = session['rootvalue']
    return redirect(value + "qctool/login")



if __name__ == '__main__':
    app.run(host = '0.0.0.0')
    # app.run(debug=True,port=5009)

