import sys

import requests
import json
from simple_salesforce import Salesforce
from flask import Flask, render_template, request, session, redirect, jsonify
from collections import OrderedDict as odict

sf_rest = Salesforce(username='supriya@triniti.com', password='Triniti@123',
                             security_token='T5rHqJkvn4yrBEWzV8vebymvg')
headers = {
    'access_token': "",
    'permalink': ''
}

refresh_token_headers = {
    "client_id": "SaeuNo46",
    "client_secret": "NQHhrsAvWmfJzNRl53kqfIwpFlybOqwbne7YA1L1SGY7ZT2qHPJPmerqe37RAshJ",
    "grant_type": "refresh_token",
    "refresh_token": "eyJ0dCI6InAiLCJhbGciOiJIUzI1NiIsInR2IjoiMSJ9.eyJkIjoie1wiYVwiOjE4OTA0NjMsXCJpXCI6NjI2MjA5MSxcImNcIjo0NjExNTM4LFwidlwiOlwiXCIsXCJ1XCI6MzczNTcwOSxcInJcIjpcIlVTXCIsXCJzXCI6W1wiUlwiXSxcInpcIjpbXCJyc2hcIl0sXCJ0XCI6MTU1OTk4MDM4NjAwMH0iLCJleHAiOjE1NTk5ODAzODYsImlhdCI6MTU1OTk3Njc4Nn0.tSfTMXGQ4YdenAIzdgnU6mNWH8xqpCL8AiaWbAtYslQ"
}

class Project_Portal:

    def ProjectRisks(self, opportunity_name):
        Projectdetails = []
        if opportunity_name is not None:
            queryResult = sf_rest.query(
                "select Opportunity1__C,opportunity1__r.name,Opportunity1__r.Probability_Weighted_Risk_Impact__c, "
                "name,Risk_Description__c,Risk_Probability__c,Impact__c,Weighted_Impact__c,"
                "Mitigation_Action__c,Status__c,Active__c,LastModifiedBy.FirstName, "
                "LastModifiedby.LastName,lastmodifieddate from Risk_Register__c where  opportunity1__r.name='" + opportunity_name + "'")

            print(queryResult)

            records = queryResult['records']
            print(len(records))
            print(queryResult['totalSize'])
            if queryResult['totalSize'] > 0:
                for i in range(len(records)):
                    try:
                        Projectdetails.append({
                            "opportunity_id": records[i]["Opportunity1__c"],
                                               "opportunity_name": records[i]["Opportunity1__r"]["Name"],
                                               "prob_weigh_risk_impact": records[i]["Opportunity1__r"]["Probability_Weighted_Risk_Impact__c"],
                                               "description": records[i]["Risk_Description__c"],
                                               "probability": records[i]["Risk_Probability__c"],
                                               "impact": records[i]["Impact__c"],
                                               "weighted_impact": records[i]["Weighted_Impact__c"],
                                               "mitigation": records[i]["Mitigation_Action__c"],
                                               "status": records[i]["Status__c"],
                                               # "active": records[i]["Active__c"],
                                               "last_modified_date": records[i]["LastModifiedDate"]

                                               })
                    except KeyError as ve:
                        print("Variable x is not defined ",ve)
                    except:
                        print("else")
                        print("Oops!", sys.exc_info()[0], "occured.")
                        pass

        return jsonify(Projectdetails)

    def sfdc_projects(self,project_name):
        Projectdetails = []
        if project_name is not None:
            print("project name is " + project_name)

            queryResult = sf_rest.query("select id,name,probability,site__r.name,Project_id__c,Total_Non_Conformance_Tasks__c,Total_Tasks_for_Report_Information__c,"
                           " Wrike_Folder_ID__c,of_Risk_Registers__c,site__r.street_Address__c,site__r.city__c, site__r.state__c,site__r.zip__c,"
                           "account.name from opportunity where probability>89 and account.name='"+project_name+"'"
                           "and (account.recordtype.name='Customer' OR Account.RecordType.name='Financier')")
            print(queryResult)
            result = json.loads(json.dumps(queryResult))
            print(result)
            records = result['records']

            print(records)
            if result['totalSize'] > 0:
                for i in range(len(records)):
                    try:
                        Projectdetails.append({"Project_ID": records[i]["Project_ID__c"],
                                               "Opportunity_Name": records[i]["Name"],
                                               "Address": records[i]["Site__r"]["Street_Address__c"],
                                               "City": records[i]["Site__r"]["City__c"],
                                               "State": records[i]["Site__r"]["State__c"],
                                               "Zip": records[i]["Site__r"]["Zip__c"],
                                               "Account_Name": records[i]["Account"]["Name"]
                                               })
                    except:
                        if records[i]["Site__r"] is None:
                            Projectdetails.append({"Project_ID": records[i]["Project_ID__c"],
                                                   "Opportunity_Name": records[i]["Name"],
                                                   "Address": records[i]["Site__r"],
                                                   "City": records[i]["Site__r"],
                                                   "State": records[i]["Site__r"],
                                                   "Zip": records[i]["Site__r"],
                                                   "Account_Name": records[i]["Account"]["Name"]
                                                   })

        return jsonify(Projectdetails)

    def dashboard(self, opportunity_name):

        queryResult = sf_rest.query(
            "select id, name, Project_id__c,Total_Tasks_for_Report_Information__c, "
            "Wrike_Folder_ID__c,of_Risk_Registers__c from opportunity where name='" + opportunity_name + "'")

        result = json.loads(json.dumps(queryResult))
        print(result)
        records = result['records']
        print(records)

        # opportunity_id = records[0]['Id']
        # status_rep = sf_rest.query(
        #     "select id,createddate, status from task where recordtype.name='Progress Report' "
        #     "and status='Open' "
        #     "and what.type='opportunity' and whatid='" + opportunity_id + "'")
        # status_rec = json.loads(json.dumps(status_rep))
        # print(status_rec)
        # week_status_rep = {'status':'', 'created_date':''}
        # week_status_rep['status'] = status_rec['records'][0]['Status']
        # week_status_rep['created_date'] = status_rec['records'][0]['CreatedDate']
        # print(week_status_rep)

        dashboard = []

        if result['totalSize'] > 0:
            for i in range(len(records)):
                dashboard.append({"Wrike_Folder_ID": records[i]['Wrike_Folder_ID__c'],
                                  "RFI": records[i]['Total_Tasks_for_Report_Information__c'],
                                  # "NCR": records[i]['Total_Non_Conformance_Tasks__c'],
                                  "Risk_Register": records[i]['of_Risk_Registers__c']
                                  })
        print(dashboard)
        test_url = "https://www.wrike.com/api/v4/folders"
        test_get = requests.get(test_url, headers)
        print(test_get)
        # headers = {
        #     'access_token': "",
        #     'permalink': ''
        # }
        # refresh_token_headers = {
        #     "client_id": "SaeuNo46",
        #     "client_secret": "NQHhrsAvWmfJzNRl53kqfIwpFlybOqwbne7YA1L1SGY7ZT2qHPJPmerqe37RAshJ",
        #     "grant_type": "refresh_token",
        #     "refresh_token": "eyJ0dCI6InAiLCJhbGciOiJIUzI1NiIsInR2IjoiMSJ9.eyJkIjoie1wiYVwiOjE4OTA0NjMsXCJpXCI6NjI2MjA5MSxcImNcIjo0NjExNTM4LFwidlwiOlwiXCIsXCJ1XCI6MzczNTcwOSxcInJcIjpcIlVTXCIsXCJzXCI6W1wiUlwiXSxcInpcIjpbXCJyc2hcIl0sXCJ0XCI6MTU1OTk4MDM4NjAwMH0iLCJleHAiOjE1NTk5ODAzODYsImlhdCI6MTU1OTk3Njc4Nn0.tSfTMXGQ4YdenAIzdgnU6mNWH8xqpCL8AiaWbAtYslQ"
        # }
        if test_get.status_code == 401:
            refresh_url = 'https://www.wrike.com/oauth2/token'
            acc_token = requests.post(refresh_url, params=refresh_token_headers)
            print(acc_token)
            acc_token_json = json.loads(acc_token.text)
            access_token_new = acc_token_json['access_token']
            refresh_token_new = acc_token_json['refresh_token']
            print access_token_new
            print refresh_token_new
            headers['access_token'] = access_token_new
            refresh_token_headers['refresh_token'] = refresh_token_new

        if records != [] and records[0]['Wrike_Folder_ID__c'] is not None:
            permalink = 'https://www.wrike.com/open.htm?id=' + records[0]['Wrike_Folder_ID__c']
            print(permalink)

            headers['permalink'] = permalink

            url1 = "https://www.wrike.com/api/v4/folders"
            folder = requests.get(url1, params=headers)
            print(folder)
            folder_details = json.loads(folder.text)
            print folder_details

            folder_id = folder_details['data'][0]['id']
            print(folder_id)

            headers2 = {'access_token': headers['access_token']}

            url = "https://www.wrike.com/api/v4/folders/" + folder_id + "/tasks"
            print(url)
            req_folder = requests.get(url, params=headers2)
            req_folders = json.loads(req_folder.text)
            print req_folders

            if req_folders['data'] != []:
                for i in range(len(req_folders['data'])):
                    dashboard.append({
                        'title': req_folders['data'][i]['title'],
                        'due_date': req_folders['data'][i]['dates']['due'],
                        'status': req_folders['data'][i]['status']
                    })
            else:
                dashboard.append({})

        if dashboard != []:

            dashboard_n = {"milestone_header": dashboard[0], "milestone_details": dashboard[1:]}
        else:

            dashboard_n = {"milestone_header": [], "milestone_details": []}

        return dashboard_n

    def ProjectSchedule(self, opportunity_name):

        queryResult = sf_rest.query(
            "select id, name, Project_id__c,Total_Non_Conformance_Tasks__c,Total_Tasks_for_Report_Information__c, "
            "Wrike_Folder_ID__c,of_Risk_Registers__c from opportunity where name='" + opportunity_name + "'")

        result = json.loads(json.dumps(queryResult))
        print(result)
        records = result['records']
        print(records)

        # headers = {
        #     'access_token': "",
        #     'permalink': ''
        # }
        test_url = "https://www.wrike.com/api/v4/folders"
        test_get = requests.get(test_url, headers)
        print(test_get)
        # test_get_json = json.loads(test_get)
        # print test_get_json
        if test_get.status_code == 401:
            refresh_url = 'https://www.wrike.com/oauth2/token'
            acc_token = requests.post(refresh_url, params=refresh_token_headers)
            print(acc_token)
            acc_token_json = json.loads(acc_token.text)
            access_token_new = acc_token_json['access_token']
            refresh_token_new = acc_token_json['refresh_token']
            print access_token_new
            print refresh_token_new
            headers['access_token'] = access_token_new
            refresh_token_headers['refresh_token'] = refresh_token_new

        wrike_schedule = []

        if records != [] and records[0]['Wrike_Folder_ID__c'] is not None:
            permalink = 'https://www.wrike.com/open.htm?id=' + records[0]['Wrike_Folder_ID__c']
            print(permalink)

            headers['permalink'] = permalink

            url1 = "https://www.wrike.com/api/v4/folders"
            folder = requests.get(url1, params=headers)
            print(folder)
            folder_details = json.loads(folder.text)
            print folder_details

            folder_id = folder_details['data'][0]['id']
            print(folder_id)

            headers2 = {'access_token': headers['access_token']}
            url = "https://www.wrike.com/api/v4/folders/" + folder_id + "/folders"
            # get folder tree - consisting of all the folders in wrike
            folder_tree = requests.get(url, params=headers2)
            # convert the output to dictionary
            folders_tree = json.loads(folder_tree.text)
            # get the data of the folders
            tree_data = folders_tree['data']
            folder_name = 'Project Schedule'
            sub_folder_id = ''
            # get the folder id of specific folder based on the title
            for i in range(len(tree_data)):
                if folder_name in tree_data[i]['title']:
                    print tree_data[i]['title']
                    sub_folder_id = tree_data[i]['id']
                    print("project schedule folder id is " + sub_folder_id)

            # get the tasks involved in the project
            url2 = "https://www.wrike.com/api/v4/folders/" + sub_folder_id + "/tasks"
            print(url2)

            req_folder = requests.get(url2, params=headers2)
            req_folders = json.loads(req_folder.text)
            print type(req_folders)

            # data = req_folders['data']
            # print(data)

            if req_folders['data'] != []:
                for i in range(len(req_folders['data'])):
                    # print req_folders['data'][i]['dates']
                    if all(k in req_folders['data'][i]['dates'] for k in ("start", "due")):
                        wrike_schedule.append({
                            'title': req_folders['data'][i]['title'],
                            'start_date': req_folders['data'][i]['dates']['start'],
                            'due_date': req_folders['data'][i]['dates']['due'],
                            'duration': req_folders['data'][i]['dates']['duration']
                        })
                    elif all(k not in req_folders['data'][i]['dates'] for k in ("start", "due")):
                        wrike_schedule.append({
                            'title': req_folders['data'][i]['title'],
                            'start_date': "",
                            'due_date': "",
                            'duration': ""
                        })
                    elif all(k not in req_folders['data'][i]['dates'] for k in ("due", "duration")):
                        wrike_schedule.append({
                            'title': req_folders['data'][i]['title'],
                            'start_date': req_folders['data'][i]['dates']['start'],
                            'due_date': "",
                            'duration': ""
                        })
                    elif all(k not in req_folders['data'][i]['dates'] for k in ("start", "duration")):
                        wrike_schedule.append({
                            'title': req_folders['data'][i]['title'],
                            'start_date': "",
                            'due_date': req_folders['data'][i]['dates']['due'],
                            'duration': ""
                        })
            else:
                wrike_schedule.append([])
        else:
            wrike_schedule.append([])

        return wrike_schedule

    def OpenItems(self, opportunity_name):

        queryResult = sf_rest.query("select id, name from opportunity where name='" + opportunity_name + "'")
        result = json.loads(json.dumps(queryResult))
        print(result)
        records = result['records']
        print(records)
        opportunity_id = ''
        if result['totalSize'] > 0:
            opportunity_id = records[0]['Id']

        print(opportunity_id)

        RFI = sf_rest.query(
            "select id,description,Brief_Description__c,createddate,activitydate from task where recordtype.name='Request for Information' "
            "and status='Open' "
            "and what.type='opportunity' and whatid='" + opportunity_id + "'")
        RFI_n = json.loads(json.dumps(RFI))
        print(RFI_n)
        RFI_rec = RFI_n['records']
        # print(RFI_rec)
        RFI_desc = []
        for i in range(len(RFI_rec)):
            if RFI_rec != []:
                RFI_desc.append({"Created_Date": RFI_rec[i]["CreatedDate"],
                                 "Brief_Description": RFI_rec[i]["Brief_Description__c"],
                                 "Comments": RFI_rec[i]["Description"],
                                 "Due_Date": RFI_rec[i]["ActivityDate"]
                                 })
            else:
                    RFI_desc.append([])

        return RFI_desc

        # NCR = sf_rest.query(
        #     "select id,description,Brief_Description__c,createddate,activitydate from task where recordtype.name='Non-Conformance Report'"
        #     " and status='Open' "
        #     "and what.type='opportunity' and whatid='" + opportunity_id + "'")
        #
        # NCR_n = json.loads(json.dumps(NCR))
        # NCR_rec = NCR_n['records']
        # NCR_desc = []
        # for i in range(len(NCR_rec)):
        #     try:
        #         NCR_desc.append({"Created_Date": NCR_rec[i]["CreatedDate"],
        #                          "Brief_Description": NCR_rec[i]["Brief_Description__c"],
        #                          "Comments": NCR_rec[i]["Description"],
        #                          "Due_Date": NCR_rec[i]["ActivityDate"]
        #                          })
        #     except:
        #         if NCR_rec == []:
        #             NCR_desc.append('Null')
        #
        # print NCR_desc
        #
        # RFI_NCR = {"RFI": RFI_desc, "NCR": NCR_desc}
        # print(RFI_NCR)
        #
        # return RFI_NCR


    def contacts(self,opportunity_name):

        queryResult = sf_rest.query("SELECT Id, Name,(SELECT Contact.Name,Contact.Email, Contact.Phone,Role FROM OpportunityContactRoles)"
                                    "FROM Opportunity where opportunity.name='"+opportunity_name+"'")
        result = json.loads(json.dumps(queryResult))
        print(result)
        records_contacts = []
        sfdc_contacts = []
        if result['totalSize'] > 0 and result['records'][0]['OpportunityContactRoles'] is not None :
            records_contacts = result['records'][0]['OpportunityContactRoles']['records']

        for i in range(len(records_contacts)):
            try:
                sfdc_contacts.append({"Name":records_contacts[i]['Contact']['Name'],
                                  "Role": records_contacts[i]['Role'],
                                  "Email":records_contacts[i]['Contact']['Email'],
                                  "Phone":records_contacts[i]['Contact']['Phone']
                             })
            except:
                if records_contacts==[]:
                    sfdc_contacts.append([])

        return sfdc_contacts
        # return result


app = Flask (__name__,static_url_path='/project_portal/static')
app.secret_key = '123456'

@app.route('/project/getProjectDetails',methods=['GET'])
def home():
    portal = Project_Portal()

    project_name = request.args.get('project_name')
    # project_name ='Iron Mountain'

    recordList = portal.sfdc_projects(project_name)
    return recordList

@app.route('/project/dashboard',methods=['GET'])
def dashboard():
    portal = Project_Portal()

    opportunity_name = request.args.get('opportunity_name')
    # project_name ='Iron Mountain'
    recordList = portal.dashboard(opportunity_name)
    return jsonify(recordList)

@app.route('/project/ProjectSchedule',methods=['GET'])
def ProjectSchedule():
    portal = Project_Portal()

    opportunity_name = request.args.get('opportunity_name')
    # project_name ='Iron Mountain'
    recordList = portal.ProjectSchedule(opportunity_name)
    return jsonify(recordList)

@app.route('/project/risks',methods=['GET'])
def ProjectRisks():
    portal = Project_Portal()

    opportunity_name = request.args.get('opportunity_name')
    # project_name ='Iron Mountain'
    recordList = portal.ProjectRisks(opportunity_name)
    # return jsonify({'accountsList': recordList})
    return recordList
@app.route('/project/OpenItems',methods=['GET'])
def OpenItems():
    portal = Project_Portal()

    opportunity_name = request.args.get('opportunity_name')
    # project_name ='Iron Mountain'
    recordList = portal.OpenItems(opportunity_name)
    return jsonify(recordList)

@app.route('/project/contacts',methods=['GET'])
def Contacts():
    portal = Project_Portal()

    opportunity_name = request.args.get('opportunity_name')
    # project_name ='Iron Mountain'
    recordList = portal.contacts(opportunity_name)
    return jsonify(recordList)


if __name__ == '__main__':
    app.run(debug=True)


