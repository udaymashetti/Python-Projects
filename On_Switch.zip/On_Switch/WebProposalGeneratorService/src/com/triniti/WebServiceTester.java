package com.triniti;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class WebServiceTester  {

	   private Client client;
	   private WebResource webResource = null;
	   private String REST_SERVICE_URL = "https://www.webmerge.me/merge/150748/g4dfxz?download=1";
	   private static final String PASS = "pass";

	   private void init(){
	      //this.client = ClientBuilder.newClient();
	      this.client = Client.create();
	      webResource = client.resource(REST_SERVICE_URL);
	   }

	   public static void main(String[] args){
	      WebServiceTester tester = new WebServiceTester();
	      //initialize the tester
	      tester.init();
	      //test get all users Web Service Method
	      tester.testGetUsers();

	   }
	   //Test: Get list of all users
	   //Test: Check if list is not empty
	   private void testGetUsers(){
		   
		   //ClientConfig config = new DefaultClientConfig();
		   //Client client = Client.create(config);
		  // WebResource service = client.resource(getBaseURI());
		   //WebResource service = client.resource(getBaseURI());
		   
		   //ObjectMapper mapper = new ObjectMapper();
		   
		   
		   
		   JSONObject inputJsonObj = new JSONObject();
		   try {
			inputJsonObj.put("AccountName", "Test Account");
			inputJsonObj.put("imgSrc", "y41cp6v64dsu5v4/image2.png?dl=0");
			inputJsonObj.put("AccountOwner", "Vijay");
			inputJsonObj.put("AccountAddress", "Hyderabad");
			inputJsonObj.put("AccountName", "Triniti");
			//inputJsonObj.put("imgSrc", "y41cp6v64dsu5v4/image2.png?dl=0");
			//inputJsonObj.put("imgSrc", "y41cp6v64dsu5v4/image2.png?dl=0");
			
			ArrayList<JSONObject> oppsList	=	new ArrayList<JSONObject>();
			JSONObject oppsChild1	=	new JSONObject();
			oppsChild1.put("Name", "IPhone4s");
			oppsChild1.put("Amount", "25000");
			oppsChild1.put("StageName", "New");
			oppsList.add(oppsChild1);
			JSONObject oppsChild2	=	new JSONObject();
			oppsChild2.put("Name", "IPhone5s");
			oppsChild2.put("Amount", "35000");
			oppsChild2.put("StageName", "In-Process");
			oppsList.add(oppsChild2);
			JSONObject oppsChild3	=	new JSONObject();
			oppsChild3.put("Name", "IPhone6s");
			oppsChild3.put("Amount", "40000");
			oppsChild3.put("StageName", "In-Process");
			oppsList.add(oppsChild3);
		
			inputJsonObj.put("Opps", new JSONArray(oppsList));
			
		   //System.out.println(service.path("rest").path("hello").accept(MediaType.APPLICATION_JSON).post(JSONObject.class, inputJsonObj));
		   
	      //client.target(REST_SERVICE_URL).request(MediaType.APPLICATION_JSON).post(JSONObject.class, inputJsonObj));
		   
			//ClientResponse response = webResource.type(MediaType.APPLICATION_JSON_TYPE).post(ClientResponse.class, inputJsonObj.toString());
			//Builder wb=webResource.accept("application/json,application/pdf,text/plain,image/jpeg,application/xml,application/vnd.ms-excel");

			ClientResponse response = webResource.type("application/json").post(ClientResponse.class, inputJsonObj.toString());
			
			   //JSONObject returnObject	=	webResource.type("application/json").post(JSONObject.class, inputJsonObj);
			   
			InputStream is = (InputStream)response.getEntityInputStream();
	        int len;
	        File file = new File("D:\\Clients\\On-Switch\\WebMerge\\myfile123.docx");  
	        FileOutputStream out = new FileOutputStream(file);
	        
	        byte[] buffer = new byte[4096];
	        while ((len = is.read(buffer, 0, buffer.length)) != -1) {
	        	out.write(buffer, 0, len);
	        }
	        
		      System.out.println("Test case name: testGetUsers, Result: " + response );
		      
		      out.flush();
		       out.close();
		       is.close();
		       
		   } catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  

	   }

	}
