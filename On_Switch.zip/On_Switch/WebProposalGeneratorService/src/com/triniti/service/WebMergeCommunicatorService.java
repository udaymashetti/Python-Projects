package com.triniti.service;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.triniti.ApplicationConfiguration;
import com.triniti.bean.ESAInfoBean;
import com.triniti.bean.ESAInfoBean15;
import com.triniti.bean.ESAProformaInfoBean;
import com.triniti.bean.ESAProformaInfoBean15;
import com.triniti.bean.EsaProformaYearsInfoBean;
import com.triniti.bean.PortalInfoBean;
import com.triniti.bean.ProformaInfoBean;
import com.triniti.bean.ProformaYearsInfoBean;
import com.triniti.bean.QuoteInfoBean;
import com.triniti.bean.WebQuoterMainBean;


@Component
public class WebMergeCommunicatorService {

	
	   private Client client;
	   private WebResource webResource = null;
	   //private String REST_SERVICE_URL = "https://www.webmerge.me/merge/156262/hfh3cc?download=1";
	   private String REST_SERVICE_URL = null;
	   
	   
	   @Autowired
		private ApplicationConfiguration configuration;

	   public void init() throws Exception{
	      this.client = Client.create();
	      //webResource = client.resource(REST_SERVICE_URL);
	      REST_SERVICE_URL	=	configuration.getWebMergeDocumentURL();
	      if(REST_SERVICE_URL == null || REST_SERVICE_URL.equals("")) {
	    	  throw new Exception("WebMerge Service URL not found. Please check configuration");
	      }
	      webResource = client.resource(REST_SERVICE_URL);
	   }

	   public static void main(String[] args) throws Exception{
		   WebMergeCommunicatorService tester = new WebMergeCommunicatorService();
	      //initialize the tester
	      tester.init();
	      //test get all users Web Service Method
	      //tester.prepareMergeData();

	   }
	public Map<String, String> prepareMergeData(WebQuoterMainBean quoterMainBean){
		 
		   JSONObject mainInputJsonObj = new JSONObject();
		   Map<String, String> returnMap	=	 new HashMap<>();
		   String returnFileName	=	null;
		   try {
			   PortalInfoBean portalBean			=	quoterMainBean.getPortalInfoBean();
			   QuoteInfoBean quoteInfoBean			=	quoterMainBean.getQuoteInfoBean();
			   ProformaInfoBean proformaInfoBean	=	quoterMainBean.getProformaInfoBean();
			   ESAInfoBean esaInfoBean				=	quoterMainBean.getEsaInfoBean();
			   ESAProformaInfoBean esaProformaBean	=	quoterMainBean.getEsaProformaInfoBean();
			   
			   ESAInfoBean15 esaInfoBean15				=	quoterMainBean.getEsaInfoBean15();
			   ESAProformaInfoBean15 esaProformaBean15	=	quoterMainBean.getEsaProformaInfoBean15();
			   
			   if(portalBean != null) {
				   mainInputJsonObj.put("companyName", portalBean.getCompanyName());
				   mainInputJsonObj.put("contactName", portalBean.getContactName());
				   mainInputJsonObj.put("address", portalBean.getAddress());
				   mainInputJsonObj.put("city", portalBean.getCity());
				   //mainInputJsonObj.put("roofType", portalBean.getRoofType());
				   mainInputJsonObj.put("roofType", portalBean.getRoofType());
				   mainInputJsonObj.put("utility", portalBean.getUtility());
				   
				   mainInputJsonObj.put("contactDesignation", portalBean.getContactDesignation());
				   mainInputJsonObj.put("contactAddress", portalBean.getContactAddress());
				   mainInputJsonObj.put("contactPhone", portalBean.getContactPhone());
				   
				   StringBuffer mainImageBuffer	=	new StringBuffer();
				   String latlong	=	portalBean.getLatitude()+"," + portalBean.getLongitude();
				   mainImageBuffer.append("https://maps.googleapis.com/maps/api/staticmap?center=");
				   mainImageBuffer.append(latlong);
				  /* mainImageBuffer.append("&zoom=18&markers=size:mid%7Ccolor:red%7C");
				   mainImageBuffer.append(latlong);*/
				   //mainImageBuffer.append("&zoom=16");
				   mainImageBuffer.append("&visible=");
				   mainImageBuffer.append(latlong);
				   mainImageBuffer.append("&scale=2&size=350x300&maptype=satellite&key=");
				   mainImageBuffer.append(configuration.getGoogleAPIKey());
				   
				   System.out.println("WebMergeCommunicatorService.prepareMergeData() mainImageBuffer- " + mainImageBuffer);
				   
				   mainInputJsonObj.put("mainImage", mainImageBuffer);
				   mainInputJsonObj.put("imageCoordinates", latlong);
				   mainInputJsonObj.put("googleKey", configuration.getGoogleAPIKey());
			   }
			   
			   if(quoteInfoBean != null) {
				   mainInputJsonObj.put("solarUnitSize", quoteInfoBean.getOsSystemSize());
				   mainInputJsonObj.put("firstYearTotalProduction", quoteInfoBean.getFirstYearTotalProduction());
				   mainInputJsonObj.put("percentOffset", quoteInfoBean.getPercentOffset());
				   mainInputJsonObj.put("purchasePriceDollars", quoteInfoBean.getPurchasePriceDollars());
				   mainInputJsonObj.put("purchasePriceDollarsPerWatt", quoteInfoBean.getPurchasePriceDollarsPerWatt());
				   mainInputJsonObj.put("utilityEscalation", quoteInfoBean.getUtilityEscalation());
				   
			   }
			   if(esaInfoBean != null) {
				   mainInputJsonObj.put("discountPercentToUtil", esaInfoBean.getDiscountPercentToUtil());
				   mainInputJsonObj.put("esaSavingsOverTerm", esaInfoBean.getEsaSavingsOverTerm());
				   mainInputJsonObj.put("priceLockInPeriod", esaInfoBean.getPriceLockInPeriod());
				   mainInputJsonObj.put("Savings_Period", esaInfoBean.getPriceLockInPeriod());
				   mainInputJsonObj.put("esa", "esa");
			   }
			   else {
				   mainInputJsonObj.put("priceLockInPeriod", "20");
				   //mainInputJsonObj.put("Savings_Period", "20");
			   }
			   
			   if(esaInfoBean15 != null) {
				   mainInputJsonObj.put("discountPercentToUtil15", esaInfoBean15.getDiscountPercentToUtil());
				   mainInputJsonObj.put("esaSavingsOverTerm15", esaInfoBean15.getEsaSavingsOverTerm());
				   mainInputJsonObj.put("priceLockInPeriod15", esaInfoBean15.getPriceLockInPeriod());
				   mainInputJsonObj.put("Savings_Period15", esaInfoBean15.getPriceLockInPeriod());
				   mainInputJsonObj.put("esa15", "esa15Years");
			   }
			   
			   int totalESAYears	=	0;
			   double min = 0;
			   double max = 0;
			   double cumulativeTotalSaving	= 0;
			   if(esaProformaBean != null) {
				   
				   mainInputJsonObj.put("solarElectricityYear1Price", esaProformaBean.getSolarElectricityYear1Price());
				   mainInputJsonObj.put("solarElectricityAnnualEscalator", esaProformaBean.getSolarElectricityAnnualEscalator());
				   mainInputJsonObj.put("avoidedUtilityYear1Price", esaProformaBean.getAvoidedUtilityYear1Price());
				   mainInputJsonObj.put("avoidedUtilityAnnualEscalator", esaProformaBean.getAvoidedUtilityAnnualEscalator());
				   
				   List<EsaProformaYearsInfoBean> esaYearsInfoBeanList =	esaProformaBean.getEsaYearsInfoBean();
				   
				   
				   for(EsaProformaYearsInfoBean yearsInfoBean : esaYearsInfoBeanList) {
					   
					   mainInputJsonObj.put("esaelectricity_yr" + yearsInfoBean.getYear() , yearsInfoBean.getElectricity());
					   mainInputJsonObj.put("esaname_yr" + yearsInfoBean.getYear() , yearsInfoBean.getName());
					   mainInputJsonObj.put("esayear_yr" + yearsInfoBean.getYear() , yearsInfoBean.getYear());
					   mainInputJsonObj.put("solarElectricityPrice_yr" + yearsInfoBean.getYear() , yearsInfoBean.getSolarElectricityPrice());
					   mainInputJsonObj.put("solarElectricityPayment_yr" + yearsInfoBean.getYear() , yearsInfoBean.getSolarElectricityPayment());
					   mainInputJsonObj.put("esautilityElectrictyPrice_yr" + yearsInfoBean.getYear() , yearsInfoBean.getUtilityElectrictyPrice());
					   mainInputJsonObj.put("esaavoidedUtilityElectricity_yr" + yearsInfoBean.getYear() , yearsInfoBean.getAvoidedUtilityElectricity());
					   mainInputJsonObj.put("netSavings_yr" + yearsInfoBean.getYear() , yearsInfoBean.getNetSavings());
					   mainInputJsonObj.put("cumulativeNetSavings_yr" + yearsInfoBean.getYear() , yearsInfoBean.getCumulativeNetSavings());
					   
					   if(yearsInfoBean.getCumulativeNetSavings() != null) {
						   cumulativeTotalSaving	=	Double.parseDouble(yearsInfoBean.getCumulativeNetSavings());
						   if(cumulativeTotalSaving < min) {
							   min =	cumulativeTotalSaving;
						   }
						   if(cumulativeTotalSaving > max) {
							   max	=	cumulativeTotalSaving;
						   }
					   }
					   
					   mainInputJsonObj.put("discountToUtility_yr" + yearsInfoBean.getYear() , yearsInfoBean.getDiscountToUtility());
					   mainInputJsonObj.put("esaforProfit_yr" + yearsInfoBean.getYear() , yearsInfoBean.getForProfit());
					   mainInputJsonObj.put("esairrOverride_yr" + yearsInfoBean.getYear() , yearsInfoBean.getIrrOverride());
					   mainInputJsonObj.put("esaaddTaxOnSavings_yr" + yearsInfoBean.getYear() , yearsInfoBean.getAddTaxOnSavings());
					   
					   totalESAYears ++;
				   }
			   }
			   if(totalESAYears > 0) {
				   totalESAYears = totalESAYears - 1;
			   }
			   else if (totalESAYears == 0) {
				   totalESAYears = 20;
			   }
			   mainInputJsonObj.put("esaProformaYears", totalESAYears);
			   
			   //15 years esa table data
			   	if(esaProformaBean15 != null) {
				   
				   mainInputJsonObj.put("solarElectricityYear1Price15", esaProformaBean15.getSolarElectricityYear1Price());
				   mainInputJsonObj.put("solarElectricityAnnualEscalator15", esaProformaBean15.getSolarElectricityAnnualEscalator());
				   mainInputJsonObj.put("avoidedUtilityYear1Price15", esaProformaBean15.getAvoidedUtilityYear1Price());
				   mainInputJsonObj.put("avoidedUtilityAnnualEscalator15", esaProformaBean15.getAvoidedUtilityAnnualEscalator());
				   
				   List<EsaProformaYearsInfoBean> esaYearsInfoBeanList =	esaProformaBean15.getEsaYearsInfoBean();
				   
				   
				   for(EsaProformaYearsInfoBean yearsInfoBean : esaYearsInfoBeanList) {
					   
					   mainInputJsonObj.put("esaelectricity_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getElectricity());
					   mainInputJsonObj.put("esaname_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getName());
					   mainInputJsonObj.put("esayear_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getYear());
					   mainInputJsonObj.put("solarElectricityPrice_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getSolarElectricityPrice());
					   mainInputJsonObj.put("solarElectricityPayment_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getSolarElectricityPayment());
					   mainInputJsonObj.put("esautilityElectrictyPrice_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getUtilityElectrictyPrice());
					   mainInputJsonObj.put("esaavoidedUtilityElectricity_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getAvoidedUtilityElectricity());
					   mainInputJsonObj.put("netSavings_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getNetSavings());
					   mainInputJsonObj.put("cumulativeNetSavings_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getCumulativeNetSavings());
					   
					   /*if(yearsInfoBean.getCumulativeNetSavings() != null) {
						   cumulativeTotalSaving	=	Double.parseDouble(yearsInfoBean.getCumulativeNetSavings());
						   if(cumulativeTotalSaving < min) {
							   min =	cumulativeTotalSaving;
						   }
						   if(cumulativeTotalSaving > max) {
							   max	=	cumulativeTotalSaving;
						   }
					   }*/
					   
					   mainInputJsonObj.put("discountToUtility_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getDiscountToUtility());
					   mainInputJsonObj.put("esaforProfit_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getForProfit());
					   mainInputJsonObj.put("esairrOverride_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getIrrOverride());
					   mainInputJsonObj.put("esaaddTaxOnSavings_15_yr" + yearsInfoBean.getYear() , yearsInfoBean.getAddTaxOnSavings());
					   
					   //totalESAYears ++;
				   }
			   }
			   	//15 years table data end

			   int totalOwnershipYears	=	0;
			   
			   if(proformaInfoBean != null) {
				   mainInputJsonObj.put("totalSavings", proformaInfoBean.getTotalSavings());
				   mainInputJsonObj.put("cashprice", proformaInfoBean.getCashPrice());
				   mainInputJsonObj.put("priceAfterTaxBenes", proformaInfoBean.getPriceAfterTaxBenes());
				   mainInputJsonObj.put("paybackOn25YearLife", proformaInfoBean.getPaybackOn25YearLife());
				   
				   List<ProformaYearsInfoBean> yearsInfoBeanList =	proformaInfoBean.getYearsInfoBean();
				   boolean utilityIncentive	=	false;
				  
				   for(ProformaYearsInfoBean yearsInfoBean : yearsInfoBeanList) {
					   
					   mainInputJsonObj.put("name_yr" + yearsInfoBean.getYear() , yearsInfoBean.getName());
					   mainInputJsonObj.put("year_yr" + yearsInfoBean.getYear() , yearsInfoBean.getYear());
					   mainInputJsonObj.put("solarUnitSize_yr" + yearsInfoBean.getYear() , yearsInfoBean.getSolarUnitSize());
					   mainInputJsonObj.put("preTaxSavings_yr" + yearsInfoBean.getYear() , yearsInfoBean.getPreTaxSavings());
					   mainInputJsonObj.put("stateTaxOnSavings_yr" + yearsInfoBean.getYear() , yearsInfoBean.getStateTaxOnSavings());
					   mainInputJsonObj.put("stateTaxExemptionOnUtilityIncentive_yr" + yearsInfoBean.getYear() , yearsInfoBean.getStateTaxExemptionOnUtilityIncentive());
					   mainInputJsonObj.put("deductionOfStateIncomeTax_yr" + yearsInfoBean.getYear() , yearsInfoBean.getDeductionOfStateIncomeTax());
					  
					   mainInputJsonObj.put("totalTax_yr" + yearsInfoBean.getYear() , yearsInfoBean.getTotalTax());
					   
					   mainInputJsonObj.put("purchasePrice_yr" + yearsInfoBean.getYear() , yearsInfoBean.getPurchasePrice());
					   mainInputJsonObj.put("maintenanceCost_yr" + yearsInfoBean.getYear() , yearsInfoBean.getMaintenanceCost());
					   mainInputJsonObj.put("electricity_yr" + yearsInfoBean.getYear() , yearsInfoBean.getElectricity());
					   mainInputJsonObj.put("utilityElectrictyPrice_yr" + yearsInfoBean.getYear() , yearsInfoBean.getUtilityElectrictyPrice());
					   mainInputJsonObj.put("utilityIncentive_yr" + yearsInfoBean.getYear() , yearsInfoBean.getUtilityIncentive());
					   if(yearsInfoBean.getUtilityIncentive() != null && !yearsInfoBean.getUtilityIncentive().equals("0")){
						   utilityIncentive	=	true;
					   }
					   mainInputJsonObj.put("avoidedUtilityElectricity_yr" + yearsInfoBean.getYear() , yearsInfoBean.getAvoidedUtilityElectricity());
					   mainInputJsonObj.put("purchasePrice_yr" + yearsInfoBean.getYear() , yearsInfoBean.getPurchasePrice());
					   mainInputJsonObj.put("stateTaxBenefitFromDepr_yr" + yearsInfoBean.getYear() , yearsInfoBean.getStateTaxBenefitFromDepr());
					   mainInputJsonObj.put("fedTaxBenefitFromDepr_yr" + yearsInfoBean.getYear() , yearsInfoBean.getFedTaxBenefitFromDepr());
					   mainInputJsonObj.put("fedTaxOnSavings_yr" + yearsInfoBean.getYear() , yearsInfoBean.getFedTaxOnSavings());
					   mainInputJsonObj.put("totalSavings_yr" + yearsInfoBean.getYear() , yearsInfoBean.getTotalSavings());
					   mainInputJsonObj.put("cumulativeTotalSavings_yr" + yearsInfoBean.getYear() , yearsInfoBean.getCumulativeTotalSavings());
					   if(yearsInfoBean.getCumulativeTotalSavings() != null) {
						   cumulativeTotalSaving	=	Double.parseDouble(yearsInfoBean.getCumulativeTotalSavings());
						   if(cumulativeTotalSaving < min) {
							   min =	cumulativeTotalSaving;
						   }
						   if(cumulativeTotalSaving > max) {
							   max	=	cumulativeTotalSaving;
						   }
					   }
					   mainInputJsonObj.put("maintenanceCost_yr" + yearsInfoBean.getYear() , yearsInfoBean.getMaintenanceCost());
					   mainInputJsonObj.put("maintenanceExpenseEscalator_yr" + yearsInfoBean.getYear() , yearsInfoBean.getMaintenanceExpenseEscalator());
					   mainInputJsonObj.put("stateTaxRate_yr" + yearsInfoBean.getYear() , yearsInfoBean.getStateTaxRate());
					   mainInputJsonObj.put("fedTaxRate_yr" + yearsInfoBean.getYear() , yearsInfoBean.getFedTaxRate());
					   mainInputJsonObj.put("fedInvestmentTaxCredit_yr" + yearsInfoBean.getYear() , yearsInfoBean.getFedInvestmentTaxCredit());
					   mainInputJsonObj.put("forProfit_yr" + yearsInfoBean.getYear() , yearsInfoBean.getForProfit());
					   mainInputJsonObj.put("irrOverride_yr" + yearsInfoBean.getYear() , yearsInfoBean.getIrrOverride());
					   mainInputJsonObj.put("addTaxOnSavings_yr" + yearsInfoBean.getYear() , yearsInfoBean.getAddTaxOnSavings());
					   
					   totalOwnershipYears ++;
					   
				   }
				   
				   System.out.println("WebMergeCommunicatorService.prepareMergeData() min " + min);
				   System.out.println("WebMergeCommunicatorService.prepareMergeData() max " + max);
				   
				   int maxDigits = (int) (Math.floor(Math.log10(Math.abs(max))) + 1);
				   
				   int maxfactor = (int)Math.pow(10,maxDigits-2);
					 System.out.println("WebMergeCommunicatorService.prepareMergeData() factor-" + maxfactor);
					 
					 max = (int)Math.ceil(max / maxfactor) * maxfactor;
				   
				   int minDigits = (int) (Math.floor(Math.log10(Math.abs(min))) + 1);
				   
				   int factor = (int)Math.pow(10,minDigits-2);
					 System.out.println("WebMergeCommunicatorService.prepareMergeData() factor-" + factor);
					 
					 min = (int)Math.ceil(min / factor) * factor;
					 System.out.println("WebMergeCommunicatorService.prepareMergeData() min-" + min);
					 
					 
						 System.out.println("WebMergeCommunicatorService.prepareMergeData() max-" + max);
						 
					mainInputJsonObj.put("chartMin" , ""+ min);
					mainInputJsonObj.put("chartMax" , ""+ max);
					mainInputJsonObj.put("utilityIncentive" , ""+ utilityIncentive);
				}
			   
			   if(totalOwnershipYears > 0) {
				   totalOwnershipYears = totalOwnershipYears - 1;
			   }
			   else if (totalOwnershipYears == 0) {
				   totalOwnershipYears = 25;
			   }
			   mainInputJsonObj.put("ownershipProformaYears", totalOwnershipYears);
			   
			   //System.out.println("WebMergeCommunicatorService.prepareMergeData() final input String mainInputJsonObj - " + mainInputJsonObj);
			   
			   ClientResponse response = webResource.type("application/json").post(ClientResponse.class, mainInputJsonObj.toString());

			   //JSONObject returnObject	=	webResource.type("application/json").post(JSONObject.class, inputJsonObj);

			   InputStream is = (InputStream)response.getEntityInputStream();
			   long timeStamp	=	System.currentTimeMillis();
			   
			   int len;
			   File file = new File(configuration.getOutputFilePath() + "/" + timeStamp + ".docx");  
			   FileOutputStream out = new FileOutputStream(file);

			   byte[] buffer = new byte[4096];
			   while ((len = is.read(buffer, 0, buffer.length)) != -1) {
				   out.write(buffer, 0, len);
			   }

			   System.out.println("Test case name: testGetUsers, Result: " + response );

			   out.flush();
			   out.close();
			   is.close();
			   returnFileName	=	"" + timeStamp;
			   returnMap.put("FileKey" , returnFileName);

		   } catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					returnMap.put("Error" , e.getLocalizedMessage());
				}
		  
		   return returnMap;

	   }
	
	private static final String FILE_PATH = "d:\\Test2.zip";
	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_OCTET_STREAM)
	public Response getFile() {
	    File file = new File(FILE_PATH);
	    ResponseBuilder response = Response.ok((Object) file);
	    response.header("Content-Disposition", "attachment; filename=newfile.zip");
	    return response.build();

	}

}
