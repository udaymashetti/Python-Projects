package com.triniti.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WebQuoterMainBean {

	public WebQuoterMainBean() {}
	
	@JsonProperty("portal")
	private PortalInfoBean portalInfoBean;
	
	@JsonProperty("quote")
	private QuoteInfoBean quoteInfoBean;
	
	@JsonProperty("esa25Years")
	private ESAInfoBean esaInfoBean;

	@JsonProperty("proforma")
	private ProformaInfoBean proformaInfoBean;
	
	@JsonProperty("esaProforma25Years")
	private ESAProformaInfoBean esaProformaInfoBean;
	
	@JsonProperty("esa15Years")
	private ESAInfoBean15 esaInfoBean15;
	
	@JsonProperty("esaProforma15Years")
	private ESAProformaInfoBean15 esaProformaInfoBean15;

	
	
	public ESAInfoBean15 getEsaInfoBean15() {
		return esaInfoBean15;
	}

	public void setEsaInfoBean15(ESAInfoBean15 esaInfoBean15) {
		this.esaInfoBean15 = esaInfoBean15;
	}

	public ESAProformaInfoBean15 getEsaProformaInfoBean15() {
		return esaProformaInfoBean15;
	}

	public void setEsaProformaInfoBean15(ESAProformaInfoBean15 esaProformaInfoBean15) {
		this.esaProformaInfoBean15 = esaProformaInfoBean15;
	}

	

	public ESAProformaInfoBean getEsaProformaInfoBean() {
		return esaProformaInfoBean;
	}

	public void setEsaProformaInfoBean(ESAProformaInfoBean esaProformaInfoBean) {
		this.esaProformaInfoBean = esaProformaInfoBean;
	}

	public QuoteInfoBean getQuoteInfoBean() {
		return quoteInfoBean;
	}

	public void setQuoteInfoBean(QuoteInfoBean quoteInfoBean) {
		this.quoteInfoBean = quoteInfoBean;
	}

	public PortalInfoBean getPortalInfoBean() {
		return portalInfoBean;
	}

	public void setPortalInfoBean(PortalInfoBean portalInfoBean) {
		this.portalInfoBean = portalInfoBean;
	}

	public ESAInfoBean getEsaInfoBean() {
		return esaInfoBean;
	}

	public void setEsaInfoBean(ESAInfoBean esaInfoBean) {
		this.esaInfoBean = esaInfoBean;
	}

	public ProformaInfoBean getProformaInfoBean() {
		return proformaInfoBean;
	}

	public void setProformaInfoBean(ProformaInfoBean proformaInfoBean) {
		this.proformaInfoBean = proformaInfoBean;
	}
	
}
