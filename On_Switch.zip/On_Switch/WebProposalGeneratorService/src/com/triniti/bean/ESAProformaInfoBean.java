package com.triniti.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ESAProformaInfoBean {

	public ESAProformaInfoBean() {}
	
	private String solarElectricityYear1Price;
	
	private String solarElectricityAnnualEscalator;
	
	private String avoidedUtilityYear1Price;
	
	private String avoidedUtilityAnnualEscalator;
	
	@JsonProperty("years")
	private List<EsaProformaYearsInfoBean> esaYearsInfoBean;

	public List<EsaProformaYearsInfoBean> getEsaYearsInfoBean() {
		return esaYearsInfoBean;
	}

	public void setEsaYearsInfoBean(List<EsaProformaYearsInfoBean> esaYearsInfoBean) {
		this.esaYearsInfoBean = esaYearsInfoBean;
	}

	public String getSolarElectricityYear1Price() {
		return solarElectricityYear1Price;
	}

	public void setSolarElectricityYear1Price(String solarElectricityYear1Price) {
		this.solarElectricityYear1Price = solarElectricityYear1Price;
	}

	public String getSolarElectricityAnnualEscalator() {
		return solarElectricityAnnualEscalator;
	}

	public void setSolarElectricityAnnualEscalator(String solarElectricityAnnualEscalator) {
		this.solarElectricityAnnualEscalator = solarElectricityAnnualEscalator;
	}

	public String getAvoidedUtilityYear1Price() {
		return avoidedUtilityYear1Price;
	}

	public void setAvoidedUtilityYear1Price(String avoidedUtilityYear1Price) {
		this.avoidedUtilityYear1Price = avoidedUtilityYear1Price;
	}

	public String getAvoidedUtilityAnnualEscalator() {
		return avoidedUtilityAnnualEscalator;
	}

	public void setAvoidedUtilityAnnualEscalator(String avoidedUtilityAnnualEscalator) {
		this.avoidedUtilityAnnualEscalator = avoidedUtilityAnnualEscalator;
	}
	
	
	
}
