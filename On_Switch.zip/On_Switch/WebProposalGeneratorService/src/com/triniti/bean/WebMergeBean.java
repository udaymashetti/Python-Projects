package com.triniti.bean;

public class WebMergeBean {

}
