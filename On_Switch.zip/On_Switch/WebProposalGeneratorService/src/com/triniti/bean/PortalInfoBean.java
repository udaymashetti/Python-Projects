package com.triniti.bean;

public class PortalInfoBean {
	
	public PortalInfoBean() {
		
	}

	public String portalId;
	
	public String portalName;
	
	private String contactDesignation;
	
	public String contactName;

	public String companyName;

	public String emailAddress;

	public String prospectEmail;

	public String phoneNumber;

	public String address;

	public String city;

	public String buildingUse;

	public String roofType;

	public String roofRating;
	
	public String closestCityForProduction;

	public String utility;

	public String regionOfCA;

	public String latitude;

	public String longitude;

	public String portalUrl;

	public String numberOfStories;

	public String tilt;

	public String roofArea;

	public String productionEstimate;

	public String purchasePriceDollarsPerWatt;

	public String forProfit;

	public String override;

	public String triggerMail;

	public String sendProspectMail;

	public String timestamp;

	//public String portalOverrides;

	private String contactAddress;
	
	private String contactPhone;
	
	
	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public String getContactAddress() {
		return contactAddress;
	}

	public void setContactAddress(String contactAddress) {
		this.contactAddress = contactAddress;
	}

	public String getPortalId() {
		return portalId;
	}

	public void setPortalId(String portalId) {
		this.portalId = portalId;
	}

	public String getPortalName() {
		return portalName;
	}

	public void setPortalName(String portalName) {
		this.portalName = portalName;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getProspectEmail() {
		return prospectEmail;
	}

	public void setProspectEmail(String prospectEmail) {
		this.prospectEmail = prospectEmail;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getBuildingUse() {
		return buildingUse;
	}

	public void setBuildingUse(String buildingUse) {
		this.buildingUse = buildingUse;
	}

	public String getRoofType() {
		return roofType;
	}

	public void setRoofType(String roofType) {
		this.roofType = roofType;
	}

	public String getRoofRating() {
		return roofRating;
	}

	public void setRoofRating(String roofRating) {
		this.roofRating = roofRating;
	}

	public String getClosestCityForProduction() {
		return closestCityForProduction;
	}

	public void setClosestCityForProduction(String closestCityForProduction) {
		this.closestCityForProduction = closestCityForProduction;
	}

	public String getUtility() {
		return utility;
	}

	public void setUtility(String utility) {
		this.utility = utility;
	}

	public String getRegionOfCA() {
		return regionOfCA;
	}

	public void setRegionOfCA(String regionOfCA) {
		this.regionOfCA = regionOfCA;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getPortalUrl() {
		return portalUrl;
	}

	public void setPortalUrl(String portalUrl) {
		this.portalUrl = portalUrl;
	}

	public String getNumberOfStories() {
		return numberOfStories;
	}

	public void setNumberOfStories(String numberOfStories) {
		this.numberOfStories = numberOfStories;
	}

	public String getTilt() {
		return tilt;
	}

	public void setTilt(String tilt) {
		this.tilt = tilt;
	}

	public String getRoofArea() {
		return roofArea;
	}

	public void setRoofArea(String roofArea) {
		this.roofArea = roofArea;
	}

	public String getProductionEstimate() {
		return productionEstimate;
	}

	public void setProductionEstimate(String productionEstimate) {
		this.productionEstimate = productionEstimate;
	}

	public String getPurchasePriceDollarsPerWatt() {
		return purchasePriceDollarsPerWatt;
	}

	public void setPurchasePriceDollarsPerWatt(String purchasePriceDollarsPerWatt) {
		this.purchasePriceDollarsPerWatt = purchasePriceDollarsPerWatt;
	}

	public String getForProfit() {
		return forProfit;
	}

	public void setForProfit(String forProfit) {
		this.forProfit = forProfit;
	}

	public String getOverride() {
		return override;
	}

	public void setOverride(String override) {
		this.override = override;
	}

	public String getTriggerMail() {
		return triggerMail;
	}

	public void setTriggerMail(String triggerMail) {
		this.triggerMail = triggerMail;
	}

	public String getSendProspectMail() {
		return sendProspectMail;
	}

	public void setSendProspectMail(String sendProspectMail) {
		this.sendProspectMail = sendProspectMail;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	/*public String getPortalOverrides() {
		return portalOverrides;
	}

	public void setPortalOverrides(String portalOverrides) {
		this.portalOverrides = portalOverrides;
	}*/

	public String getContactDesignation() {
		return contactDesignation;
	}

	public void setContactDesignation(String contactDesignation) {
		this.contactDesignation = contactDesignation;
	}

}
