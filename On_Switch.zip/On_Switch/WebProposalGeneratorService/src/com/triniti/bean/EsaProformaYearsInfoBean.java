package com.triniti.bean;

public class EsaProformaYearsInfoBean {

	public EsaProformaYearsInfoBean() {}
	
	private String name;
	private String year;
	private String solarElectricityPayment;
	private String solarElectricityPrice;
	private String forProfit;
	private String electricity;
	private String utilityElectrictyPrice;
	private String avoidedUtilityElectricity;
	private String cumulativeNetSavings;
	private String discountToUtility;
	private String netSavings;
	private String irrOverride;
	private String addTaxOnSavings;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getElectricity() {
		return electricity;
	}
	public void setElectricity(String electricity) {
		this.electricity = electricity;
	}
	public String getUtilityElectrictyPrice() {
		return utilityElectrictyPrice;
	}
	public void setUtilityElectrictyPrice(String utilityElectrictyPrice) {
		this.utilityElectrictyPrice = utilityElectrictyPrice;
	}
	public String getAvoidedUtilityElectricity() {
		return avoidedUtilityElectricity;
	}
	public void setAvoidedUtilityElectricity(String avoidedUtilityElectricity) {
		this.avoidedUtilityElectricity = avoidedUtilityElectricity;
	}
	public String getForProfit() {
		return forProfit;
	}
	public void setForProfit(String forProfit) {
		this.forProfit = forProfit;
	}
	public String getIrrOverride() {
		return irrOverride;
	}
	public void setIrrOverride(String irrOverride) {
		this.irrOverride = irrOverride;
	}
	public String getAddTaxOnSavings() {
		return addTaxOnSavings;
	}
	public void setAddTaxOnSavings(String addTaxOnSavings) {
		this.addTaxOnSavings = addTaxOnSavings;
	}
	public String getSolarElectricityPayment() {
		return solarElectricityPayment;
	}
	public void setSolarElectricityPayment(String solarElectricityPayment) {
		this.solarElectricityPayment = solarElectricityPayment;
	}
	public String getSolarElectricityPrice() {
		return solarElectricityPrice;
	}
	public void setSolarElectricityPrice(String solarElectricityPrice) {
		this.solarElectricityPrice = solarElectricityPrice;
	}
	public String getCumulativeNetSavings() {
		return cumulativeNetSavings;
	}
	public void setCumulativeNetSavings(String cumulativeNetSavings) {
		this.cumulativeNetSavings = cumulativeNetSavings;
	}
	public String getDiscountToUtility() {
		return discountToUtility;
	}
	public void setDiscountToUtility(String discountToUtility) {
		this.discountToUtility = discountToUtility;
	}
	public String getNetSavings() {
		return netSavings;
	}
	public void setNetSavings(String netSavings) {
		this.netSavings = netSavings;
	}
}
