package com.triniti.bean;

public class ESAInfoBean15 {

	public ESAInfoBean15() {}
	
	private String discountPercentToUtil;
	private String year1SolarOutput;
	private String esaSavingsOverTerm;
	private String priceLockInPeriod;
	
	public String getPriceLockInPeriod() {
		return priceLockInPeriod;
	}
	public void setPriceLockInPeriod(String priceLockInPeriod) {
		this.priceLockInPeriod = priceLockInPeriod;
	}
	public String getDiscountPercentToUtil() {
		return discountPercentToUtil;
	}
	public void setDiscountPercentToUtil(String discountPercentToUtil) {
		this.discountPercentToUtil = discountPercentToUtil;
	}
	public String getYear1SolarOutput() {
		return year1SolarOutput;
	}
	public void setYear1SolarOutput(String year1SolarOutput) {
		this.year1SolarOutput = year1SolarOutput;
	}
	public String getEsaSavingsOverTerm() {
		return esaSavingsOverTerm;
	}
	public void setEsaSavingsOverTerm(String esaSavingsOverTerm) {
		this.esaSavingsOverTerm = esaSavingsOverTerm;
	}
	
	
}
