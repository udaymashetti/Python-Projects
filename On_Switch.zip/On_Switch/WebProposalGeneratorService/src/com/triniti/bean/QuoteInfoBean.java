package com.triniti.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class QuoteInfoBean {

	public QuoteInfoBean() {
		
	}
	
	private String productionEstimate;
	private String annualConsumption;
	private String facilityMaxDemandEst;
	private String startingTariff;
	private String utilityEscalation;
	private String usableRoofArea;
	private String maxEstimatedKWP;
	private String osSystemSize;
	private String firstYearTotalProduction;
	private String percentOffset;
	private String avoidedCost;
	private String purchasePriceDollars;
	private String purchasePriceDollarsPerWatt;
	
	@JsonProperty("esaPairs")
	private List<ESAPairBean> esaPairBean;
	
	public List<ESAPairBean> getEsaPairBean() {
		return esaPairBean;
	}
	public void setEsaPairBean(List<ESAPairBean> esaPairBean) {
		this.esaPairBean = esaPairBean;
	}
	public String getProductionEstimate() {
		return productionEstimate;
	}
	public void setProductionEstimate(String productionEstimate) {
		this.productionEstimate = productionEstimate;
	}
	public String getAnnualConsumption() {
		return annualConsumption;
	}
	public void setAnnualConsumption(String annualConsumption) {
		this.annualConsumption = annualConsumption;
	}
	public String getFacilityMaxDemandEst() {
		return facilityMaxDemandEst;
	}
	public void setFacilityMaxDemandEst(String facilityMaxDemandEst) {
		this.facilityMaxDemandEst = facilityMaxDemandEst;
	}
	public String getStartingTariff() {
		return startingTariff;
	}
	public void setStartingTariff(String startingTariff) {
		this.startingTariff = startingTariff;
	}
	public String getUtilityEscalation() {
		return utilityEscalation;
	}
	public void setUtilityEscalation(String utilityEscalation) {
		this.utilityEscalation = utilityEscalation;
	}
	public String getUsableRoofArea() {
		return usableRoofArea;
	}
	public void setUsableRoofArea(String usableRoofArea) {
		this.usableRoofArea = usableRoofArea;
	}
	public String getMaxEstimatedKWP() {
		return maxEstimatedKWP;
	}
	public void setMaxEstimatedKWP(String maxEstimatedKWP) {
		this.maxEstimatedKWP = maxEstimatedKWP;
	}
	public String getOsSystemSize() {
		return osSystemSize;
	}
	public void setOsSystemSize(String osSystemSize) {
		this.osSystemSize = osSystemSize;
	}
	public String getFirstYearTotalProduction() {
		return firstYearTotalProduction;
	}
	public void setFirstYearTotalProduction(String firstYearTotalProduction) {
		this.firstYearTotalProduction = firstYearTotalProduction;
	}
	public String getPercentOffset() {
		return percentOffset;
	}
	public void setPercentOffset(String percentOffset) {
		this.percentOffset = percentOffset;
	}
	public String getAvoidedCost() {
		return avoidedCost;
	}
	public void setAvoidedCost(String avoidedCost) {
		this.avoidedCost = avoidedCost;
	}
	public String getPurchasePriceDollars() {
		return purchasePriceDollars;
	}
	public void setPurchasePriceDollars(String purchasePriceDollars) {
		this.purchasePriceDollars = purchasePriceDollars;
	}
	public String getPurchasePriceDollarsPerWatt() {
		return purchasePriceDollarsPerWatt;
	}
	public void setPurchasePriceDollarsPerWatt(String purchasePriceDollarsPerWatt) {
		this.purchasePriceDollarsPerWatt = purchasePriceDollarsPerWatt;
	}

	
}
