package com.triniti.bean;

public class ProformaYearsInfoBean {

	public ProformaYearsInfoBean() {}
	
	private String name;
	private String year;
	private String solarUnitSize;
	private String purchasePrice;
	private String maintenanceCost;
	private String electricity;
	private String utilityElectrictyPrice;
	private String avoidedUtilityElectricity;
	private String cumulativeTotalSavings;
	private String utilityIncentive;
	private String forProfit;
	private String irrOverride;
	private String addTaxOnSavings;
	private String stateTaxRate;
	private String totalTax;
	private String stateTaxExemptionOnUtilityIncentive;
	private String deductionOfStateIncomeTax;
	private String fedTaxBenefitFromDepr;
	private String fedTaxOnSavings;
	private String stateTaxBenefitFromDepr;
	private String stateTaxOnSavings;
	private String preTaxSavings;
	private String totalSavings;
	private String maintenanceExpenseEscalator;
	private String fedTaxRate;
	private String fedInvestmentTaxCredit;
	
	public String getFedInvestmentTaxCredit() {
		return fedInvestmentTaxCredit;
	}
	public void setFedInvestmentTaxCredit(String fedInvestmentTaxCredit) {
		this.fedInvestmentTaxCredit = fedInvestmentTaxCredit;
	}

	
	
	public String getFedTaxRate() {
		return fedTaxRate;
	}
	public void setFedTaxRate(String fedTaxRate) {
		this.fedTaxRate = fedTaxRate;
	}
	public String getMaintenanceExpenseEscalator() {
		return maintenanceExpenseEscalator;
	}
	public void setMaintenanceExpenseEscalator(String maintenanceExpenseEscalator) {
		this.maintenanceExpenseEscalator = maintenanceExpenseEscalator;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getSolarUnitSize() {
		return solarUnitSize;
	}
	public void setSolarUnitSize(String solarUnitSize) {
		this.solarUnitSize = solarUnitSize;
	}
	public String getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(String purchasePrice) {
		this.purchasePrice = purchasePrice;
	}
	public String getMaintenanceCost() {
		return maintenanceCost;
	}
	public void setMaintenanceCost(String maintenanceCost) {
		this.maintenanceCost = maintenanceCost;
	}
	public String getElectricity() {
		return electricity;
	}
	public void setElectricity(String electricity) {
		this.electricity = electricity;
	}
	public String getUtilityElectrictyPrice() {
		return utilityElectrictyPrice;
	}
	public void setUtilityElectrictyPrice(String utilityElectrictyPrice) {
		this.utilityElectrictyPrice = utilityElectrictyPrice;
	}
	public String getAvoidedUtilityElectricity() {
		return avoidedUtilityElectricity;
	}
	public void setAvoidedUtilityElectricity(String avoidedUtilityElectricity) {
		this.avoidedUtilityElectricity = avoidedUtilityElectricity;
	}
	public String getCumulativeTotalSavings() {
		return cumulativeTotalSavings;
	}
	public void setCumulativeTotalSavings(String cumulativeTotalSavings) {
		this.cumulativeTotalSavings = cumulativeTotalSavings;
	}
	public String getUtilityIncentive() {
		return utilityIncentive;
	}
	public void setUtilityIncentive(String utilityIncentive) {
		this.utilityIncentive = utilityIncentive;
	}
	public String getForProfit() {
		return forProfit;
	}
	public void setForProfit(String forProfit) {
		this.forProfit = forProfit;
	}
	public String getIrrOverride() {
		return irrOverride;
	}
	public void setIrrOverride(String irrOverride) {
		this.irrOverride = irrOverride;
	}
	public String getAddTaxOnSavings() {
		return addTaxOnSavings;
	}
	public void setAddTaxOnSavings(String addTaxOnSavings) {
		this.addTaxOnSavings = addTaxOnSavings;
	}
	public String getStateTaxRate() {
		return stateTaxRate;
	}
	public void setStateTaxRate(String stateTaxRate) {
		this.stateTaxRate = stateTaxRate;
	}
	public String getTotalTax() {
		return totalTax;
	}
	public void setTotalTax(String totalTax) {
		this.totalTax = totalTax;
	}
	public String getStateTaxExemptionOnUtilityIncentive() {
		return stateTaxExemptionOnUtilityIncentive;
	}
	public void setStateTaxExemptionOnUtilityIncentive(String stateTaxExemptionOnUtilityIncentive) {
		this.stateTaxExemptionOnUtilityIncentive = stateTaxExemptionOnUtilityIncentive;
	}
	public String getDeductionOfStateIncomeTax() {
		return deductionOfStateIncomeTax;
	}
	public void setDeductionOfStateIncomeTax(String deductionOfStateIncomeTax) {
		this.deductionOfStateIncomeTax = deductionOfStateIncomeTax;
	}
	public String getFedTaxBenefitFromDepr() {
		return fedTaxBenefitFromDepr;
	}
	public void setFedTaxBenefitFromDepr(String fedTaxBenefitFromDepr) {
		this.fedTaxBenefitFromDepr = fedTaxBenefitFromDepr;
	}
	public String getFedTaxOnSavings() {
		return fedTaxOnSavings;
	}
	public void setFedTaxOnSavings(String fedTaxOnSavings) {
		this.fedTaxOnSavings = fedTaxOnSavings;
	}
	public String getStateTaxBenefitFromDepr() {
		return stateTaxBenefitFromDepr;
	}
	public void setStateTaxBenefitFromDepr(String stateTaxBenefitFromDepr) {
		this.stateTaxBenefitFromDepr = stateTaxBenefitFromDepr;
	}
	public String getStateTaxOnSavings() {
		return stateTaxOnSavings;
	}
	public void setStateTaxOnSavings(String stateTaxOnSavings) {
		this.stateTaxOnSavings = stateTaxOnSavings;
	}
	public String getPreTaxSavings() {
		return preTaxSavings;
	}
	public void setPreTaxSavings(String preTaxSavings) {
		this.preTaxSavings = preTaxSavings;
	}
	public String getTotalSavings() {
		return totalSavings;
	}
	public void setTotalSavings(String totalSavings) {
		this.totalSavings = totalSavings;
	}
	
	
}
