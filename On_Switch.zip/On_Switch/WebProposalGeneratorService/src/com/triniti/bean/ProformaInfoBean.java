package com.triniti.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProformaInfoBean {

	public ProformaInfoBean() {}
	
	private String priceAfterTaxBenes;
	private String cashPrice;
	private String totalSavings;
	private String paybackOn25YearLife;
	private String irr;
	private String npv;
	private String discountRate;
	
	@JsonProperty("years")
	private List<ProformaYearsInfoBean> yearsInfoBean;
	
	public String getPriceAfterTaxBenes() {
		return priceAfterTaxBenes;
	}
	public void setPriceAfterTaxBenes(String priceAfterTaxBenes) {
		this.priceAfterTaxBenes = priceAfterTaxBenes;
	}
	public String getCashPrice() {
		return cashPrice;
	}
	public void setCashPrice(String cashPrice) {
		this.cashPrice = cashPrice;
	}
	public String getTotalSavings() {
		return totalSavings;
	}
	public void setTotalSavings(String totalSavings) {
		this.totalSavings = totalSavings;
	}
	public String getPaybackOn25YearLife() {
		return paybackOn25YearLife;
	}
	public void setPaybackOn25YearLife(String paybackOn25YearLife) {
		this.paybackOn25YearLife = paybackOn25YearLife;
	}
	public String getIrr() {
		return irr;
	}
	public void setIrr(String irr) {
		this.irr = irr;
	}
	public String getNpv() {
		return npv;
	}
	public void setNpv(String npv) {
		this.npv = npv;
	}
	public String getDiscountRate() {
		return discountRate;
	}
	public void setDiscountRate(String discountRate) {
		this.discountRate = discountRate;
	}
	public List<ProformaYearsInfoBean> getYearsInfoBean() {
		return yearsInfoBean;
	}
	public void setYearsInfoBean(List<ProformaYearsInfoBean> yearsInfoBean) {
		this.yearsInfoBean = yearsInfoBean;
	}
	
	
}
