package com.triniti;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
@PropertySource("file:${CONFIG_PATH}proposal-app.properties")
@ComponentScan
public class ApplicationConfiguration {

    @Value("${name}")
    private String name;
    
    @Value("${outputfilepath}")
    private String outputFilePath;
    
    @Value("${googleAPIKey}")
    private String googleAPIKey;
    
    @Value("${webMergeURL}")
    private String webMergeDocumentURL;

    public String getGoogleAPIKey() {
		return googleAPIKey;
	}

	public String getWebMergeDocumentURL() {
		return webMergeDocumentURL;
	}

	public String getOutputFilePath() {
		return outputFilePath;
	}

	@Bean
    public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
        return new PropertySourcesPlaceholderConfigurer();
    }

	public String getName() {
		return name;
	}

}