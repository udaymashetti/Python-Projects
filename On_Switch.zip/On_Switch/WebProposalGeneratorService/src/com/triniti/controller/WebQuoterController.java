package com.triniti.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.triniti.ApplicationConfiguration;
import com.triniti.bean.ESAInfoBean;
import com.triniti.bean.ESAPairBean;
import com.triniti.bean.PortalInfoBean;
import com.triniti.bean.ProformaInfoBean;
import com.triniti.bean.ProformaYearsInfoBean;
import com.triniti.bean.QuoteInfoBean;
import com.triniti.bean.WebQuoterMainBean;
import com.triniti.service.WebMergeCommunicatorService;



@RestController
public class WebQuoterController {

	@Autowired
	private WebMergeCommunicatorService webMergeCommunicatorService;
	
	@Autowired
	private ApplicationConfiguration configuration;

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@RequestMapping("/webMerge/generateProposal")
	public  Map<String, String> generateDocument(@RequestBody WebQuoterMainBean mainBean){
	
		Map<String, String> returnMap	=	 new HashMap<>();
		//printJSONData(mainBean);
		try {
			webMergeCommunicatorService.init();
			returnMap	=	webMergeCommunicatorService.prepareMergeData(mainBean);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			returnMap.put("Error" , e.getLocalizedMessage());
			
		}
		
		
		System.out.println("WebQuoterController.generateDocument() returnMap-" + returnMap);
		return returnMap;
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	@RequestMapping("/webMerge/getName")
	public  String getName(){
	
		 String result = "TEST-" + configuration.getName();
		 return result;
	}
	
	@GET
	@Produces({MediaType.APPLICATION_OCTET_STREAM,MediaType.APPLICATION_JSON})
	@RequestMapping("/webMerge/downloadProposal/{fileName}")
	public  ResponseEntity downloadProposal( @PathVariable("fileName") String key){
	
		InputStreamResource isr = null;
		System.out.println("WebQuoterController.downloadProposal() input key-" + key);

		    File file =  new File(configuration.getOutputFilePath() + "/" + key + ".docx"); 

		    System.out.println("WebQuoterController.downloadProposal() file path " + file.getAbsolutePath());
		    
		    HttpHeaders headers = new HttpHeaders();
		    headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
		    headers.add("Pragma", "no-cache");
		    headers.add("Expires", "0");
		    
		    
			try {
				isr = new InputStreamResource(new FileInputStream(file));
				headers.setContentType(org.springframework.http.MediaType.APPLICATION_OCTET_STREAM);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				return new ResponseEntity ("File Not Found", HttpStatus.OK);
			}
		    return new ResponseEntity<InputStreamResource>(isr, headers, HttpStatus.OK);
	}
	
	public void printJSONData(WebQuoterMainBean mainBean) {
		System.out.println("Creating a Document-");
		System.out.println("portalBean-" + mainBean.getPortalInfoBean());
		if(mainBean != null) {
			PortalInfoBean portalBean	=	mainBean.getPortalInfoBean();
			if(portalBean != null) {
				System.out.println("portalId" + portalBean.getPortalId());
				System.out.println("portalName" + portalBean.getPortalName());
				
				System.out.println("contactName" + portalBean.getContactName());
				System.out.println("companyName" + portalBean.getCompanyName());
				System.out.println("emailAddress" + portalBean.getEmailAddress());
				System.out.println("purchasePriceDollarsPerWatt-" + portalBean.getPurchasePriceDollarsPerWatt());
				System.out.println("timestamp" + portalBean.getTimestamp());
				System.out.println("triggerMail" + portalBean.getTriggerMail());
				System.out.println("portalUrl" + portalBean.getPortalUrl());
			}
			System.out.println("--------------------------------------------------------------------------------------------------------------");
			System.out.println("quoteBean-" + mainBean.getQuoteInfoBean());
			
			QuoteInfoBean quoteBean	=	mainBean.getQuoteInfoBean();
			if(quoteBean != null) {
				System.out.println("productionEstimate" + quoteBean.getProductionEstimate());
				System.out.println("AnnualConsumption" + quoteBean.getAnnualConsumption());
				
				System.out.println("startingTariff	" + quoteBean.getStartingTariff());
				System.out.println("firstYearTotalProduction" + quoteBean.getFirstYearTotalProduction());
				System.out.println("usableRoofArea" + quoteBean.getUsableRoofArea());
				System.out.println("percentOffset" + quoteBean.getPercentOffset());
				System.out.println("purchasePriceDollarsPerWatt-" + quoteBean.getPurchasePriceDollarsPerWatt());
				
				List<ESAPairBean> esaPairBeanList	=	quoteBean.getEsaPairBean();
				
				System.out.println("esaPairBean-" + esaPairBeanList);
				for(ESAPairBean esaPairBean:esaPairBeanList) {
					System.out.println("key-" + esaPairBean.getKey() + "-value-" + esaPairBean.getValue());
				}
			}
			System.out.println("--------------------------------------------------------------------------------------------------------------");
			System.out.println("esaBean-" + mainBean.getEsaInfoBean());
			ESAInfoBean esaInfoBean	=	mainBean.getEsaInfoBean();
			if(esaInfoBean != null) {
				System.out.println("discountPercentToUtil" + esaInfoBean.getDiscountPercentToUtil());
				System.out.println("year1SolarOutput" + esaInfoBean.getYear1SolarOutput());
				
				System.out.println("esaSavingsOverTerm	" + esaInfoBean.getEsaSavingsOverTerm());
			}
			System.out.println("--------------------------------------------------------------------------------------------------------------");
			System.out.println("proformaBean-" + mainBean.getProformaInfoBean());
			ProformaInfoBean proformaBean	=	mainBean.getProformaInfoBean();
			if(proformaBean != null) {
				System.out.println("priceAfterTaxBenes" + proformaBean.getPriceAfterTaxBenes());
				System.out.println("cashPrice" + proformaBean.getCashPrice());
				
				System.out.println("totalSavings	" + proformaBean.getTotalSavings());
				System.out.println("paybackOn25YearLife" + proformaBean.getPaybackOn25YearLife());
				System.out.println("irr" + proformaBean.getIrr());
				
				System.out.println("discountRate	" + proformaBean.getDiscountRate());
				
				
				List<ProformaYearsInfoBean> yearsInfoBeanList	=	proformaBean.getYearsInfoBean();
				
				for(ProformaYearsInfoBean yearsInfoBean:yearsInfoBeanList) {
					System.out.println("**************************************");
					System.out.println("name-" + yearsInfoBean.getName());
					System.out.println("year-" + yearsInfoBean.getYear());
					
					System.out.println("solarUnitSize-" + yearsInfoBean.getSolarUnitSize());
					System.out.println("purchasePrice-" + yearsInfoBean.getPurchasePrice());
					System.out.println("utilityIncentive-" + yearsInfoBean.getUtilityIncentive());
					
					System.out.println("totalTax-" + yearsInfoBean.getTotalTax());
					System.out.println("fedTaxBenefitFromDepr-" + yearsInfoBean.getFedTaxBenefitFromDepr());
					System.out.println("preTaxSavings-" + yearsInfoBean.getPreTaxSavings());
					System.out.println("totalSavings-" + yearsInfoBean.getTotalSavings());
					
				}
			}
		}
	}
}
