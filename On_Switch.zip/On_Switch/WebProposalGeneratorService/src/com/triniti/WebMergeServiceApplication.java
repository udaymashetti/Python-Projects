package com.triniti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication
public class WebMergeServiceApplication  extends SpringBootServletInitializer{
	
	/*@Value("${firstName}")
	private static String name;
*/	
	public static void main(String[] args) {
		 System.setProperty("spring.config.name", "proposal-app");
		SpringApplication.run(WebMergeServiceApplication.class, args);
		
		//System.out.println("WebMergeServiceApplication.main() = " + name);
	}
	
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		 //System.setProperty("spring.config.name", "my-app");
        return application.sources(WebMergeServiceApplication.class).properties("spring.config.name:proposal-app");
    }
    
}
